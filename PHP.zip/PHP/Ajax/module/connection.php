<?php
$conn=mysqli_connect('localhost','root','','phpconnect2');
if(!$conn)  
{  
  die('Could not connect: ' . mysqli_error());  
}  
echo 'Connected successfully <br>';  
  
?>