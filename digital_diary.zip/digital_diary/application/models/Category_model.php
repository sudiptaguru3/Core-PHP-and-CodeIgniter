<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Category_model extends CI_Model 
{
	function register($insertArray){
        
        if($this->db->insert('category',$insertArray)){
            return true;
        }else{
            return false;
        }
    }
}