<?php
class abc{
	function test(){
		echo "Hello PHP";
	}
}
 $obj=new abc();
 $obj-> test();
?>