<?php
session_start();
$_SESSION['name']='Rahul';
print_r($_SESSION['name']);

?>