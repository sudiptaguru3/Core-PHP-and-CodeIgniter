<?php
session_start();
include "connect.php";
$id=$_SESSION['id'];
$sql=mysqli_query($conn,"SELECT * FROM user WHERE id=".$id);
$data=mysqli_fetch_array($sql);

$db_pass=$data['password'];
$old_pass=md5($_REQUEST['old_pass']);
$new_pass=md5($_REQUEST['new_pass']);
$confirm_pass=md5($_REQUEST['confirm_pass']);

if($db_pass==$old_pass)
{
	if($old_pass!=$new_pass)
	{
		if($new_pass==$confirm_pass)
		{
			$update=mysqli_query($conn,"UPDATE user SET password='".$new_pass."' where ID=".$id);
			if($update)
			{
				header("location:profile.php?pass=4");
			}
			else
			{
				header("location:changePassword.php?pass=3");
			}
		}
		else
		{
			header("location:changePassword.php?pass=2");
		}

	}
	else
	{
		header("location:changePassword.php?pass=1");

	}

}
else
{
	header("location:changePassword.php?pass=0");
}

?>