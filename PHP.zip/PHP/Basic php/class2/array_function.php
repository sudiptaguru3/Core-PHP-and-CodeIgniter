<?php
echo "<h3> Array Push </h3>";
$ar1= array('1'=>'Blue','2'=>'Yellow','3'=>'Black');
array_push($ar1, 'Red');
print_r($ar1);
echo "<br>";

echo "<h3> Array Pop </h3>";
$ar2= array('10','25','30');
array_pop($ar2,);
print_r($ar2);
echo "<br>";

echo "<h3> Array Combine </h3>"; 
$ar3= array('20','30','50');
$ar4= array('blue','pink','green');
print_r(array_combine($ar3, $ar4));
echo "<br>";

echo "<h3> Array Merge </h3>"; 
print_r(array_merge($ar3, $ar4));
echo "<br>";

echo "<h3> Array Chunk </h3>"; 
$ar5= array('1'=>'red', '2'=>'php','3'=>'java','4'=>'c','5'=>'ejob','6'=>'green');
echo "<pre>";
print_r(array_chunk($ar5,3));
echo "<br>";

echo "<h3> Array Slice </h3>";
print_r(array_slice($ar5, 3));
echo "<br>";

echo "<h3> Array Unique </h3>";
$ar6= array('1'=>'php','2'=>'java','3'=>'php','4'=>'c','5'=>'java');
print_r(array_unique($ar6));
echo "<br>";

echo "<h3> Array Sum </h3>";
$a=array(10,30,25);
print_r(array_sum($a));
echo "<br>";
echo "<h3> Array Product </h3>";
print_r(array_product($a));
echo "<br>";

echo "<h3> Array Reverse </h3>";
$ar6=array("1"=>"Hello","2"=>"ejob","3"=>"india");
print_r(array_reverse($ar6));
echo "<br>";

echo "<h3> Array Replace </h3>";
$ar7=array("1"=>"Hello","2"=>"ejob");
$ar8=array("1"=>"india","2"=>"west");
print_r(array_replace($ar7, $ar8));
echo "<br>";

echo "<h3> Array Key Exists </h3>";
$ab=array('0'=>'ejob','1'=>'php','2'=>'ggg',"3"=>"red");
if(array_key_exists(1, $ab))
{
	echo "key exists";
}
else
{
	echo "key not exists";
}
echo "<br>";

echo "<h3> in Array </h3>";
if(in_array('ejob', $ab))
{
	echo "yes value is there";
}
else
{
	echo "no value is not found";
}
echo "<br>";

echo "<h3> is Array </h3>";
$str="hello";
if(is_array($str))
{
	echo "yes it is an array";
}
else
{
	echo "no, it is not an array";
}
echo "<br>";
?>