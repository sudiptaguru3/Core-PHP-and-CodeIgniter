<?php
$ar= array('1'=>'Blue','2'=>'Yellow','3'=>'Black');

foreach ($ar as $key => $value) {
	echo $key.'='.$value;
	echo "<br>";
	//echo $value;
	echo "<br>";
}
?>