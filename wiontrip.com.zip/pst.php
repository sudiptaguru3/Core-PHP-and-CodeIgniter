<?php 
	include("z_db.php");
	include("Auth.php");
	
	if(isset($_POST['dest']))
	{
		$ar = array();
		$dest = mysqli_real_escape_string($con,trim($_POST['dest']));
		$qre = mysqli_query($con,"select flight_date from ticket_master where flight_id in (select id from airline_flight_no_master where destination_id='$dest') and isexpire='0'  order by id asc");
		if(mysqli_num_rows($qre)>0)
		{
			while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
			{
				$date .= $res["flight_date"]."~";
				
				//$ar = $res["flight_date"];
				
				array_push($ar,$res["flight_date"]);
			}
		}
		//echo $ar;
		die(json_encode(array('items'=>$ar))); //output json 	
	}
	
	if(isset($_POST['airline']) && isset($_POST['date'])   && isset($_POST['typ']))
	{
		
		$airline=mysqli_real_escape_string($con,trim($_POST['airline']));
		$infant=mysqli_real_escape_string($con,trim($_POST['infant']));
		$child=mysqli_real_escape_string($con,trim($_POST['child']));
		$adult=mysqli_real_escape_string($con,trim($_POST['adult']));
		$date=mysqli_real_escape_string($con,trim($_POST['date']));
		$destination=mysqli_real_escape_string($con,trim($_POST['destination']));
		$typ=mysqli_real_escape_string($con,trim($_POST['typ']));
		
		$qty = $child+$adult;
		$data_table = "";
		
		unset($_SESSION['des']);
		unset($_SESSION['dt']);
		unset($_SESSION['ad']);
		unset($_SESSION['ch']);
		unset($_SESSION['inf']);
		unset($_SESSION['ttl']);
		
		$_SESSION['des']=$destination;
		$_SESSION['dt']=$date;
		$_SESSION['ad']=$adult;
		$_SESSION['ch']=$child;
		$_SESSION['inf']=$infant;
		$_SESSION['qty']=$qty;
		
		
		
		if($typ=="left")
		{
			$exp = explode('-',$date);
			
			if($exp[0]==1)
			{
				$day_count = 30;	
			}
			else
			{
				$day_count = ($exp[0]-1);
			}
			$date = $day_count."-".$exp[1]."-".$exp[2];
			
			if($airline == "all")
			{
				$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM `ticket_master` t where available_seat>='$qty' and  flight_id in (select id from airline_flight_no_master where destination_id='$destination' ) and flight_date='$date') j ) f");	
			}
			else
			{
				$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM ticket_master t where available_seat>='$qty' and airline_id='$airline' and flight_id in (select id from airline_flight_no_master where destination_id='$destination' and airline_id='$airline') and flight_date='$date') j ) f");	
			}
		}
		else if($typ=="right")
		{
			$exp = explode('-',$date);
			
			if($exp[0]==30 || $exp[0]==31)
			{
				$day_count = 1;	
			}
			else
			{
				$day_count = ($exp[0]+1);
			}
			$date = $day_count."-".$exp[1]."-".$exp[2];
			
			if($airline == "all")
			{
				$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM `ticket_master` t where available_seat>='$qty' and  flight_id in (select id from airline_flight_no_master where destination_id='$destination' ) and flight_date='$date') j ) f");	
			}
			else
			{
				$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM ticket_master t where available_seat>='$qty' and airline_id='$airline' and flight_id in (select id from airline_flight_no_master where destination_id='$destination' and airline_id='$airline') and flight_date='$date') j ) f");
			}
		}
		
		
		
		
		if(mysqli_num_rows($qre)>0)
		{
			while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
			{
				$ttl = $res["price"]*$qty;
				if($infant>0)
				{
					$ttl = $ttl+1500;	
				}
				$data_table .="<tr>";
				$data_table .="<td><img src='2021/productimg/".$res["airline_logo"]."' width='70' height='70' alt=' ' /></td>";
				$data_table .="<td><strong>".$res["from_city_name"]." to ".$res["to_city_name"]."</strong></td>";
				$data_table .="<td><strong>".$res["flight_number"]."</strong></td>";
				$data_table .="<td><strong>".$date."</strong></td>";
				$data_table .="<td><strong>".$res["dep_hour"]." : ".$res["dep_mint"]."</strong></td>";
				$data_table .="<td><strong>".$res["arrival_hour"]." : ".$res["arrival_mint"]."</strong></td>";
				$data_table .="<td><strong>".$qty."</strong></td>";
				$data_table .="<td><strong>".$res["available_seat"]."</strong></td>";
				$data_table .="<td><strong>".$ttl."</strong></td>";
				$data_table .="<td><a href='proceed-booking.php?sol=".$res["id"]."' class='btn btn-success'>Book Now</a></td>";
				$data_table .="</tr>";				
			}
			die(json_encode(array('items'=>$data_table,'msg'=>'Done','dt'=>$date))); //output json 
		}	
		else
		{
			die(json_encode(array('items'=>'NOTOK','msg'=>'No Flight Found','dt'=>$date))); //output json 
			
		}
		
			
	}
	
	
	if(isset($_POST['airline']) && isset($_POST['date'])  && !isset($_POST['typ']) )
	{
		
		$airline=mysqli_real_escape_string($con,trim($_POST['airline']));
		$infant=mysqli_real_escape_string($con,trim($_POST['infant']));
		$child=mysqli_real_escape_string($con,trim($_POST['child']));
		$adult=mysqli_real_escape_string($con,trim($_POST['adult']));
		$date=mysqli_real_escape_string($con,trim($_POST['date']));
		$destination=mysqli_real_escape_string($con,trim($_POST['destination']));
		
		$qty = $child+$adult;
		$data_table = "";
		
		unset($_SESSION['des']);
		unset($_SESSION['dt']);
		unset($_SESSION['ad']);
		unset($_SESSION['ch']);
		unset($_SESSION['inf']);
		unset($_SESSION['ttl']);
		
		$_SESSION['des']=$destination;
		$_SESSION['dt']=$date;
		$_SESSION['ad']=$adult;
		$_SESSION['ch']=$child;
		$_SESSION['inf']=$infant;
		$_SESSION['qty']=$qty;
		
		
		if($airline == "all")
		{
			$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM `ticket_master` t where available_seat>='$qty' and  flight_id in (select id from airline_flight_no_master where destination_id='$destination' ) and flight_date='$date') j ) f");	
		}
		else
		{
			$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM ticket_master t where available_seat>='$qty' and airline_id='$airline' and flight_id in (select id from airline_flight_no_master where destination_id='$destination' and airline_id='$airline') and flight_date='$date') j ) f");	
		}
		
		if(mysqli_num_rows($qre)>0)
		{
			while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
			{
				$ttl = $res["price"]*$qty;
				if($infant>0)
				{
					$ttl = $ttl+1500;	
				}
				$data_table .="<tr>";
				$data_table .="<td><img src='2021/productimg/".$res["airline_logo"]."' width='70' height='70' alt=' ' /></td>";
				$data_table .="<td><strong>".$res["from_city_name"]." to ".$res["to_city_name"]."</strong></td>";
				$data_table .="<td><strong>".$res["flight_number"]."</strong></td>";
				$data_table .="<td><strong>".$date."</strong></td>";
				$data_table .="<td><strong>".$res["dep_hour"]." : ".$res["dep_mint"]."</strong></td>";
				$data_table .="<td><strong>".$res["arrival_hour"]." : ".$res["arrival_mint"]."</strong></td>";
				$data_table .="<td><strong>".$qty."</strong></td>";
				$data_table .="<td><strong>".$res["available_seat"]."</strong></td>";
				$data_table .="<td><strong>".$ttl."</strong></td>";
				$data_table .="<td><a href='proceed-booking.php?sol=".$res["id"]."' class='btn btn-success'>Book Now</a></td>";
				$data_table .="</tr>";				
			}
			die(json_encode(array('items'=>$data_table,'msg'=>"Done"))); //output json 
		}	
		else
		{
			die(json_encode(array('items'=>'NOTOK','msg'=>'No Flight Found'))); //output json 
			
		}
		
			
	}
?>