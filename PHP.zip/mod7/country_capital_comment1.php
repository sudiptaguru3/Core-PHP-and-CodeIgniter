<?php
echo "<pre>";
 $con = array( "Italy"=>"Rome", "Luxembourg"=>"Luxembourg", "Belgium"=> "Brussels", "Denmark"=>"Copenhagen", "Finland"=>"Helsinki", "France" => "Paris", "Slovakia"=>"Bratislava", "Slovenia"=>"Ljubljana", "Germany" => "Berlin", "Greece" => "Athens", "Ireland"=>"Dublin", "Netherlands"=>"Amsterdam", "Portugal"=>"Lisbon", "Spain"=>"Madrid", "Sweden"=>"Stockholm", "United Kingdom"=>"London", "Cyprus"=>"Nicosia", "Lithuania"=>"Vilnius", "Czech Republic"=>"Prague", "Hungary"=>"Budapest", "Latvia"=>"Riga", "Malta"=>"Valetta", "Austria" => "Vienna", "Poland"=>"Warsaw") ; 
 $coun = [
 	["cap"=>'Rome',"coun"=>'Italy'],
 	["cap"=>'Luxembourg',"coun"=>'Luxembourg'],
 	["cap"=>'Brussels',"coun"=>'Belgium'],
 	["cap"=>'Copenhagen',"coun"=>'Denmark'],
 	["cap"=>'Helsinki',"coun"=>'Finland'],
 	["cap"=>'Paris',"coun"=>'France'],
 	["cap"=>'Bratislava',"coun"=>'Slovakia'],
 	["cap"=>'Ljubljana',"coun"=>'Slovenia'],
 	["cap"=>'Berlin',"coun"=>'Germany'],
 	["cap"=>'Athens',"coun"=>'Greece'],
 	["cap"=>'Dublin',"coun"=>'Ireland'],
 	["cap"=>'Amsterdam',"coun"=>'Netherlands'],
 	["cap"=>'Lisbon',"coun"=>'Portugal'],
 	["cap"=>'Madrid',"coun"=>'Spain'],
 	["cap"=>'Stockholm',"coun"=>'Sweden'],
 	["cap"=>'London',"coun"=>'United Kingdom'],
 	["cap"=>'Nicosia',"coun"=>'Cyprus'],
 	["cap"=>'Vilnius',"coun"=>'Lithuania'],
 	["cap"=>'Prague',"coun"=>'Czech Republic'],
 	["cap"=>'Budapest',"coun"=>'Hungary'],
 	["cap"=>'Riga',"coun"=>'Latvia'],
 	["cap"=>'Valetta',"coun"=>'Malta'],
 	["cap"=>'Vienna',"coun"=>'Austria'],
 	["cap"=>'Warsaw',"coun"=>'Poland'],
 ];
foreach ($coun as["cap" => $cap, "coun" => $coun]) {
    echo "capital of $coun is $cap\n";
}
?>