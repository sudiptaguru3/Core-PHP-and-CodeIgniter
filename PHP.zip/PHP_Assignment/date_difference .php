<?php
$date1= date_create("1981-11-04");
//echo $date1;
//echo date_format($date1, "Y-m-d");
$date2= date_create(date("2020-09-04"));
$diff= date_diff($date2, $date1);
//echo $diff;
//echo date_format($diff, "y-m-d");
echo $diff->format("%y year %m month %d days");
?>