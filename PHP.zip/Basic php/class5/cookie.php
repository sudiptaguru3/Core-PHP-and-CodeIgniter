<?php
// $_COOKIE['address']='Kolkata';
// print_r($_COOKIE['address']);
?>

<?php
setcookie('name','Rajesh',time()+5);
// setcookie('address','Kolkata',time()+5);
setcookie('name','Rajesh',time()-5);

print_r($_COOKIE['name']);
?>