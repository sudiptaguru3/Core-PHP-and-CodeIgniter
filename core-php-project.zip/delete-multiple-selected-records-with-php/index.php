<?php 
include "config.php";
?>
<!doctype html>
<html>
    <head>
        <title>Delete Multiple Selected Records with PHP</title>
        <!-- <link href='style.css' rel='stylesheet' type='text/css'> -->

        <?php 
        if(isset($_POST['but_delete'])){

            if(isset($_POST['delete'])){
                foreach($_POST['delete'] as $deleteid){

                    $deleteUser = "DELETE from user WHERE id=".$deleteid;
                    mysqli_query($con,$deleteUser);
                }
            }
            
        }
        ?>
    </head>
    <body>
        <div class='container'>

            <!-- Form -->
            <form method='post' action=''>
                <input type='submit' value='Delete' name='but_delete'><br><br>
            

            <!-- Record list -->
            <table border='1' style='border-collapse: collapse;' >
                <tr style='background: whitesmoke;'>
                    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Address</th>
    <th>Action</th>
    <th><span class="custom-checkbox"><input type="checkbox" id="selectAll"><label for="selectAll"></label></span></th>
                    <!-- <th>&nbsp;</th> -->
                </tr>

                <?php 
                $query = "SELECT * FROM user";
                $result = mysqli_query($con,$query);

                $count = 1;
                while($row = mysqli_fetch_array($result) ){
                    $id = $row['id'];
                    $name = $row['name'];
                    $email = $row['email'];
                    $contact = $row['contact'];
                    $address = $row['address'];
                ?>
                    <tr id='tr_<?= $id ?>'>

                        <td><?= $name ?></td>
                        <td><?= $email ?></td>
                        <td><?= $contact ?></td>
                        <td><?= $address ?></td>
                        <td><input type='submit' value='Delete' name='but_delete'></td>
                        <td><span class="custom-checkbox"><input type="checkbox" name='delete[]' class="user_checkbox" value='<?= $id ?>'><label for="checkbox2"></label></span></td>

                        <!-- Checkbox -->
                        <!-- <td><input type='checkbox' name='delete[]' value='<?= $id ?>' ></td> -->
                        
                    </tr>
                <?php
                }
                ?>
            </table>
            </form>
        </div>
    </body>
</html>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>User Data</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="ajax/ajax.js"></script>
<script type="text/javascript">

    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
        var checkbox = $('table tbody input[type="checkbox"]');
        $("#selectAll").click(function(){
            if(this.checked){
                checkbox.each(function(){
                    this.checked = true;                        
                });
            } else{
                checkbox.each(function(){
                    this.checked = false;                        
                });
            } 
        });
        checkbox.click(function(){
            if(!this.checked){
                $("#selectAll").prop("checked", false);
            }
        });
    });

</script>