<?php
session_start();
include 'connect.php';
if(isset($_REQUEST['login']) && $_REQUEST['login'] == 1){
    echo "<font color='green'>Login successful</font>";
}
if(isset($_REQUEST['update']) && $_REQUEST['update'] == 1){
    echo "<font color='green'> profile update successful</font>";
}

if(isset($_REQUEST['pass']) && $_REQUEST['pass'] == 4){
    echo "<font color='green'>password updated successfully</font>";
}
$id =$_SESSION['id'];
// print_r($id);
$sql = mysqli_query($conn, "SELECT * FROM user WHERE id =".$id);
$data = mysqli_fetch_array($sql);
?>
<br>
<p>Name:<?php echo $data['name']; ?></p><br><br>
<p>Email: <?php echo $data['email']; ?></p><br><br>
<p>Address: <?php echo $data['address']; ?></p><br><br>
<p>Number: <?php echo $data['contact']; ?></p><br><br>
<p>Gender: <?php echo $data['gender'] ?></p><br><br>
<p>Skill: <?php echo $data['skill'] ?></p><br><br>
<p>City: <?php echo $data['city'] ?></p><br><br>
<p>FILE:<img src="<?php echo $data['file']; ?>" width="100px" height="100px"><p><br><br>

<a href="editProfile.php">Edit Profile</a><br>
<a href="changePassword.php">Change Password</a><br>
<a href="logOut.php">Log Out</a></br>
