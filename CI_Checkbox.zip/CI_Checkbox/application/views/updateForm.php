<!DOCTYPE html>
<html lang="en">
<head>
    <title>Update User</title>
</head>
<body>
    <a href="<?php echo base_url(); ?>">Add User </a> 
    &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="<?php echo base_url('view'); ?>">View User</a>
    <hr>
    
    <form action="<?php echo base_url('update'); ?>" method="POST">

        <input type="hidden" name="userId" value="<?php echo $user['id']; ?>">
        <br>
        
        <a>Name :</a> 
        <input type="text" name="user" value="<?php echo $user['name']; ?>"> <br>
        
       Address :
        <input type="text" name="address" value="<?php echo $user['address']; ?>">
        <br>

        Phone :
        <input type="text" name="phone" value="<?php echo $user['phone']; ?>">
        <br>
        Skill:<input type="checkbox" name="skill[]" value="php">PHP
         <input type="checkbox" name="skill[]" value="android">ANDROID
         <input type="checkbox" name="skill[]" value="iphone">IPHONE 
         <input type="checkbox" name="skill[]" value="java">JAVA
         <br>
        
        <input type="submit" name="submitbtn" value="Update">
        <input type="reset" name="resetbtn" value="Refresh">
        <br>
    </form>
</body>
</html>