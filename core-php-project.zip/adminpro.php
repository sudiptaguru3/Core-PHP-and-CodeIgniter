<?php
require_once "connect.php";
$result = mysqli_query($conn, "SELECT * FROM user");
?>
<html>
<head>
<title>User List</title>
<link rel="stylesheet" type="text/css" href="styles.css" />
<script language="javascript" src="users.js" type="text/javascript"></script>
</head>
<body>
<form name="frmUser" method="post" action="">
<div style="width:500px;">
<table border="0" cellpadding="10" cellspacing="1" width="1000" class="tblListForm">
	<tr class="listheader">
<td colspan="8">
    <!-- <input type="button" name="update" value="Update" onClick="setUpdateAction();" />  -->
    <input type="button" name="delete" value="Delete"  onClick="setDeleteAction();" /></td>
</tr>
<tr class="listheader">
<td><span class="custom-checkbox"><input type="checkbox" id="selectAll"><label for="selectAll"></label></span></td>
<td>SL No</td>
<td>Name</td>
<td>Email</td>
<td>Phone</td>
<td>Address</td>
<td>Action</td>
<th>Status</th>
</tr>
<?php
$i=1;
while($row = mysqli_fetch_array($result)) {
if($i%2==0)
$classname="evenRow";
else
$classname="oddRow";
?>
<tr class="<?php if(isset($classname)) echo $classname;?>">
<td><span class="custom-checkbox"><input type="checkbox" name="user[]" value="<?php echo $row["id"]; ?>" class="user_checkbox"><label for="checkbox2"></label></span></td>
<!-- <td><input type="checkbox" name="user[]" value="<?php echo $row["id"]; ?>" ></td> -->
<td><?php echo $i; ?></td>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['email'];?></td>
<td><?php echo $row['contact'];?></td>
<td><?php echo $row['address'];?></td>
<td>
	<a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>&nbsp;&nbsp;
    <!-- <input href="edit_user.php?id=<?php echo $row['id']; ?>" type="button" name="delete" value="Edit"  onClick="setDeleteAction();" /> -->
    <a onclick="return confirm('Are you sure you want to delete this item ?');" href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
    <!-- <input href="delete_user.php?id=<?php echo $row['id']; ?>" type="button" name="delete" value="Delete"  onClick="setDeleteAction();" /> -->
</td>
<td><a href="active_deactive1.php?id=<?php echo $row['id'];?>">
		<?php
			if($row['login_status']==1)
			{
				echo "Block";
			}
			else
			{
				echo "Unblock";
			}
			?></a></td>
</tr>
<?php
$i++;
}
?>
</table>
</form>
</div>
</body>
</html>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">

    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
        var checkbox = $('table tbody input[type="checkbox"]');
        $("#selectAll").click(function(){
            if(this.checked){
                checkbox.each(function(){
                    this.checked = true;                        
                });
            } else{
                checkbox.each(function(){
                    this.checked = false;                        
                });
            } 
        });
        checkbox.click(function(){
            if(!this.checked){
                $("#selectAll").prop("checked", false);
            }
        });
    });

</script>