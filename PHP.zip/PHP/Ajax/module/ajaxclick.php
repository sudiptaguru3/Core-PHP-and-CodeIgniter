<!DOCTYPE html>

<html>
<head>

<title>Live Search using AJAX</title>

   <!-- Including jQuery is required. -->

   <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

   <!-- Including our scripting file. -->

   <script type="text/javascript" src="script.js"></script>

   <style type="text/css">
   a:hover {

   cursor: pointer;

   background-color: yellow;

   }
   </style>

</head>
<body>

<!-- Search box. -->

   <input type="text" id="search" placeholder="Search">

   <br>

   <!-- Suggestions will be displayed in below div. -->

   <div id="display"></div>
   
</body>
</html>