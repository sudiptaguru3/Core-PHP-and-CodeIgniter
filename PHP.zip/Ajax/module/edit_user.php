<?php
    include "connection.php";

    $id= $_POST['edit_id'];
	$name = $_POST['edit_name'];
	//$email = $_POST['edit_email'];
    $address= $_POST['edit_add'];
    $number= $_POST['edit_num'];
    
$sql="UPDATE user SET name='$name', address='$address', contact='$number' WHERE id='".$id."'";

$update= mysqli_query($conn, $sql);

	if($update){
		echo "Update Success";
	}else{
		echo "Update Failed";
	}

?>