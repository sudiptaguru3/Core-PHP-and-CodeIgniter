<!DOCTYPE html>
<html>
<head>
	<title>ajax search</title>
	<script
			  src="http://code.jquery.com/jquery-3.3.1.js"
			  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
			  crossorigin="anonymous">
	</script>

<script>
 $(document).ready(function(){
	$("input").keyup(function(){
	   var name=$("#nme").val();
	    if(name!='')
		{
		  $.ajax({
				  url:'search.php',
				  type:'post',
		   data:{'send_name':name},
		success:function(e){
					$("#shw").html(e);
				}

           })
		}
		else
	    {
			$("#shw").html('');
		}
				
	});
});
</script>
</head>

<body>

Search By Name:<input type="text" name="name" id="nme"><br>

<div id="shw"></div>
</body>
</html>