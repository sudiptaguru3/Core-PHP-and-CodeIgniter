<div class="content">

		<div class="navigation">
			<h5 class="title">Menu</h5>
			<!-- /.title -->
            
			<ul class="menu js__accordion">
                <li>
					<a href="dashboard.php" class="waves-effect"> <i class="menu-icon fa fa-home"> </i> <span class="font-bold">Dashboard</span> </a>
				</li>
				<li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon  fa fa-gears"> </i><span>Airlines</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li  > <a href="add_airport.php" class="auto"> <span>Add Airport</span> </a> </li>
                        <li  > <a href="add_airlines.php" class="auto"> <span>Add Airlines</span> </a> </li>
                        <li  > <a href="add_route.php" class="auto"> <span>Add Destination</span> </a> </li>
                   		<li  > <a href="add_flight.php" class="auto"> <span> Add Flights</span> </a> </li>
                        <li  > <a href="add_ticket.php" class="auto"> <span> Add Tickets</span> </a> </li>
                      
					</ul>
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon  fa fa-google-wallet"> </i><span>Manage Wallet</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li  > <a href="addswallet.php" class="auto"> <span>Wallet TOP-UP</span> </a> </li>                      
					</ul>
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon  fa fa-users"> </i><span>Manage Agent</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li  > <a href="members.php" class="auto"> <span>Agent List</span> </a> </li>                      
					</ul>
				</li>
                <li>
					<a class="waves-effect parent-item js__control" href="#"><i class="menu-icon  fa fa-ticket"> </i><span>Manage Bookings</span><span class="menu-arrow fa fa-angle-down"></span></a>
					<ul class="sub-menu js__content">
						<li  > <a href="booking.php" class="auto"> <span>Pending Booking List</span> </a> </li>
                        <li  > <a href="booking1.php" class="auto"> <span>Confirmed Booking List</span> </a> </li>                      
					</ul>
				</li>
				
                
			</ul>
			<!-- /.menu js__accordion -->
			
			<!-- /.title -->
			
			<!-- /.menu js__accordion -->
		</div>
		<!-- /.navigation -->
	</div>