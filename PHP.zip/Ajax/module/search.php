<?php
include "connection.php";
$search=$_REQUEST['send_name'];
$sql=mysqli_query($conn,"SELECT * FROM user WHERE name LIKE '$search%'");
?>
<table border="1" cellpadding="10">
<tr>
<th>Name</th>
<th>Email</th>
<th>Address</th>
<th>Contact No</th>
</tr>

<?php
while($fetch=mysqli_fetch_array($sql))
{
?>
 <tr>
  <td><?php echo $fetch['name'];?></td>
  <td><?php echo $fetch['email'];?></td> 
  <td><?php echo $fetch['address'];?></td>
  <td><?php echo $fetch['contact'];?></td>
 </tr>
<?php
}
?>
</table>