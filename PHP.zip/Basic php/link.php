<?php
$first= $_REQUEST['num1'];
$Second= $_REQUEST['num2'];
$result= $first + $Second;
echo $result;
?>