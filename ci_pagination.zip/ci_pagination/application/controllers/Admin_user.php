<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_user extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		// $this->load->database();
		// $this->load->model('Category_model');
	}

	public function index()
	{
		$this->load->view('admin_user_add');
	}

	public function add_user()
	{
		// echo "<pre>";
		// print_r($_FILES);
		$courses = $this->input->post('course');
       if(!empty($courses)){
      $course=implode(',',$courses);
    }
    else{
        $course='';
        } 
		$data['name']=$this->input->post('name');
		$data['email']=$this->input->post('email');
		$data['course']=$course;
		$this->load->model('StudentModel');
		 $user=$this->StudentModel->saverecords($data); 
		// if($user >0)
		// 	{
	
		// 	        redirect('Admin_user');
		// 	}
		// 	else
		// 	{
		// 			echo "Insert error !";
		// 	}

	}


}

?>	
	