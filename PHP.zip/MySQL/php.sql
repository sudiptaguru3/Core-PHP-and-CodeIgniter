-- Insert Query
INSERT INTO student (name,email,address,department,courses)
VALUES('raj','raj@gmail.com','kolkata','computer','c')