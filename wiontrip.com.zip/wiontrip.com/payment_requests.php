<?php 
	include("z_db.php");
	include("Auth.php");
?>
<!DOCTYPE html>
<html lang="en">

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    .custom-file-input.selected:lang(en)::after {
      content: "" !important;
    }

    .custom-file {
      overflow: hidden;
    }

    .custom-file-input {
      white-space: nowrap;
    }
    th{
    	color: white;
    	background-color: #9999ff;
    }
    /*td{
    	font-color: white;
    }*/
  </style>
<?php include("headercss.php");?>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<!--sidebar-wrapper-->
		<?php include("sidemenu.php");?>
		<!--end sidebar-wrapper-->
		<!--header-->
		<?php include("header.php");?>
		<!--end header-->
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					<div class="page-breadcrumb d-none d-md-flex align-items-center mb-3">
						
						<div class="ml-auto">
							<div class="btn-group">
								
								
								<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-left">	<a class="dropdown-item" href="javascript:;">Action</a>
									<a class="dropdown-item" href="javascript:;">Another action</a>
									<a class="dropdown-item" href="javascript:;">Something else here</a>
									<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
								</div>
							</div>
						</div>
					</div>
					<!--end breadcrumb-->
					<div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Payment Requests</h4>
							</div>
							<hr/>
							<div class="table-responsive">
    <form action="payment_requests_action.php" method="POST" enctype="multipart/form-data">
    	<label>Amount* :</label>
    		<div class="col-md-6">
    <input type="text" id="" placeholder="Amount" class="form-control" name="amount">
</div>
<label>Ref No* :</label>
<div class="col-md-6">
    <input type="text" id="" placeholder="Ref No" class="form-control" name="ref">
</div>
<label>Branch Name* :</label>
<div class="col-md-6">
    <input type="text" id="" placeholder="Branch Name" class="form-control" name="branch">
</div>
<label>Payment Type :</label>
<div class="col-md-6">
    <select name="payment_type" class="form-control">
    	<option value="NEFT">NEFT</option>
    	<option value="RTGS">RTGS</option>
    	<option value="IMPS">IMPS</option>
    	<option value="CASH_DEPOSIT">CASH DEPOSIT</option>
    	<option value="BANK_TRANSFER">BANK TRANSFER</option>
    	<option value="CHEQUE">CHEQUE</option>
    	<option value="UPI">UPI</option>
    	<option value="OTHER">OTHER</option>
    	<option value="CREDIT_REQUEST">CREDIT REQUEST</option>
    </select>
</div>
   
   <label>Payment Date* :</label>
   <div class="col-md-6">
    <input type="date" id="" placeholder="Date of transaction" class="form-control" name="payment_date">
</div>

<label>Message :</label>
<div class="col-md-6">
    <textarea placeholder="Message" class="form-control" name="message"></textarea>
</div>
    
    <label>Attachment:</label>
    <div class="col-md-6">
      <div class="custom-file">
        <input type="file" class="custom-file-input" id="customFileInput" aria-describedby="customFileInput" name="file">
        <label class="custom-file-label" for="customFileInput">Select file</label>
      </div>
    </div>
    <br>
    <input type="submit" class="btn btn-primary" value="Submit" name="submit">
  </form>
<br><br>
  	<table border="1" class="table">
<tr>
	<th style="color: white;">SL No</th>
	<th style="color: white;">Amount</th>
	<th style="color: white;">Ref No</th>
	<th style="color: white;">Branch Name</th>
	<th style="color: white;">Payment Type</th>
	<th style="color: white;">Payment Date</th>
	<th style="color: white;">Message</th>
	<th style="color: white;">Attachment</th>
	<th style="color: white;">Status</th>
</tr>

	<?php
	$i=1;
	$sql=mysqli_query($con,"SELECT *,(case when isactive='1' AND isaprove='1' then 'Aproved' else (case WHEN isactive='0' AND isaprove='0' THEN 'Reject' else 'Pending' END) END)status FROM payment_request");
	while($data=mysqli_fetch_array($sql))
	{
		?>
		<tr>
		<td><?php echo $i++;?></td>	
		<td><?php echo $data['amount'];?></td>
		<td><?php echo $data['ref'];?></td>
		<td><?php echo $data['branch_name'];?></td>
		<td><?php echo $data['payment_type'];?></td>
		<td><?php echo $data['payment_date'];?></td>
		<td><?php echo $data['message'];?></td>
		<td><img src="<?php echo $data['attachment']; ?>" width="100px" height="100px"></td>
		<td><?php echo $data['status'];?></td>
		<!-- <td><a href="active_deactive.php?id=<?php echo $data['id'];?>">
		<?php
			if($data['']==1)
			{
				echo "Block";
			}
			else
			{
				echo "Unblock";
			}
			?>
				
			</a>
		</td> -->
	</tr>
	<?php	
	}
	?>


</table>
							</div>
						</div>
						
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<!--footer -->
		<div class="footer">
			
			
			<p class="mb-0">WION TRIP @2021 | Developed By : <a href="http://happyweb.in/" target="_blank">Happy Web</a>
			</p>
		</div>
		<!-- end footer -->
	</div>
	<!-- end wrapper -->
	<!--start switcher-->
	<div class="switcher-wrapper">
		
		<div class="switcher-body">
			<h5 class="mb-0 text-uppercase">Theme Customizer</h5>
			<hr/>
			<h6 class="mb-0">Theme Styles</h6>
			<hr/>
			<div class="d-flex align-items-center justify-content-between">
				<div class="custom-control custom-radio">
					<input type="radio" id="darkmode" name="customRadio" class="custom-control-input">
					<label class="custom-control-label" for="darkmode">Dark Mode</label>
				</div>
				<div class="custom-control custom-radio">
					<input type="radio" id="lightmode" name="customRadio" checked class="custom-control-input">
					<label class="custom-control-label" for="lightmode">Light Mode</label>
				</div>
			</div>
			<hr/>
			<div class="custom-control custom-switch">
				<input type="checkbox" class="custom-control-input" id="DarkSidebar">
				<label class="custom-control-label" for="DarkSidebar">Dark Sidebar</label>
			</div>
			<hr/>
			<div class="custom-control custom-switch">
				<input type="checkbox" class="custom-control-input" id="ColorLessIcons">
				<label class="custom-control-label" for="ColorLessIcons">Color Less Icons</label>
			</div>
		</div>
	</div>

	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<?php include("footerjs.php");?>

</body>


</html>
<script>
    document.querySelector('.custom-file-input').addEventListener('change', function (e) {
      var name = document.getElementById("customFileInput").files[0].name;
      var nextSibling = e.target.nextElementSibling
      nextSibling.innerText = name
    })
  </script>