<?php
function test(){
     static $a=0;
     echo $a;
     $a++;
}
test(); echo "<br>";
test(); echo "<br>";
test(); echo "<br>";
test(); echo "<br>";
test(); 
?>