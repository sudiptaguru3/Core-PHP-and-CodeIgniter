
 <div class="content-wrapper">
 
 <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Employee</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add User</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

<section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Create User</h3>
          </div>
          <!-- /.card-header -->
          <form action="<?php echo base_url('Admin_user/add_user'); ?>" method="post"  enctype="multipart/form-data">
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter Full Name">
                  </div>

                  
                  <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="">
                  </div>
              </div>

              <div class="col-md-6">
                 <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" value="">
                  </div>
                 <div class="form-group">
                    <label for="mobile">Mobile</label>
                    <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile" value="">
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-6 col-sm-6">
                <div class="form-group">
                  <label>User Role</label>
                  <select class="form-control" style="width: 100%;" name="user_role">
                    <option value="Select">Select</option>
                    <option value="Super Admin">Super Admin</option>
                    <option value="Admin">Admin</option>
                    <option value="Employee">Employee</option> 
                  </select>
                </div>
              </div>
              <div class="col-3 col-sm-3">
                <div class="form-group">
                    <label for="profile_pic">Profile Picture</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <!-- <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic" onchange ="show_pictures(this.value)"> -->
                        <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic"  onchange="readURL(this);">
                        <label class="custom-file-label" for="profile_pic">Choose file</label>
                      </div>
                    </div>
                  </div>
              </div>

              <div class="col-3 col-sm-3">
                <div class="form-group">
                        <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('asset/banner/180.png'); ?>" id="image_disp" class="img-thumbnail">
                </div>
              </div>        
            </div>
            <div class="card-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
          </div>
          </form>       
        </div>
</div>        
</section>
</div> 


<!-------------- image showing just after uploading------------------- -->

<script type="text/javascript">
       function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#image_disp')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
<!-- 
<script type="text/javascript">
  $(document).ready(function () {
    $('#categoryForm').validate({
      rules: {
        category_name: {
          required: true
        },
      },
      messages: {
        category_name: {
          required: "Please enter category name"
        },
      },
      errorElement: 'span',
      errorPlacement: function (error, element) {
        error.addClass('invalid-feedback');
        element.closest('.form-group').append(error);
      },
      highlight: function (element, errorClass, validClass) {
        $(element).addClass('is-invalid');
      },
      unhighlight: function (element, errorClass, validClass) {
        $(element).removeClass('is-invalid');
      }
    });
  });
  </script> -->