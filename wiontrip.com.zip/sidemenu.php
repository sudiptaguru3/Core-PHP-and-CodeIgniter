<?php 
	$qre = mysqli_query($con,"select * from uwalletstatus where Msrno='".$_SESSION['MSRNO']."'");
	$res = mysqli_fetch_array($qre,MYSQLI_ASSOC);
	$credit = $res["credit"];
	$debit = $res["debit"];
	$due_amount = $res["due_amount"];
	$credit_limit = $res["credit_limit"];
?>
<div class="sidebar-wrapper" data-simplebar="true" style="background-color: #6236AF;">
			<div class="sidebar-header" style="background-color: #6236AF;">
				<div class="">
					<img src="logo_dashboard-white.png" class="logo-icon-2" style="width:174px !important;height:35px;" alt="" />
				</div>
				
				<a href="javascript:;" class="toggle-btn ml-auto" style="color: white;"> <i class="bx bx-menu"></i>
				</a>
			</div>
			<!--navigation-->
			<ul class="metismenu" id="menu">
				
				<!--<li class="menu-label">Web Apps</li>-->
				
                <li>
					<a href="dashboard.php">
						<div class="parent-icon icon-color-1"> <i class="bx bx-home-alt"></i>
						</div>
						<div class="menu-title" style="color: white;">Dashboard</div>
					</a>
				</li>
                <li>
					<a href="javascript:void(0);">
						<div class="parent-icon icon-color-1"> <i class="bx bx-rupee"></i>
						</div>
						<div class="menu-title" style="color: white;">Balance <?php echo $credit;?></div>
					</a>
				</li>
                <li>
					<a href="javascript:void(0);">
						<div class="parent-icon icon-color-1"> <i class="bx bx-rupee"></i>
						</div>
						<div class="menu-title" style="color: white;">Credit Limit <?php echo $credit_limit;?></div>
					</a>
				</li>
                <li>
					<a href="javascript:void(0);">
						<div class="parent-icon icon-color-1"> <i class="bx bx-rupee"></i>
						</div>
						<div class="menu-title" style="color: white;">Due Amount <?php echo $due_amount;?></div>
					</a>
				</li>
                
				<li>
					<a href="Fare_Calendar.php">
						<div class="parent-icon icon-color-3"> <i class="bx bx-calendar"></i>
						</div>
						<div class="menu-title" style="color: white;">Fare Calendar</div>
					</a>
				</li>
				
				<!--<li>
					<a class="has-arrow" href="javascript:;">
						<div class="parent-icon icon-color-10"><i class="bx bx-credit-card"></i>
						</div>
						<div class="menu-title">Transaction Details</div>
					</a>
					<ul>
						<li> <a href="javascript:;"><i class="bx bx-right-arrow-alt"></i>Offline</a></li>
                        <li> <a href="javascript:;"><i class="bx bx-right-arrow-alt"></i>Online</a></li>
					</ul>
				</li>-->
                <li>
					<a href="sold-tickets.php">
						<div class="parent-icon icon-color-4"> <i class="bx bx-shopping-bag"></i>
						</div>
						<div class="menu-title" style="color: white;">Sold Tickets</div>
					</a>
				</li>
                <li>
					<a href="javascript:;">
						<div class="parent-icon icon-color-5"> <i class="bx bx-reply-all"></i>
						</div>
						<div class="menu-title" style="color: white;">Refund Tickets</div>
					</a>
				</li>
                <li>
					<a href="wallet_history.php">
						<div class="parent-icon icon-color-6"> <i class="bx bx-user"></i>
						</div>
						<div class="menu-title" style="color: white;">Accounts</div>
					</a>
				</li>
                <li>
					<a href="contact.php">
						<div class="parent-icon icon-color-7"> <i class="bx 
bx-phone-call"></i>
						</div>
						<div class="menu-title" style="color: white;">Contact Us</div>
					</a>
				</li>
                <li>
					<a href="logout.php">
						<div class="parent-icon icon-color-2"> <i class="bx 
bx-log-out"></i>
						</div>
						<div class="menu-title" style="color: white;">Logout</div>
					</a>
				</li>
                
				
				
			</ul>
			<!--end navigation-->
		</div>