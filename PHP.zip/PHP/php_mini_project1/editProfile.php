<?php
session_start();
include "connect.php";

if(isset($_REQUEST['update']) && $_REQUEST['update'] == 0){
    echo "<font color='red'> profile is not updated</font>";
}

$id=$_SESSION['id'];
$sql=mysqli_query($conn,"SELECT * from user where id=".$id);
$data = mysqli_fetch_assoc($sql);
//echo "<pre>";
//print_r($data);
$skill=explode(',', $data['skill']);
?>
<form action="editProfile_action.php" method="POST" enctype="multipart/form-data" >
<h1>Update Profile</h1><br>

    Name:<input type="text" name='user' value="<?php echo $data['name'];?>" ><br>

    Email:<input type="email" name='email' value="<?php echo $data['email'] ?>" readonly>
    <br>
   
    Address:<textarea name='address' rows='5' cols='10'><?php echo $data['address'];?></textarea><br>

    Number:<input type="number" name='phone' value="<?php echo $data['contact'];?>"><br>

    Gender:<input type="radio" name="gen" value="male" <?php echo $data['gender']=='male'?'checked':''?>>Male
           <input type="radio" name="gen" value="female" <?php echo $data['gender']=='female'?'checked':''?>>Female <br>

    Skill:<input type="checkbox" name="skill[]" value="php" <?php echo in_array('php',$skill)?'checked':''?> >PHP
          <input type="checkbox" name="skill[]" value="android" <?php echo in_array('android', $skill)?'checked':''?>>ANDROID
          <input type="checkbox" name="skill[]" value="iphone"  <?php echo in_array('iphone', $skill)?'checked':''?>>IPHONE 
          <input type="checkbox" name="skill[]" value="java" <?php echo in_array('java',$skill)?'checked':''?>>JAVA <br>

  City:<select name="city">
	<option value="">Select</option>
	<option value="kolkata" <?php echo $data['city']=='kolkata'?'selected':''?> >Kolkata</option>
	<option value="mumbai" <?php echo $data['city']=='mumbai'?'selected':''?>>Mumbai</option>
	<option value="delhi" <?php echo $data['city']=='delhi'?'selected':''?>>Delhi</option>
	<option value="chennai" <?php echo $data['city']=='chennai'?'selected':''?>>Chennai</option>
    </select><br>

    File:<input type="file" id="fle" name='file'><br>
    <img src="<?php echo $data['file']; ?>" height="100px" width="75px"><br>

    <input type="reset" value='Reset'>
    <input type="submit" value='update'>
</form>