<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   
   class adminController extends CI_Controller 
   {
   	function __construct()
   	{
   		parent::__construct();
   		// $this->load->database();
   		$this->load->model('User');
   	}
   
   	public function index()
   	{	
   		$this->load->model('User');
   		$data['test']=$this->User->get_data();
   
   		// $this->load->view('include/header');
   		// $this->load->view('include/sidebar');
   		$this->load->view('adminView', $data);
   		// $this->load->view('include/footer');
   		
   	}
   
   	public function edit()
   	{
   		 $id=$this->uri->segment(3); 
   		 $this->load->model('User');
   		 $data['user']= $this->User->get_data($id);
   		 
   		 // echo "<pre>";
   		 // print_r($data);die();

//---------------------- adding update form to fetch data in form------------------------
   

   		// $this->load->view('include/header');
   		// $this->load->view('include/sidebar');
   		$this->load->view('updateData',$data);
   		// $this->load->view('admin_user_add', $data);
   		// $this->load->view('include/footer');
   
   	}
   
   	public function update_user() 
   	{   
   
   	 $id=$this->input->post('id');
   
   
   //----------------------file upload code------------------
   
   
       if(!empty($_FILES['file']['name']))
       {
              $config['upload_path'] = 'uploads/';
              $config['allowed_types'] = 'jpg|jpeg|png|gif';
              $config['file_name'] = $_FILES['file']['name'];
                   
                   //Load upload library and initialize configuration
              $this->load->library('upload',$config);
              $this->upload->initialize($config);
                   
              if($this->upload->do_upload('file'))
                {
                 $uploadData = $this->upload->data();
                 $picture = $uploadData['file_name'];
                }
              else
               {
                  $picture = '';
               }
        }
        // else
        // {
        //     $picture = '';
        // }
   
   //-------------------file upload code end here----------------------------------------
   
   
     if($_FILES['file']['name']!='')
     {
      $data = array(
           // 'table_name' => 'admin_user', // pass the real table name
           'first_name' => strip_tags($this->input->post('first_name')), 
           'last_name' => strip_tags($this->input->post('last_name')), 
           'gender' => $this->input->post('gender'), 
           'phone' => strip_tags($this->input->post('phone')),
           'file' => strip_tags($_FILES['file']['name'])
           );
     }
     else
     {
      $data = array(
           // 'table_name' => 'admin_user', // pass the real table name
           'first_name' => strip_tags($this->input->post('first_name')), 
           'last_name' => strip_tags($this->input->post('last_name')), 
           'gender' => $this->input->post('gender'), 
           'phone' => strip_tags($this->input->post('phone'))
       );
     }
   
       
   
       // echo "<pre>";
       // print_r($data);die();
   
       $this->load->model('User');
   
       if($this->User->upddata($data,$id)) 
       {  
           // echo("update successful");
           redirect('adminController');
   
       }
       else
       {
           echo("update not successful");
       }
   
   }
   
   	public function delete_row($id='')
   	{  
   		$this->load->model('User');
   		$id=$this->uri->segment(3);
   	    $this->User->delete_data($id);
   	    redirect('adminController');
   	}


  public function edit_status()
  {
    // print_r($_POST);die();

    $id= $this->input->post('id'); 
    $status = $this->input->post('status');
    
     $this->load->model('User');
   
       if($this->User->update_status($status,$id)) 
       {  
           echo '1';
       }
       else
       {
           echo '0';
       }
    
  }

   
   }
   
   ?>