<form action="oop_log_action.php" method="POST" enctype="multipart/form-data" >
   Email:<input type="text" id="email" name='email' id='mail' ><br>
   Password:<input type="password" id="password" name='password' id='pass'><br>
    <input type="reset" value='Reset'>
    <input type="submit" value='Login'>
</form>