<?php
include 'connect.php';

$name = $_REQUEST['user'];
$email = $_REQUEST['email'];
$password = md5($_REQUEST['password']);
$address = $_REQUEST['address'];
$number = $_REQUEST['phone'];
$skill= implode(',', $_REQUEST['skill']);
$gender= $_REQUEST['gen'];
$experience_in_year= $_REQUEST['exp'];
$experience_or_fresher= $_REQUEST['expe'];
$type= $_REQUEST['type'];
$city= $_REQUEST['city'];

$filename = $_FILES['file']['name'];
$tmpName = $_FILES['file']['tmp_name'];
$destination = 'uploads/'.rand().$filename;
move_uploaded_file($tmpName, $destination);

$check_email = mysqli_query($conn, "SELECT * FROM user WHERE email ='".$email."'");

if(mysqli_num_rows($check_email) == 0){

$sql ="INSERT INTO user VALUES('','$name','$email','$password','$address','$number','$skill','$gender','$experience_in_year','experience_or_fresher','type','$city','$destination','$login_status')";
//echo $sql; exit;
 $rs=mysqli_query($conn,$sql);

if($rs){
	// echo "<font color='green'>Registation Successfull</font>";
	 header("location:login.php?reg=1");
 
}else
{
	// echo "<font color='red'>Registation Unsuccessfull</font>";
    header("location:registration.php?reg=0");
}
}
else
{
   header("location:registration.php?reg=2");
}

?>