<?php 
include_once ("z_db.php");
// Inialize session
include("Auth.php");
?>
<!DOCTYPE html>
<html lang="en">


<head>
	<?php include("headercss.php");?>
   
</head>

<body>
<div class="main-menu">
	<?php 
		include("header.php");
	?>
	<!-- /.header -->
	<?php 
		include("sidemenu.php");
	?>
	<!-- /.content -->
</div>
<!-- /.main-menu -->


<!-- /.fixed-navbar -->


<!-- /#notification-popup -->


<!-- /#message-popup -->
<?php include("uppernav.php");?>
<!-- #color-switcher -->

<div id="wrapper">
	<div class="main-content">
		<div class="row small-spacing">
			
			<!-- /.col-xs-12 -->
            <div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content">
					<div class="statistics-box with-icon">
						<i class="ico fa fa-users text-primary"></i>
						<h2 class="counter text-primary">
                        	<?php $qre = mysqli_query($con,"select * from tempusermaster");
								echo mysqli_num_rows($qre);
							?>
                        </h2>
						<p class="text">Total Agent</p>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
            
            <div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content">
					<div class="statistics-box with-icon">
						<i class="ico fa fa-users text-primary"></i>
						<h2 class="counter text-primary">
                        	<?php $qre = mysqli_query($con,"select * from airline_flight_no_master");
								echo mysqli_num_rows($qre);
							?>
                        </h2>
						<p class="text">Total Flights</p>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
            <div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content">
					<div class="statistics-box with-icon">
						<i class="ico fa fa-users text-primary"></i>
						<h2 class="counter text-primary">
                        	<?php $qre = mysqli_query($con,"select * from airline_master");
								echo mysqli_num_rows($qre);
							?>
                        </h2>
						<p class="text">Total Airlines</p>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
            <div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content">
					<div class="statistics-box with-icon">
						<i class="ico fa fa-users text-primary"></i>
						<h2 class="counter text-primary">
                        	<?php $qre = mysqli_query($con,"select * from destination_master");
								echo mysqli_num_rows($qre);
							?>
                        </h2>
						<p class="text">Total Destination</p>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
            <div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content">
					<div class="statistics-box with-icon">
						<i class="ico fa fa-google-wallet text-primary"> </i>
						<h2 class="counter text-primary">
                        	<?php $qre = mysqli_query($con,"select * from tempusermaster");
								echo mysqli_num_rows($qre);
							?>
                        </h2>
						<p class="text">Today Total Wallet topup</p>
					</div>
				</div>
				<!-- /.box-content -->
			</div> 
			<div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content">
					<div class="statistics-box with-icon">
						<i class="ico fa fa-ticket text-primary" > </i>
						<h2 class="counter text-primary">
                        	<?php $qre = mysqli_query($con,"select * from tempusermaster");
								echo mysqli_num_rows($qre);
							?>
                        </h2>
						<p class="text">Today Total booking</p>
					</div>
				</div>
				<!-- /.box-content -->
			</div>
			<div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content">
					<div class="statistics-box with-icon">
						<i class="ico fa fa-ticket text-primary"> </i>
						<h2 class="counter text-primary">
                        	<?php $qre = mysqli_query($con,"select * from tempusermaster");
								echo mysqli_num_rows($qre);
							?>
                        </h2>
						<p class="text">Total booking</p>
					</div>
				</div>
				<!-- /.box-content -->
			</div>  
			<div class="col-lg-3 col-md-6 col-xs-12">
				<div class="box-content">
					<div class="statistics-box with-icon">
						<i class="ico fa fa-google-wallet text-primary"> </i>
						<h2 class="counter text-primary">
                        	<?php $qre = mysqli_query($con,"select * from tempusermaster");
								echo mysqli_num_rows($qre);
							?>
                        </h2>
						<p class="text">today total due</p>
					</div>
				</div>
				<!-- /.box-content -->
			</div> 
            
            
            
            
		</div>
		<!-- /.row -->		
		<?php include("footer.php"); ?>
	</div>
	<!-- /.main-content -->
</div><!--/#wrapper -->
	<?php include("footerjs.php"); ?>
     <script type="application/javascript" src="canvasjs.min.js"></script>
</body>


</html>