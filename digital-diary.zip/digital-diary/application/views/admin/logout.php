<!DOCTYPE html>
<html>
<head>
	<title>logout</title>
</head>
<body>
<input type="submit" name="submit" value="Logout">
</body>
</html>