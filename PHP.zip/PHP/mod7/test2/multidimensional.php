<?php
$ar= array(
array('10','20','30','40'),
array('1'=>'Blue','2'=>'Yellow','3'=>'Black','2'=>'White')
);
echo "<pre>";
print_r($ar);

?>