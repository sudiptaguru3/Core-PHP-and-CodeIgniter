<?php 
	include("z_db.php");
	include("Auth.php");
	if(isset($_POST['search'])){
		
		$airline=mysqli_real_escape_string($con,trim($_POST['airline']));
		$infant=mysqli_real_escape_string($con,trim($_POST['infant']));
		$child=mysqli_real_escape_string($con,trim($_POST['child']));
		$adult=mysqli_real_escape_string($con,trim($_POST['adult']));
		$date=mysqli_real_escape_string($con,trim($_POST['date']));
		$destination=mysqli_real_escape_string($con,trim($_POST['destination']));
		
		$qty = $child+$adult;
		$data_table = "";
		
		unset($_SESSION['des']);
		unset($_SESSION['dt']);
		unset($_SESSION['ad']);
		unset($_SESSION['ch']);
		unset($_SESSION['inf']);
		unset($_SESSION['ttl']);
		
		$_SESSION['des']=$destination;
		$_SESSION['dt']=$date;
		$_SESSION['ad']=$adult;
		$_SESSION['ch']=$child;
		$_SESSION['inf']=$infant;
		$_SESSION['qty']=$qty;
		
		
		if($airline == "all")
		{
			$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM `ticket_master` t where available_seat>='$qty' and  flight_id in (select id from airline_flight_no_master where destination_id='$destination' ) and flight_date='$date') j ) f");	
		}
		else
		{
			$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM ticket_master t where available_seat>='$qty' and airline_id='$airline' and flight_id in (select id from airline_flight_no_master where destination_id='$destination' and airline_id='$airline') and flight_date='$date') j ) f");	
		}
		
		if(mysqli_num_rows($qre)>0)
		{
			while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
			{
				$ttl = $res["price"]*$qty;
				if($infant>0)
				{
					$ttl = $ttl+1500;	
				}
				$data_table .="<tr>";
				$data_table .="<td><img src='2021/productimg/".$res["airline_logo"]."' width='70' height='70' alt=' ' /></td>";
				$data_table .="<td><strong>".$res["from_city_name"]." to ".$res["to_city_name"]."</strong></td>";
				$data_table .="<td><strong>".$res["flight_number"]."</strong></td>";
				$data_table .="<td><strong>".$date."</strong></td>";
				$data_table .="<td><strong>".$res["dep_hour"]." : ".$res["dep_mint"]."</strong></td>";
				$data_table .="<td><strong>".$res["arrival_hour"]." : ".$res["arrival_mint"]."</strong></td>";
				$data_table .="<td><strong>".$qty."</strong></td>";
				$data_table .="<td><strong>".$res["available_seat"]."</strong></td>";
				$data_table .="<td><strong>".$ttl."</strong></td>";
				$data_table .="<td><a href='proceed-booking.php?sol=".$res["id"]."' class='btn btn-success'>Book Now</a></td>";
				$data_table .="</tr>";				
			}
		}	
		else
		{
			echo "<script>alert('No Flight Found');window.location='dashboard.php';</script>";
		}
	}
?>

<!DOCTYPE html>
<html lang="en">


<?php include("headercss.php");?>
  <link href="http://www.jquerycookbook.com/demos/css/jquery-ui.css" rel="stylesheet" />
  <style type="text/css">
	.tbl tr th
	{
		padding:5px !important;	
	}
	.popup {
    width:100%;
    height:100%;
    display:none;
    position:fixed;
    top:0px;
    left:0px;
    background:rgba(0,0,0,0.75);
}
 
/* Inner */
.popup-inner {
    max-width:500px;
    width:90%;
    padding:40px;
    position:absolute;
    top:50%;
    left:50%;
    -webkit-transform:translate(-50%, -50%);
    transform:translate(-50%, -50%);
    box-shadow:0px 2px 6px rgba(0,0,0,1);
    border-radius:3px;
    background:#fff;
}
 
/* Close Button */
.popup-close {
    width:30px;
    height:30px;
    padding-top:4px;
    display:inline-block;
    position:absolute;
    top:0px;
    right:0px;
    transition:ease 0.25s all;
    -webkit-transform:translate(50%, -50%);
    transform:translate(50%, -50%);
    border-radius:1000px;
    background:rgba(0,0,0,0.8);
    font-family:Arial, Sans-Serif;
    font-size:20px;
    text-align:center;
    line-height:100%;
    color:#fff;
}
 
.popup-close:hover {
    -webkit-transform:translate(50%, -50%) rotate(180deg);
    transform:translate(50%, -50%) rotate(180deg);
    background:rgba(0,0,0,1);
    text-decoration:none;
}
.popup {
    background:rgba(0,0,0,0.75);
}
.popup-inner {
    position:absolute;
    top:50%;
    left:50%;
    -webkit-transform:translate(-50%, -50%);
    transform:translate(-50%, -50%);
}
.popup-close {
    transition:ease 0.25s all;
    -webkit-transform:translate(-50%, -50%);
    transform:translate(50%, -50%);
}
.popup-close:hover {
    -webkit-transform:translate(50%, -50%) rotate(180deg);
    transform:translate(50%, -50%) rotate(180deg);
    background:rgba(0,0,0,1);
}
</style>

<body>

	<!-- wrapper -->
	<div class="wrapper">
		<!--sidebar-wrapper-->
		<?php include("sidemenu.php");?>
		<!--end sidebar-wrapper-->
		<!--header-->
		<?php include("header.php");?>
		<!--end header-->
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					
					<!--end row-->
					
					<!--end row-->
					
					<!--end row-->
					
					<!--end row-->
					
					<div class="card radius-15" style="background-color:  #952EAA;">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0"><a style="color: white;">Search Flight</a></h5>
							</div>
							<hr/>
							<div class="table-responsive">
                            	<form action="" method="">
                            	<div class="row">
									<div class="col-12 col-lg-12 col-xl-6">
                                    	<label for="validationServer01"><strong><a style="color: white;">Destination</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-map"></i></span>
                                            </div>
                                            <select class="form-control" name="destination" id="destination" required onChange="make_date();" id="destination">
                                                <option value="">--Select Destination--</option>
                                                <?php 
													$data = "";
													$qre = mysqli_query($con,"SELECT *,(SELECT city_name from airport_master where id=d.from_city)city_name1,(SELECT city_name from airport_master where id=d.to_city)city_name2 FROM `destination_master` d where isactive='1' and id in (select destination_id from airline_flight_no_master where id in (select flight_id from ticket_master where isexpire='0' and isactive='1'))");
													if(mysqli_num_rows($qre)>0)
													{
														while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
														{
															if($destination==$res["id"])
															{
																$data .="<option value='".$res["id"]."' selected>".$res["city_name1"]." to ".$res["city_name2"]."</option>";
															}
															else
															{
																$data .="<option value='".$res["id"]."'>".$res["city_name1"]." to ".$res["city_name2"]."</option>";
															}
															
														}
													}
													echo $data;
												?>
                                            </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-12 col-xl-6">
                                    	<label for="validationServer01"><strong><a style="color: white;">Travel Date</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-calendar-alt"></i></span>
                                            </div>
                                            <input type="text" class="form-control" id="datepicker" value="<?php echo $date;?>" required name="date"  placeholder="Travel Date">
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-12 col-lg-12 col-xl-2">
                                    	<label for="validationServer01"><strong><a style="color: white;">Adults(12+Yrs)</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                            </div>
                                            <select class="form-control" name="adult" id="adult" required>
                                                <option value="0">0</option>
                                                <option value="1" selected>1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                            </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-12 col-xl-2">
                                    	<label for="validationServer01"><strong><a style="color: white;">Child(2-12Yrs)</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                            </div>
                                            <select class="form-control" name="child" id="child" required>
                                                <option value="0">0</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                             </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-12 col-xl-2">
                                    	<label for="validationServer01"><strong><a style="color: white;">Infant(0-2Yrs)</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                            </div>
                                            <select class="form-control" name="infant" id="infant" required>
                                                <option value="0">0</option>
                                                <option value="1">1</option>
                                             </select>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-12 col-lg-12 col-xl-6">
                                    	<label for="validationServer01"><strong><a style="color: white;">Airlines</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="lni lni-plane"></i></span>
                                            </div>
                                            <select class="form-control" name="airline" id="airline" required>
                                                 <option value="all">ALL</option>
                                                 
                                                 <?php 
													$data = "";
													$qre = mysqli_query($con,"SELECT * FROM airline_master d where isactive='1'");
													if(mysqli_num_rows($qre)>0)
													{
														while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
														{
															if($airline==$res["id"])
															{
																$data .="<option selected value='".$res["id"]."'>".$res["airline"]."</option>";
															}
															else
															{
																$data .="<option value='".$res["id"]."'>".$res["airline"]."</option>";
															}
															
														}
													}
													echo $data;
												?>
                                            </select>
                                            
                                        </div>
                                    </div>
                                   <div class="row" style="width:100%;">
                                   		<div class="col-sm-4" align="left">
                                        	&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-arrow-left" style="font-size:48px;color:white;cursor:pointer;" onClick="Left_Icon();"></i>
                                        </div>
                                        <div class="col-sm-4" align="center">
                                        	<!--<input type="submit" class="btn btn-success" value="Search" onClick="view_flight();" name="search">-->
                                            <a href="javascript:void(0);" onClick="view_flight();" class="btn btn-success">Search</a>
                                        </div>
                                        <div class="col-sm-4" align="right">
                                        	<i class="fa fa-arrow-right" style="font-size:48px;color:white;cursor:pointer;" onClick="Right_Icon();"></i>
                                        </div>
                                   </div>
                                    <!--<div class="col-12 col-lg-12 col-xl-8" style="float: left; border: 1px solid silver;">
                                    	<a class="input-group mb-3" style="float: left;">
                                            
                                            
                                            
                                        </a>
                                        
                                    </div>
                                    
                                    <div class="input-group mb-3" style="margin-left: 100px;">
                                        	
                                        </div>-->
                                    
                                    <!-- <div class="col-12 col-lg-12 col-xl-4" style="border: 1px solid #000;">
                                    	<div class="input-group mb-3" style="border: 1px solid #000;float: right;">
                                            
                                            <div align="right"><i class="fa fa-arrow-right" style="font-size:48px;color:green"></i></div>
                                            
                                        </div>
                                    </div>  -->
                                    
                                </div>
                                <!-- <i class="fa fa-arrow-right" style="font-size:48px;color:green;float: right"></i> -->
                                </form>    
                            	
                            
								
							</div>
						</div>
					</div>
                    <?php 
						//if($data_table!="")
						//{?>
								<div class="card radius-15" id="show_div" style="display:none;">
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h5 class="mb-0">Flight Result</h5>
                                        </div>
                                        <hr/>
                                        <div class="table-responsive">
                                            <table class="table mb-0">
                                                <thead class="thead-dark">
                                                    <tr>
                                                        <th>Airlines</th>
                                                        <th>Destination</th>
                                                        <th>Flight No</th>
                                                        <th>Date</th>
                                                        <th>Dep</th>
                                                        <th>Arr</th>
                                                        <th>Qty.</th>
                                                        <th>Available Seat(s)</th>
                                                        <th>Deal</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                                <tbody id="table_data">
                                                    <?php //echo $data_table;?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
						<?php //}
					?>
                    
                    
                    
                    
                    
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<!--footer -->
		<div class="footer">
			<p class="mb-0">WION TRIP @2021 | Developed By : <a href="http://happyweb.in/" target="_blank">Happy Web</a>
			</p>
		</div>
		<!-- end footer -->
	</div>
	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<?php include("footerjs.php");?>
    <script src="http://www.jquerycookbook.com/demos/scripts/jquery-1.11.1.min.js"></script>
    <script src="http://www.jquerycookbook.com/demos/scripts/jquery-ui.min.js"></script>
  <script>
	
/*var dates = ["05-02-2021", "06-02-2021", "07-02-2021", "09-02-2021"];
 
function DisableDatess(date) {
	
    var string = jQuery.datepicker.formatDate('dd-mm-yy', date);
    return [dates.indexOf(string) == -1];
}


$(document).ready(function () {
	
});*/
function Left_Icon()
{
	var airline = $("#airline").val();
	var infant = $("#infant").val();
	var child = $("#child").val();
	var adult = $("#adult").val();
	var date = $("#datepicker").val();
	var destination = $("#destination").val();
	
	if(airline!="" && airline!="0" && date!="")
	{
		$("#suges").fadeIn(350);
		$.ajax({ //make ajax request to cart_process.php
		url: "pst.php",
		type: "POST",
		dataType:"json", //expect json value from server
		data: {'typ':'left', 'airline': airline,'infant': infant,'child': child,'adult': adult,'date': date,'destination': destination}
		}).done(function(data){ //on Ajax success
				
				if(data.items=="NOTOK")
				{
					alert(data.msg);
					window.location='dashboard.php';
				}
				else
				{
					$("#datepicker").val(data.dt);
					$("#show_div").show();
					$("#table_data").empty();
					$("#table_data").html(data.items);
				}
				 closess1();
				
					
		});
	}
}
function Right_Icon()
{
	var airline = $("#airline").val();
	var infant = $("#infant").val();
	var child = $("#child").val();
	var adult = $("#adult").val();
	var date = $("#datepicker").val();
	var destination = $("#destination").val();
	
	if(airline!="" && airline!="0" && date!="")
	{
		$("#suges").fadeIn(350);
		$.ajax({ //make ajax request to cart_process.php
		url: "pst.php",
		type: "POST",
		dataType:"json", //expect json value from server
		data: {'typ':'right', 'airline': airline,'infant': infant,'child': child,'adult': adult,'date': date,'destination': destination}
		}).done(function(data){ //on Ajax success
				
				if(data.items=="NOTOK")
				{
					$("#show_div").hide();
					alert(data.msg);
					window.location='dashboard.php';
				}
				else
				{
					$("#datepicker").val(data.dt);
					$("#show_div").show();
					$("#table_data").empty();
					$("#table_data").html(data.items);	
				}
				 closess1();
				
					
		});
	}
}
function view_flight()
{
	var airline = $("#airline").val();
	var infant = $("#infant").val();
	var child = $("#child").val();
	var adult = $("#adult").val();
	var date = $("#datepicker").val();
	var destination = $("#destination").val();
	
	if(airline!="" && airline!="0" && date!="")
	{
		$("#suges").fadeIn(350);
		$.ajax({ //make ajax request to cart_process.php
		url: "pst.php",
		type: "POST",
		dataType:"json", //expect json value from server
		data: { 'airline': airline,'infant': infant,'child': child,'adult': adult,'date': date,'destination': destination}
		}).done(function(data){ //on Ajax success
				
				if(data.items=="NOTOK")
				{
					$("#show_div").hide();
					alert(data.msg);
					window.location='dashboard.php';
				}
				else
				{
					$("#show_div").show();
					$("#table_data").empty();
					$("#table_data").html(data.items);	
				}
				 closess1();
				
					
		});
	}
}
function make_date()
{
	var dest = $("#destination").val();
	
	if(dest>0)
	{
		$("#suges").fadeIn(350);
		$("#datepicker").datepicker("destroy");
		
		$.ajax({ //make ajax request to cart_process.php
		url: "pst.php",
		type: "POST",
		dataType:"json", //expect json value from server
		data: { 'dest': dest}
		}).done(function(data){ //on Ajax success
			
			$("#datepicker").datepicker({
				
				dateFormat:"d-m-yy",
				beforeShowDay: function(date) {
				var dd = date.getDate();
				var mm = date.getMonth()+1; //January is 0!
				var yyyy = date.getFullYear();
				//alert(text);
				var shortDate = dd+'-'+mm+'-'+yyyy;
				var test = "20-2-2021";
				
				var my_array = new Array('20-2-2021', '22-2-2021');
				
				//$('#d1').append(in_date+'<br>') 
				if (data.items.indexOf(shortDate) >= 0) { 
					return [true, "av", "available"]; 
				} else { 
					return [false, "notav", 'Not Available']; 
					
				} 
				
				/*if (shortDate == test) {
					
					return [false, "" ];
				} else {
					return [true, "" ];
				}*/
			}
		 });
		 closess1();
			
		});
		
		$( "#datepicker" ).datepicker("refresh");
	}
}

function closess1()
{
	$("#suges").fadeOut(350);
}

  /*function make_date()
  {
	var dest = $("#destination").val();
	if(dest>0)
	{
		$.ajax({ type: "GET",   
		 url: "pst.php?dest="+dest,   
		 async: false,
		 success : function(text)
		 {
					
							$("#datepicker").datepicker({
					 		minDate: 0,
							dateFormat:"d-m-yy",
						 	beforeShowDay: function(date) {
							var dd = date.getDate();
							var mm = date.getMonth()+1; //January is 0!
							var yyyy = date.getFullYear();
							//alert(text);
							var shortDate = dd+'-'+mm+'-'+yyyy;
							var test = "20-2-2021";
							
							var my_array = new Array('20-2-2021', '22-2-2021'); 
							//$('#d1').append(in_date+'<br>') 
							if (my_array.indexOf(text) >= 0) { 
								return [false, "notav", 'Not Available']; 
							} else { 
								return [true, "av", "available"]; 
							} 
							
							if (shortDate == test) {
								
								return [false, "" ];
							} else {
								return [true, "" ];
							}
						}
					 });
				
		 }
		});
	}

  }*/
  
  
 /* $( function() {
   $( "#datepicker" ).datepicker({ minDate: 0 ,dateFormat:"d-m-yyyy",maxDate: new Date('02-02-2012','03-02-2021')});
  } );*/
  </script>
  
  
  <div class="popup" id="suges" data-popup="popup-1">
    <div class="popup-inner">
    	<img src="ajax-loader.gif" />
        <!--<h2>Feed Back</h2>-->
        	
        <!--<p><a data-popup-close="popup-1" href="javascript:void(0);" onClick="closess1();" id="close">Close</a></p>
        <a class="popup-close" data-popup-close="popup-1" onClick="closess1();" id="xross" href="javascript:void(0);">x</a>-->
    </div>
</div>
  
	
	
</body>


</html>