<?php
echo "<h2> Addition is here </h2> <br>";
$a="Php";
$b="<b> Design </b>";
print "This is ".$a.$b;

echo "<br>";

$x=10;
$y=15;
$z=$x+$y;
echo "<br>".$z;
?>