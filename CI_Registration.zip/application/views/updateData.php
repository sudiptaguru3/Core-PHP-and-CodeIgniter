
 <div class="container">
 
 <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Update Data</h1>
          </div>
          
        </div>
      </div><!-- /.container-fluid -->
    </section>

<section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Create User</h3>
          </div>
          <!-- /.card-header -->
          <form action="<?php echo base_url('adminController/update_user'); ?>" method="post"  enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $this->uri->segment(3); ?>">
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="">First Name</label>
                    <input type="" class="form-control" id="" name="first_name" placeholder="Enter First Name" value="<?php echo $user[0]->first_name; ?>">
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                   <label for="">Last Name</label>
                    <input type="" class="form-control" id="" name="last_name" placeholder="Enter Last Name" value="<?php echo $user[0]->last_name; ?>">
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                   <label for="">Contact Number</label>
                    <input type="" class="form-control" id="" name="phone" placeholder="Enter Contact Number" value="<?php echo $user[0]->phone; ?>">
                  </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
            <label>Gender: </label>
                <?php 
                if(!empty($user['gender']) && $user['gender'] == 'Female'){ 
                    $fcheck = 'checked="checked"'; 
                    $mcheck = ''; 
                }else if(!empty($user['gender']) && $user['gender'] == 'Male'){ 
                    $mcheck = 'checked="checked"'; 
                    $fcheck = ''; 
                }else{
                    $mcheck = ''; 
                    $fcheck = '';
                }

                ?> 
                <div class="radio">
                <label>
                        <input type="radio" name="gender" value="Male" 
                        <?php set_radio('gender', 'Male'); ?>
                        <?php echo $mcheck;?>
                        >

                        Male
                </label>
                <label>
                        <input type="radio" name="gender" value="Female" 
                        <?php set_radio('gender', 'Female'); ?>
                        <?php echo $fcheck;?>>
                        Female
                </label>
                <span style='color:red'><?php echo form_error('gender'); ?>
            </span>
                </div>

        </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="profile_pic">Profile Picture</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <!-- <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic" onchange ="show_pictures(this.value)"> -->
                        <input type="file" class="custom-file-input" id="filefile" name="file"  onchange="readURL(this);" value="">
                        <label class="custom-file-label" for="file">Choose file</label>
                      </div>
                    </div>
                  </div>
              </div>
                        <?php if($user[0]->file!='') {?>
                        <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('uploads/'.$user[0]->file); ?>" id="image_disp" class="img-thumbnail">
                <?php } else {?>
                  <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('asset/banner/180.png'); ?>" id="image_disp" class="img-thumbnail">
                <?php } ?>
            </div>
            <div class="card-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
          </div>
          </form>       
        </div>
</div>        
</section>
</div> 


<!-------------- image showing just after uploading------------------- -->

<script type="text/javascript">
       function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#image_disp')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>