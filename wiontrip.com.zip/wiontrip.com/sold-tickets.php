<?php 
	include("z_db.php");
	include("Auth.php");
	/*if(isset($_POST['search'])){
		
		$airline=mysqli_real_escape_string($con,trim($_POST['airline']));
		$infant=mysqli_real_escape_string($con,trim($_POST['infant']));
		$child=mysqli_real_escape_string($con,trim($_POST['child']));
		$adult=mysqli_real_escape_string($con,trim($_POST['adult']));
		$date=mysqli_real_escape_string($con,trim($_POST['date']));
		$destination=mysqli_real_escape_string($con,trim($_POST['destination']));
		
		$qty = $child+$adult;
		$data_table = "";
		
		unset($_SESSION['des']);
		unset($_SESSION['dt']);
		unset($_SESSION['ad']);
		unset($_SESSION['ch']);
		unset($_SESSION['inf']);
		unset($_SESSION['ttl']);
		
		$_SESSION['des']=$destination;
		$_SESSION['dt']=$date;
		$_SESSION['ad']=$adult;
		$_SESSION['ch']=$child;
		$_SESSION['inf']=$infant;
		$_SESSION['qty']=$qty;
		
		
		if($airline == "all")
		{
			$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM `ticket_master` t where available_seat>='$qty' and  flight_id in (select id from airline_flight_no_master where destination_id='$destination' ) and flight_date='$date') j ) f");	
		}
		else
		{
			$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM ticket_master t where available_seat>='$qty' and airline_id='$airline' and flight_id in (select id from airline_flight_no_master where destination_id='$destination' and airline_id='$airline') and flight_date='$date') j ) f");	
		}
		
		if(mysqli_num_rows($qre)>0)
		{
			while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
			{
				$ttl = $res["price"]*$qty;
				if($infant>0)
				{
					$ttl = $ttl+1500;	
				}
				$data_table .="<tr>";
				$data_table .="<td><img src='2021/productimg/".$res["airline_logo"]."' width='70' height='70' alt=' ' /></td>";
				$data_table .="<td><strong>".$res["from_city_name"]." to ".$res["to_city_name"]."</strong></td>";
				$data_table .="<td><strong>".$res["flight_number"]."</strong></td>";
				$data_table .="<td><strong>".$date."</strong></td>";
				$data_table .="<td><strong>".$res["dep_hour"]." : ".$res["dep_mint"]."</strong></td>";
				$data_table .="<td><strong>".$res["arrival_hour"]." : ".$res["arrival_mint"]."</strong></td>";
				$data_table .="<td><strong>".$qty."</strong></td>";
				$data_table .="<td><strong>".$res["available_seat"]."</strong></td>";
				$data_table .="<td><strong>".$ttl."</strong></td>";
				$data_table .="<td><a href='proceed-booking.php?sol=".$res["id"]."' class='btn btn-success'>Book Now</a></td>";
				$data_table .="</tr>";				
			}
		}	
		else
		{
			echo "<script>alert('No Flight Found');window.location='dashboard.php';</script>";
		}
	}*/
?>
<!DOCTYPE html>
<html lang="en">


<?php include("headercss.php");?>
  <link href="http://www.jquerycookbook.com/demos/css/jquery-ui.css" rel="stylesheet" />
  

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<!--sidebar-wrapper-->
		<?php include("sidemenu.php");?>
		<!--end sidebar-wrapper-->
		<!--header-->
		<?php include("header.php");?>
		<!--end header-->
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					
					<!--end row-->
					
					<!--end row-->
					
					<!--end row-->
					
					<!--end row-->
					
					
                    
                    <div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0">Sold Tickets</h5>
							</div>
							<hr/>
							<div class="table-responsive">
								<table class="table mb-0">
									<thead class="thead-dark">
										<tr>
											<th>#Ref No.</th>
											<th>Airline</th>
											<th>Travel Date</th>
											<th>PNR</th>
											<th>Sector</th>
                                            <th>Seat</th>
                                            <th>Amount</th>
                                            <th>Requested Date</th>
                                            <th>Cancel</th>
                                            <th>Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$qre = mysqli_query($con,"select *,(SELECT city_name from airport_master where id=m.from_city)city_name1,(SELECT city_name from airport_master where id=m.to_city)city_name2 from (select *,(select airline from airline_master where id=b.airline_id)airline,(select from_city from destination_master where id=b.destination_id)from_city,(select to_city from destination_master where id=b.destination_id)to_city from booking_master b where Msrno='".$_SESSION['MSRNO']."' ) m ");
											if(mysqli_num_rows($qre)>0)
											{
												while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
												{?>
													<tr>
                                                    	<td><?php echo $res["booking_PNR"];?></td>
                                                        <td><?php echo $res["airline"];?></td>
                                                        <td><?php echo $res["flight_date"];?></td>
                                                        <td><?php 
															if($res["PNR"]=="")
															{
																echo "Pending";
															}
															else
															{
																echo $res["PNR"];		
															}
														?></td>
                                                        <td><?php echo $res["city_name1"];?> To : <?php echo $res["city_name2"];?></td>
                                                        <td><?php echo $res["ticket"];?></td>
                                                        <td><?php echo $res["total_fare"];?></td>
                                                        <td><?php echo $res["ondate"];?></td>
                                                        <td>Cancel</td> 
                                                         <td>Print Invoice</td>
                                                    </tr>
												<?php }
											}
										?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                    
                    
                    
                    
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<!--footer -->
		<div class="footer">
			<p class="mb-0">WION TRIP @2021 | Developed By : <a href="http://happyweb.in/" target="_blank">Happy Web</a>
			</p>
		</div>
		<!-- end footer -->
	</div>
	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<?php include("footerjs.php");?>
    <script src="http://www.jquerycookbook.com/demos/scripts/jquery-1.11.1.min.js"></script>
    <script src="http://www.jquerycookbook.com/demos/scripts/jquery-ui.min.js"></script>
  <script>
	
/*var dates = ["05-02-2021", "06-02-2021", "07-02-2021", "09-02-2021"];
 
function DisableDatess(date) {
	alert(date);
    var string = jQuery.datepicker.formatDate('dd-mm-yy', date);
    return [dates.indexOf(string) == -1];
}
function make(date)
{
	alert(date);
}

$(document).ready(function () {
	alert(date);
});*/
 /* function make_date()
  {
	var dest = $("#destination").val();
	if(dest>0)
	{
		$.ajax({ type: "GET",   
		 url: "pst.php?dest="+dest,   
		 async: false,
		 success : function(text)
		 {
				
					 $("#datepicker").datepicker({
						 beforeShowDay: DisableDatess
					 });
				
		 }
		});
	}

  }*/
  $( function() {
   $( "#datepicker" ).datepicker({ minDate: 0 ,dateFormat:"dd-mm-yy",maxDate: new Date('02-02-2012','03-02-2021')});
  } );
  </script>
</body>


</html>