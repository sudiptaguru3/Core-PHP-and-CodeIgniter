<?php

class HomeController extends CI_Controller{
    
    public function index(){
        $this->load->view('addUser');
    }

    function registerUser(){
    $name=$this->input->post('user');
    $email=$this->input->post('email');
    $password=$this->input->post('password'); 
    $address=$this->input->post('address');
    $phone=$this->input->post('phone');
    $skills=$this->input->post('skill');
    if(!empty($skills)){
       $skill=implode(',',$skills);  
    }
    else{
        $skill='';
    }   
     
             $insertArray = [
                'name'=> $name,
                'email'=> $email,
                'password'=>$password,
                'address'=>$address,
                'phone'=>$phone,
                'skill'=>$skill
             ];
             
             
        $this->load->model('HomeModel');
        $status = $this->HomeModel->register($insertArray);

            if($status == true){
                $data['message'] = "
                 <font color='green'>
                 Successfully Data Inserted </font>";
            }else{
                $data['message'] = "
                <font color='red'>
                Please Try Again,Data is not inserted </font>";
            }
            $this->load->view('addUser',$data);
            redirect('HomeController/viewUser');
    }

    function viewUser(){
        $this->load->model('HomeModel');
        $data['userinfo'] = $this->HomeModel->getAllUsers();
        $this->load->view('viewUsers',$data);
    }
    
    function deleteUser(){

    $userId = $this->input->post('id');   
        $this->load->model('HomeModel');
        $status = $this->HomeModel->delete_user($userId);

        if($status == true){
            $data['message'] = "<font color='green'>Successfully Deleted</font>";
        }else{
            $data['message'] = "<font color='red'> Not deleted,Please Try Again </font>";
        }
        $data['userinfo'] = $this->HomeModel->getAllUsers();
        $this->load->view('viewUsers',$data);
    }

    function editUser($userId){
       
        $this->load->model('HomeModel');
        $data['user'] = $this->HomeModel->getSingleUser($userId);
        $this->load->view('updateForm',$data);
    }

    function updateUser(){
        $this->load->model('HomeModel');
        $skills=$this->input->post('skill');
        if(!empty($skills)){
       $skill=implode(',',$skills);  
    }
    else{
        $skill='';
    }  
            $setArray = [
                'name'=> $this->input->post('user'),
                'address'=>$this->input->post('address'),
                'phone'=>$this->input->post('phone'),
                'skill'=>$skill,       
            ];
            $userId = $this->input->post('userId');
            $status = $this->HomeModel->update_User($setArray,$userId);
            
            if($status == true){
                $data['message'] = "<font color='green'>
                Successfully Updated </font>";
            }else{
                $data['message'] = "<font color='red'> Not upadted,Please Try Again </font>";
            }
            $data['userinfo'] = $this->HomeModel->getAllUsers();
            $this->load->view('viewUsers',$data);
        
    }
}

?>