<form action="oop_reg_action.php" method="POST" enctype="multipart/form-data" >
    Name:<input type="text" id="user" name='user'><br><br>
    Email:<input type="text" id="email" name='email'><br><br>
    Password:<input type="password" id="password" name='password'><br><br>
    Phone Number:<input type="number" id="nmbr" name='phone'><br><br>
    File:<input type="file" id="fle" name='file'><br><br>
    <input type="reset" value='Reset'>
    <input type="submit" value='Submit'>
</form>