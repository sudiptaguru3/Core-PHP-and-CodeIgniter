
<?php
// function to get file extension
function get_extension($file) {
    $array = explode('.', $file);
    $extension = end($array);
    return $extension ? $extension : false;
}
 
$file_path = "/var/www/html/profile_picture.jpeg";
 
echo get_extension($file_path);
 
?>