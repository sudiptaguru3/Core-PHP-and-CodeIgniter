<?php
abstract class A{
	abstract function abc();
	function xyz(){
		echo "Ejob";
	}
}
class B extends A{
	function abc(){
		echo "PHP";
	}
}
$obj=new B();
$obj->xyz();
$obj->abc();
?>