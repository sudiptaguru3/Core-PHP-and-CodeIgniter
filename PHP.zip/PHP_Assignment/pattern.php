<?php
echo "<h1>Ttiangular pattern</h1> <br>";	
// for($i=0;$i<=5;$i++){
for ($i=1; $i<=5; $i++){	 
for($j=1;$j<=$i;$j++)	  
{
// echo "* ";	  	
echo $i." ";	 
}	  	
echo "<br/>";   	
} 
echo "<h1>n number of same value</h1> <br>";
function pypart($n) 
{ 
    for ($i = 0; $i < $n; $i++) 
    { 
        for($j = 0; $j <= $i; $j++ ) 
        { 
            echo "* "; 
        } 
        echo "\n"; 
    } 
} 
    $n = 5; 
    pypart($n); 

    echo "<h1>n number of real number</h1> <br>";
    for ($i=1; $i<=5; $i++){	   	
echo $i." ";	 	  	
   	
} 

echo "<h1>Ttiangular pattern1</h1> <br>";
for($i=0;$i<=5;$i++)
{  
for($j=5-$i;$j>=1;$j--)
{  
echo "* ";  
}  
echo "<br>";  
} 

echo "<h1>Trapigiam</h1> <br>";
echo "<pre>";
for ($i = 1; $i < 8; $i++) {
    for ($j = $i; $j < 8; $j++)
        echo "&nbsp;&nbsp;";
    for ($j = 2 * $i - 1; $j > 0; $j--)
        echo ("&nbsp;*");
    echo "<br>";
}
$n = 8;
for ($i = 8; $i > 0; $i--) {
    for ($j = $n - $i; $j > 0; $j--)
        echo "&nbsp;&nbsp;";
    for ($j = 2 * $i - 1; $j > 0; $j--)
        echo ("&nbsp;*");
    echo "<br>";
}
echo "</pre>";
?>
