<?php
class StudentModel extends CI_Model 
{
    public function get_count() 
	{
        return $this->db->count_all("student");
    }
    public function get_students($limit, $start) 
	{
        $this->db->limit($limit, $start);
        $query = $this->db->get("student");
        return $query->result();
    }
    function saverecords($data)
    {
          $this->db->insert('student',$data);
          return $this->db->insert_id();
    }
    public function get_data($id=0)
    {
        if($id==0)
        {
            $query = $this->db->get('student')->result();
            return $query;
        }
        else
        {
            $this->db->where('id',$id);
            $query = $this->db->get('student')->result();
            return $query;
        }
        
    }
   public function upddata($data,$id)       
    {
        extract($data); 
        $this->db->where('id', $id);
        // $this->db->update($table_name, array('full_name' => $full_name, 'email' =>$email, 'mobile' =>$mobile, 'status' =>$status, 'user_role' =>$user_role, 'profile_pic'=>$profile_pic));
        $this->db->update('student', $data);
        return true;
    }

    public function delete_data($id)
    {
        $this -> db -> where('id', $id);
        $this -> db -> delete('student');
    }

    
}
?>