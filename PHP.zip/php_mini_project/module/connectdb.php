<?php
$hostname = 'localhost';
$username = 'root';
$password = '';

$conn = mysqli_connect($hostname,$username,$password);

if(!$conn){
	die('Could not connect:'.mysqli_connect_error());
	// echo 'Could not connect:'.mysqli_connect_error();
	// exit;

}
echo '<h3> Connected Successfully </h3> <br>';

$sql= 'CREATE DATABASE phpconnect2';
if(mysqli_query($conn,$sql)){
	echo '<h4> Database phpconnect2 created successfully </h4>';
}
else{
	echo '<h4> Sorry, Database Creation Failed </h4>'.mysqli_error($conn);
}

mysqli_close($conn);
?>