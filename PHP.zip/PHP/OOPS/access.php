<?php
class access{
	Public $a=10;
	Private $b=20;
	Protected $c=30;
  function abc(){
  	echo $this->a;
  	echo $this->b;
  	echo $this->c;
  }
}
class test extends access{
	function xyz(){
		echo $this->a.'<br>';
		echo $this->b.'<br>';
		echo $this->c.'<br>';
	}
}
$obj=new test();
echo $obj->a;
echo "<br>";
$obj->abc();
echo "<br>";
$obj->xyz();
echo "<br>";
echo $obj->b;
echo $obj->c;

?>