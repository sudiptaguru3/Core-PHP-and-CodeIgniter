<!DOCTYPE html>
<html lang="en">
<head>
  <title>PHP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
  <body>
    <div class="container">
      <h2>Submit data by using core php</h2>
      <form  action="insert.php" method="POST" enctype="multipart/form-data"> 
        <div class="row">
          <div class="col-md-6">
            <div class="form-group row">
              <div class="col-sm-12">
                <label for="name" class="block">Name *</label>
              </div>
              <div class="col-sm-12">
                <input type="text" name="name" class="form-control">
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group row">
              <div class="col-sm-12">
                <label for="education" class="block">Education *</label>
              </div>
              <div class="col-sm-12">
                <select id="education" name="education" class="form-control">
                  <option value="BE">BE</option>
                  <option value="ME">ME</option>
                  <option value="Btech">Btech</option>
                  <option value="Mtech">Mtech</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
         <div class="col-md-6">
          <div class="form-group row">
            <div class="col-sm-12">
              <label for="gender" class="block">Gender *</label>
            </div>
            <div class="col-sm-12">
              <input type="radio" name="gender" value="male" >Male
              <input type="radio" name="gender" value="female">Female
            </div>
          </div>
        </div>
        <!-- <div class="col-md-6">
          <div class="form-group row">
            <div class="col-sm-12">
              <label for="hobby" class="block">Hobby *</label>
            </div>
            <div class="col-sm-12">
              <input type="checkbox" name="hobby[]" value="cricket" >cricket
              <input type="checkbox" name="hobby[]" value="wb" >wb
              <input type="checkbox" name="hobby[]" value="fb" >fb
            </div>
          </div>
        </div> -->
      </div>
     <!--  <div class="row">
        <div class="col-md-6">
          <div class="form-group row">
            <div class="col-sm-12">
              <label for="file" class="block">File *</label>
            </div>
            <div class="col-sm-12">
             <input type="file" name="file" class="form-control">
           </div>
         </div>
       </div>
       <div class="col-md-6">
        <div class="form-group row">
          <div class="col-sm-12">
            <label for="photos" class="block">Gallary *</label>
          </div>
          <div class="col-sm-12">
            <input type="file" name="photos[]" multiple="" class="form-control">
          </div>
        </div>
      </div> -->
    </div>
    <input type="submit" name="submit" value="submit" id="submit" class="btn btn-info">
  </form>
  </div>
  </body>
</html>