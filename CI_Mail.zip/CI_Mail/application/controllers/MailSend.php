<?php
defined('BASEPATH') OR exit('your exit message');
class MailSend extends CI_Controller
{
    public function index() {      
        $this->load->view('mailform');              
    }

    public function Sent()
    {
        // Storing submitted values
        $sender_email = $this->input->post('user_email');
        $user_password = $this->input->post('user_password');
        $receiver_email = $this->input->post('to_email');
        $username = $this->input->post('name');
        $subject = $this->input->post('subject');
        $message = $this->input->post('message');

        // Configure email library
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.googlemail.com';
        $config['smtp_port'] = 465;
        $config['smtp_user'] = $sender_email;
        $config['smtp_pass'] = $user_password;
 
         $this->load->library('email', $config);
         $this->email->initialize($config);
         $this->email->set_newline("\r\n");
 
         // Sender email address
         $this->email->from($sender_email, $username);
         // Receiver email address
         $this->email->to($receiver_email);
         // Subject of email
         $this->email->subject($subject);
         // Message in email
         $this->email->message($message);

         if ($this->email->send()) {
         $data['message_display'] = '<font color="green">Email Send Successfully</font>';
         } else {
         $data['message_display'] = '<font color="red">Email is not Send. Error occured</font>';
         }
         $this->load->view('mailform', $data);
    }
}