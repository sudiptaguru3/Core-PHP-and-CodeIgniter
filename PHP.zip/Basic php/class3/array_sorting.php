<?php
echo "<h3>sort</h3> <br>";
$ar= array('php','java','chash','design','5','8','2','7');
sort($ar);
print_r($ar);
echo "<br>";

echo "<h3>rsort</h3> <br>";
rsort($ar);
print_r($ar);
echo "<br>";


echo "<h3>asort</h3> <br>";
$arr= array('Raj'=>'34','Sujoy'=>'26','Arun'=>'28');
asort($arr);
print_r($arr);
echo "<br>";

echo "<h3>arsort</h3> <br>";
arsort($arr);
print_r($arr);
echo "<br>";

echo "<h3>ksort</h3> <br>";
ksort($arr);
print_r($arr);
echo "<br>";

echo "<h3>krsort</h3> <br>";
krsort($arr);
print_r($arr);
echo "<br>";

?>