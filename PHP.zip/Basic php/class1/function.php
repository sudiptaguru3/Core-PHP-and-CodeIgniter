<?php
//$name="Deep Kumar";
function hello($name){
	//$name="Deep Kumar";
	echo "Hello &nbsp".$name."<br>";
}
hello("Sudipta");
?>