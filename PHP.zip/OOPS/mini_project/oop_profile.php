<?php
session_start();
include 'query.php';
$id =$_SESSION['id'];
$obj=new oop();
$pro=$obj->profile($id);
$data = mysqli_fetch_array($pro);
?>
<br>

<p>Name:<?php echo $data['name']; ?></p>
<p>Email: <?php echo $data['email']; ?></p>
<p>Phone Number: <?php echo $data['phone']; ?></p><br>
 <p>FILE:<img src="<?php echo $data['file']; ?>" width="100px" height="75px"></p><br>
 
<a href="oop_edit.php">Edit Profile</a></br>


