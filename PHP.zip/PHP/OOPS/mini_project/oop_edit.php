<?php
session_start();
include 'query.php';
$id=$_SESSION['id'];
$obj=new oop();
$pro=$obj->profile($id);
$data = mysqli_fetch_array($pro);
// $_SESSION['id']=$data['id'];
?>
<form action="oop_edit_action.php" method="POST" enctype="multipart/form-data" >
    Name:<input type="text" id="user" name="user" value="<?php echo 
          $data['name'];?>" ><br>
    
    Email:<input type="text" id="mail" name="mail" value="<?php echo 
          $data['email'];?>" readonly><br>

    Phone Number:<input type="number" id="nmbr" name="phone" value="<?php echo $data['phone'];?>"><br>

    File:<input type="file" id="fle" name='file'><img src="<?php echo $data['file'];?>" height="300px" width="400px">
    
    <input type="reset" value='Reset'>
    <input type="submit" value='Update'>
</form>