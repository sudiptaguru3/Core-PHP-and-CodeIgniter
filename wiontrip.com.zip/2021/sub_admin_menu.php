<div class="content">

		<div class="navigation">
			<h5 class="title">Menu</h5>
			<!-- /.title -->
            
			<ul class="menu js__accordion">
                <li>
					<a href="dashboard.php" class="waves-effect"> <i class="menu-icon fa fa-home"> </i> <span class="font-bold">Dashboard</span> </a>
				</li>
                <?php 
					$qre = mysqli_query($con,"select DISTINCT menu_id,(select icon from menuMaster where id=r.menu_id)icon,(select menu from menuMaster where id=r.menu_id)menuname from roleMaster r where isactive='1' and Msrno='".$_SESSION['AMSRNO']."' ORDER by menu_id asc");
					if(mysqli_num_rows($qre)>0)
					{
						while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
						{?>
							<li>
                            <a class="waves-effect parent-item js__control" href="#"><i class="menu-icon  fa <?php echo $res["icon"];?>"> </i><span><?php echo $res["menuname"];?></span><span class="menu-arrow fa fa-angle-down"></span></a>
                            <ul class="sub-menu js__content">
                            	<?php 
									$qre1 = mysqli_query($con,"select *,(select pagelink from  pagesMaster where id=r.page_id)pagelink,(select pagename from  pagesMaster where id=r.page_id)pagename from roleMaster r where isactive='1' and Msrno='".$_SESSION['AMSRNO']."' and menu_id='".$res["menu_id"]."' ORDER by menu_id asc");
									if(mysqli_num_rows($qre1)>0)
									{
										while($resd = mysqli_fetch_array($qre1,MYSQLI_ASSOC))
										{?>
											<li  > <a href="<?php echo $resd["pagelink"];?>" class="auto"> <span><?php echo $resd["pagename"];?></span> </a> </li>
										<?php }	
									}
								?>
                                                              
                            </ul>
                        </li>	
						<?php }
					}
				?>
				
			</ul>
			
		</div>
		<!-- /.navigation -->
	</div>
    
    <?php 
		$lnk =  $_SERVER['PHP_SELF'];
		$splnk = explode("/",$lnk);
		$pagetitle=$splnk[2];
		if($pagetitle!="dashboard.php" && $pagetitle!="logout.php" && $pagetitle!="updateuser.php")
		{
			$qre = mysqli_query($con,"select * from (select *,(select pagelink from  pagesMaster where id=r.page_id)pagelink,(select pagename from  pagesMaster where id=r.page_id)pagename from roleMaster r where isactive='1' and Msrno='".$_SESSION['AMSRNO']."' ) m where pagelink='$pagetitle'");
			if(mysqli_num_rows($qre)==0)
			{
				echo "<script>window.location='dashboard.php';</script>";
			}
		}
		
	?>