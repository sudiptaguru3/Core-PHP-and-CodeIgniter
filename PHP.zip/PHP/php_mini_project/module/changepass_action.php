<?php
session_start();
include 'connect.php';

$id=$_SESSION['id'];
$sql= "SELECT * FROM user WHERE id='".$id."'";
$query= mysqli_query($conn, $sql);
$data= mysqli_fetch_array($query);

$db_pass=$data['password'];
$old_pass=$_REQUEST['old_pass'];
$new_pass=$_REQUEST['new_pass'];
$confirm_pass=$_REQUEST['confirm_pass'];

if($db_pass==$old_pass){
     if($old_pass!=$new_pass){
         if($new_pass==$confirm_pass){
            
            $update=mysqli_query($conn,"UPDATE user SET password='".$new_pass."'WHERE id='".$id."'");
            if($update){
            	// echo "Password Update Successfull";
            	header("location:profile.php?change=1");
            }
            else{
            	//echo "Password not update";
            	header("location:change_password.php?change=0");
            }
         }
         else{
              echo "<font color='red'>New password and Confirm password does not match </font>";
         }
     }
     else{
           echo "<font color='red'>Old password and New Password is matched </font>";
     }
}
else{
       echo "<font color='red'>Database password and Old password does not match </font>";
}

?>