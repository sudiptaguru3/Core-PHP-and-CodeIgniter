<?php
include "connect.php";
$sql=mysqli_query($conn,"SELECT * FROM user");

if(isset($_REQUEST['admin']) && $_REQUEST['admin'] == 1){
    echo "<font color='green'>Admin Login Successfull</font>";
}

?>
<table border="1">
<tr>
	<th>Name</th>
	<th>Email</th>
	<th>Phone</th>
	<th>Address</th>
	<th>Status</th>

</tr>

	<?php
	while($data=mysqli_fetch_array($sql))
	{
		?>
		<tr>
		<td><?php echo $data['name'];?></td>
		<td><?php echo $data['email'];?></td>
		<td><?php echo $data['contact'];?></td>
		<td><?php echo $data['address'];?></td>
		<td><a href="active_deactive.php?id=<?php echo $data['id'];?>">
		<?php
			if($data['login_status']==1)
			{
				echo "Block";
			}
			else
			{
				echo "Unblock";
			}
			?></a></td>
		
	</tr>
	<?php	
	}
	?>


</table>
