<!DOCTYPE html>
<html lang="en">
<head>
    <title>Update User</title>
</head>
<body>
    <?php
    $str = $user['skill'];
    $skill=explode(',', $str);
    // print_r($skill);
    $str1 = $user['gender'];
    $gender=explode(',', $str1);
    ?>
    <a href="<?php echo base_url(); ?>">Add User </a> 
    &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="<?php echo base_url('view'); ?>">View User</a>
    <hr>
    
    <form action="<?php echo base_url('update'); ?>" method="POST">

        <input type="hidden" name="userId" value="<?php echo $user['id']; ?>">
        <br>
        
        <a>Name :</a> 
        <input type="text" name="user" value="<?php echo $user['name']; ?>"> <br>
        
       Address :
        <input type="text" name="address" value="<?php echo $user['address']; ?>">
        <br>

        Phone :
        <input type="text" name="phone" value="<?php echo $user['phone']; ?>">
        <br>
        Skill:<input type="checkbox" name="skill[]" value="php" <?php echo in_array('php',$skill)?'checked':''?>>PHP
         <input type="checkbox" name="skill[]" value="android" <?php echo in_array('android',$skill)?'checked':''?>>ANDROID
         <input type="checkbox" name="skill[]" value="iphone" <?php echo in_array('iphone',$skill)?'checked':''?>>IPHONE 
         <input type="checkbox" name="skill[]" value="java" <?php echo in_array('java',$skill)?'checked':''?>>JAVA
         <br>
        Gender:<input type="radio" name="gender" value="male" <?php echo in_array('male',$gender)?'checked':''?>>Male
         <input type="radio" name="gender" value="female" <?php echo in_array('female',$gender)?'checked':''?>>Female
         <br>
        Country:
        <select name="country">
            <option value="">Select</option>
            <option value="India" <?php if($user['country']=='India') echo 'selected="selected"'; ?>>India</option>
            <option value="USA" <?php if($user['country']=='USA') echo 'selected="selected"'; ?>>USA</option>
        </select>
        <br>
        <input type="submit" name="submitbtn" value="Update">
        <input type="reset" name="resetbtn" value="Reset">
        <br>
    </form>
</body>
</html>