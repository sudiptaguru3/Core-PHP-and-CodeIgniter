<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_user extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		// $this->load->database();
		// $this->load->model('Category_model');
	}

	public function index()
	{

	 //   	$this->load->view('include/header');
		// $this->load->view('include/sidebar');
		$this->load->view('admin_user_add');
		// $this->load->view('include/footer');
	}

	public function add_user()
	{
		// echo "<pre>";
		// print_r($_FILES);
		$data['profile_pic']=$_FILES['profile_pic']['name'];
		

//-------------------------file upload code---------------------------

//Check whether user upload picture
            if(!empty($_FILES['profile_pic']['name'])){
                $config['upload_path'] = 'uploads/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['profile_pic']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('profile_pic')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }

		
		$this->load->model('Admin_user_model');
		 $user=$this->Admin_user_model->saverecords($data); 
	
			        redirect('View_all_admin_user');

	}


}

?>	
	