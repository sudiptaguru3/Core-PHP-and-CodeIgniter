

<?php
include("z_db.php");
include("Auth.php");
if(isset($_POST['submit'])){
	
    $amount = $_REQUEST['amount'];
    $ref = $_REQUEST['ref'];
    $branch = $_REQUEST['branch'];
    $payment_type = $_REQUEST['payment_type'];
    $payment_date = $_REQUEST['payment_date'];
    $message= $_REQUEST['message'];
    $filename = $_FILES['file']['name'];    
    $tmpName = $_FILES['file']['tmp_name'];
    $destination = 'uploads'.rand().$filename;
    move_uploaded_file($tmpName, $destination);

    $sql="";

    if(mysqli_query($con,"INSERT INTO payment_request (Msrno,amount,ref,branch_name,payment_type,payment_date,message,attachment,isactive,ondate)VALUES('".$_SESSION["MSRNO"]."','$amount','$ref','$branch','$payment_type','$payment_date','$message','$destination','1','$datedata')"))
    {
        header("location:dashboard.php");
    }
    else
    {
        echo"not ok";
    }
}
?>