$(document).ready(function() {
    
    $('.button-psswd').on('click', function() {
        
        if ($('.input-psswd').attr('psswd-shown') == 'false') {
            
            $('.input-psswd').removeAttr('type');
            $('.input-psswd').attr('type', 'text');
            
            $('.input-psswd').removeAttr('psswd-shown');
            $('.input-psswd').attr('psswd-shown', 'true');
            
            $('.button-psswd').html('Hide password');
            
        }else {
            
            $('.input-psswd').removeAttr('type');
            $('.input-psswd').attr('type', 'password');
            
            $('.input-psswd').removeAttr('psswd-shown');
            $('.input-psswd').attr('psswd-shown', 'false');
            
            $('.button-psswd').html('Show password');
            
        }
        
    });
    
});