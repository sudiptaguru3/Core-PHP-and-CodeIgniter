-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2021 at 11:55 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oli_asset_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `id` int(255) NOT NULL,
  `profile_pic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `profile_pic`) VALUES
(1, 'photo-1550028061-1de667deea35.jpg'),
(2, 'photo-1550028061-1de667deea35.jpg'),
(3, 'photo-1556830805-7cec0906aee6.jpg'),
(4, 'photo-1556830805-7cec0906aee6.jpg'),
(5, 'photo-1556830805-7cec0906aee6.jpg'),
(6, 'photo-1556830805-7cec0906aee6.jpg'),
(7, 'photo-1556830805-7cec0906aee6.jpg'),
(8, 'photo-1556830805-7cec0906aee6.jpg'),
(9, 'photo-1556830805-7cec0906aee6.jpg'),
(10, 'photo-1556830805-7cec0906aee6.jpg'),
(11, 'photo-1556830805-7cec0906aee6.jpg'),
(12, ''),
(13, 'photo-1550028061-1de667deea35.jpg'),
(14, 'Screenshot (6).png'),
(15, 'Screenshot (6).png'),
(16, 'Screenshot (2).png'),
(17, 'photo-1550028061-1de667deea35.jpg'),
(18, 'photo-1550028061-1de667deea35.jpg'),
(19, 'photo-1550028061-1de667deea35.jpg'),
(20, 'photo-1580600301354-0ce8faef576c.jpg'),
(21, 'photo-1580600301354-0ce8faef576c.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_user`
--
ALTER TABLE `admin_user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
