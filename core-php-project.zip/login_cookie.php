
<form action="login_cookie_action.php" method="POST">
<h1> User Login</h1>
Username:<input type="email" name="email"
 value="<?php echo isset($_COOKIE['email']) && $_COOKIE['email']!=''?$_COOKIE['email']:''; ?>"><br><br><br>
 
Password:<input type="password" name="password" value="<?php echo isset($_COOKIE['password']) && $_COOKIE['password']!=''?$_COOKIE['password']:''; ?>"><br><br><br>

Remember Me:<input type="checkbox" name="remember" value="1"<?php echo isset($_COOKIE['email']) && isset($_COOKIE['password'])?'checked':'';?>>

<input type="submit" name="submit" value="Login">
</form>