
 <div class="content-wrapper">
<section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <!-- <div class="card-header"> -->
            <!-- <h3 class="card-title">Create User</h3> -->


          <!-- </div> -->
          <!-- /.card-header -->
          <form action="<?php echo base_url('View_all_admin_user/update_user'); ?>" method="post"  enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $this->uri->segment(3); ?>">
          <div class="card-body">

            <div class="row">
              <div class="col-3 col-sm-3">
                <div class="form-group">
                    <label for="profile_pic">Profile Picture</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <!-- <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic" onchange ="show_pictures(this.value)"> -->
                        <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic"  onchange="readURL(this);" value="">
                      </div>
                    </div>
                  </div>
              </div>

              <div class="col-3 col-sm-3">
                <div class="form-group">
                        <?php if($user[0]->profile_pic!='') {?>
                        <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('uploads/'.$user[0]->profile_pic); ?>" id="image_disp" class="img-thumbnail">
                <?php } else {?>
                  <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('asset/banner/180.png'); ?>" id="image_disp" class="img-thumbnail">
                <?php } ?>
                </div>
              </div>        
            </div>                                                                   

            <div class="card-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
          </div>
          </form>       
        </div>
</div>        
</section>
</div> 

<script type="text/javascript">
       function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#image_disp')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>

