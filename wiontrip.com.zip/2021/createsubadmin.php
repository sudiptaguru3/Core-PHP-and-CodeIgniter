<?php 
include_once ("z_db.php");
$data ="";
include("Auth.php");
if(isset($_GET['ed']))
{
	$id = $_GET['ed'];
	$stmt = $con->prepare("select * from subadminMaster where id=?");
	$stmt->bind_param("s",$ids);
	$ids=$id;
	$stmt->execute();
	$result=$stmt->get_result();
	if($result->num_rows>0)
	{
		$row = $result->fetch_assoc();
		extract($row);
	}
}
if(isset($_GET['id']) && isset($_GET['st']))
{
	$id = $_GET['id'];
	$st = $_GET['st'];
	if($id!="" && $st!="")
	{
		if($st=="Active")
		{
			mysqli_query($con,"update subadminMaster set isactive='1' where id='$id'");
			echo "<script type='text/javascript'>alert('Sub Admin has been Activate');window.location='createsubadmin.php';</script>";
		}
		else if($st=="Deactive")
		{
			mysqli_query($con,"update subadminMaster set isactive='0' where id='$id'");
			echo "<script type='text/javascript'>alert('Sub Admin has been Deactivate');window.location='createsubadmin.php';</script>";
		}
	}
}
$path='productimg/';
$count=0;
if(isset($_POST['save']))
{
	$status = "OK"; //initial status
	$msg="";	
	$name=mysqli_real_escape_string($con,$_POST['name']);		
	$uname=mysqli_real_escape_string($con,$_POST['uname']); //fetching details through post method
	$password =mysqli_real_escape_string( $con,$_POST['password']);
	$qre = mysqli_query($con,"select * from subadminMaster where uname='$uname'");	
	if(mysqli_num_rows($qre)>0)
	{
		echo "<script type='text/javascript'>alert('UserName already exist');window.location='createsubadmin.php';</script>";
	}
	else
	{
		$res1=mysqli_query($con,"INSERT INTO subadminMaster (name,uname,password,isactive,ondate) VALUES ('$name','$uname','$password','1','$datedata')");
		echo "<script type='text/javascript'>alert('Sub Admin Created successfully');window.location='createsubadmin.php';</script>";
	}
	
}
if(isset($_POST['upd']))
{
	$status = "OK"; //initial status
	$msg="";
	$name=mysqli_real_escape_string($con,$_POST['name']);		
	$uname=mysqli_real_escape_string($con,$_POST['uname']); //fetching details through post method
	$password =mysqli_real_escape_string( $con,$_POST['password']);
	$pidmain = $_POST['hid'];	
	
	$res1=mysqli_query($con,"update subadminMaster set name='$name',uname='$uname',password='$password' where id='$pidmain'");
	
	echo "<script type='text/javascript'>alert('Sub Admin Updated successfully');window.location='createsubadmin.php';</script>";	
	
	
}
function RandomString()
{
$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$randstring = '';
for ($i = 0; $i < 10; $i++) {
	$randstring .= $characters[rand(0, strlen($characters))];
}
return $randstring;
}
?>
<!DOCTYPE html>
<html lang="en">


<head>
	<?php include("headercss.php");?>
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  
</head>

<body>
<div class="main-menu">
	<?php 
		include("header.php");
	?>
	<!-- /.header -->
	<?php 
		include("sidemenu.php");
	?>
	<!-- /.content -->
</div>
<!-- /.main-menu -->


<!-- /.fixed-navbar -->


<!-- /#notification-popup -->


<!-- /#message-popup -->
<?php include("uppernav.php");?>
<!-- #color-switcher -->

<div id="wrapper">
	<div class="main-content">
		<div class="row small-spacing">
			
			<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title">Create Sub Admin</h4>
					<!-- /.box-title -->
                     
						<form action="createsubadmin.php" method="post" >
                    <input type="hidden" name="hid" value="<?php echo $_GET['ed'];?>" />
                    <table class="table table-striped b-t b-light" >
                    	<tr>
                        	<td>Name</td>
                            <td><input type="text" name="name" style="width:50%;" value="<?php echo $name;?>" class="form-control" required /></td>
                        </tr>
                        <tr>
                        	<td>UserName</td>
                            <td><input type="text" name="uname" style="width:50%;" value="<?php echo $uname;?>" class="form-control" required /></td>
                        </tr>
                        <tr>
                        	<td>Password</td>
                            <td><input type="text" name="password" style="width:50%;" value="<?php echo $password;?>" class="form-control" required /></td>
                        </tr>
                        <tr>
                        	<td colspan="2" align="center">
                            <?php 
								if(isset($_GET['ed']))
								{?>
								 	<button type="submit" class="btn btn-lg btn-primary " name="upd">Update & Continue</button>
								<?php }
								else
								{?>
									<button type="submit" class="btn btn-lg btn-primary " name="save">Save & Continue</button>
								<?php }
							?>
                            </td>
                            
                        </tr>
                        
                    </table> 
                    
                    <table class="table table-striped b-t b-light" >
                  
                    <tr>
                    	<td>S No.</td>
                        <td>Name</td>
                        <td>UserName</td>
                        <td>Password</td>
                        <td>Status</td>
                        <td>Action</td>
                    </tr>
                    <?php
                    	$data ="";
						$stmt = $con->prepare("select *,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st from subadminMaster");
						$stmt->execute();
						$result = $stmt->get_result();
						if($result->num_rows>0)
						{
							$i=1;
							while($row = $result->fetch_assoc())
							{
								$data .="<tr>
									<td>".$i."</td>
									<td>".$row["name"]."</td>
									<td>".$row["uname"]."</td>
									<td>".$row["password"]."</td>
									<td>".$row["status"]."</td>
									<td><a class='btn btn-success' href='createsubadmin.php?id=".$row["id"]."&&st=".$row["st"]."'>".$row["st"]."</a> || <a href='createsubadmin.php?ed=".$row["id"]."' class='btn btn-success'>Edit</a> || <a href='roles.php?sol=".$row["id"]."' class='btn btn-success'> Add Privileges</a></td>
								</tr>";
								$i++;
							}
							
						}
						echo $data;
						
					?>
                    
                    </table>                    
                    </form>
    
				
				<!-- /.box-content -->
			</div>
		</div>
		<!-- /.row -->		
		<?php include("footer.php"); ?>
	</div>
	<!-- /.main-content -->
</div><!--/#wrapper -->

	<?php include("footerjs.php"); ?>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script>
  $( function() {
    $( ".datepicker" ).datepicker({ dateFormat: 'yy-mm-dd' });
  } );
  </script>
     
</body>


</html>