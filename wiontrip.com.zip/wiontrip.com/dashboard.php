<?php 
	include("z_db.php");
	include("Auth.php");
	if(isset($_POST['search'])){
		
		$airline=mysqli_real_escape_string($con,trim($_POST['airline']));
		$infant=mysqli_real_escape_string($con,trim($_POST['infant']));
		$child=mysqli_real_escape_string($con,trim($_POST['child']));
		$adult=mysqli_real_escape_string($con,trim($_POST['adult']));
		$date=mysqli_real_escape_string($con,trim($_POST['date']));
		$destination=mysqli_real_escape_string($con,trim($_POST['destination']));
		
		$qty = $child+$adult;
		$data_table = "";
		
		unset($_SESSION['des']);
		unset($_SESSION['dt']);
		unset($_SESSION['ad']);
		unset($_SESSION['ch']);
		unset($_SESSION['inf']);
		unset($_SESSION['ttl']);
		
		$_SESSION['des']=$destination;
		$_SESSION['dt']=$date;
		$_SESSION['ad']=$adult;
		$_SESSION['ch']=$child;
		$_SESSION['inf']=$infant;
		$_SESSION['qty']=$qty;
		
		
		if($airline == "all")
		{
			$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM `ticket_master` t where available_seat>='$qty' and  flight_id in (select id from airline_flight_no_master where destination_id='$destination' ) and flight_date='$date') j ) f");	
		}
		else
		{
			$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM ticket_master t where available_seat>='$qty' and airline_id='$airline' and flight_id in (select id from airline_flight_no_master where destination_id='$destination' and airline_id='$airline') and flight_date='$date') j ) f");	
		}
		
		if(mysqli_num_rows($qre)>0)
		{
			while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
			{
				$ttl = $res["price"]*$qty;
				if($infant>0)
				{
					$ttl = $ttl+1500;	
				}
				$data_table .="<tr>";
				$data_table .="<td><img src='2021/productimg/".$res["airline_logo"]."' width='70' height='70' alt=' ' /></td>";
				$data_table .="<td><strong>".$res["from_city_name"]." to ".$res["to_city_name"]."</strong></td>";
				$data_table .="<td><strong>".$res["flight_number"]."</strong></td>";
				$data_table .="<td><strong>".$date."</strong></td>";
				$data_table .="<td><strong>".$res["dep_hour"]." : ".$res["dep_mint"]."</strong></td>";
				$data_table .="<td><strong>".$res["arrival_hour"]." : ".$res["arrival_mint"]."</strong></td>";
				$data_table .="<td><strong>".$qty."</strong></td>";
				$data_table .="<td><strong>".$res["available_seat"]."</strong></td>";
				$data_table .="<td><strong>".$ttl."</strong></td>";
				$data_table .="<td><a href='proceed-booking.php?sol=".$res["id"]."' class='btn btn-success'>Book Now</a></td>";
				$data_table .="</tr>";				
			}
		}	
		else
		{
			echo "<script>alert('No Flight Found');window.location='dashboard.php';</script>";
		}
	}
?>

<!DOCTYPE html>
<html lang="en">


<?php include("headercss.php");?>
  <link href="http://www.jquerycookbook.com/demos/css/jquery-ui.css" rel="stylesheet" />
  

<body>

	<!-- wrapper -->
	<div class="wrapper">
		<!--sidebar-wrapper-->
		<?php include("sidemenu.php");?>
		<!--end sidebar-wrapper-->
		<!--header-->
		<?php include("header.php");?>
		<!--end header-->
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					
					<!--end row-->
					
					<!--end row-->
					
					<!--end row-->
					
					<!--end row-->
					
					<div class="card radius-15" style="background-color:  #952EAA;">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0"><a style="color: white;">Search Flight</a></h5>
							</div>
							<hr/>
							<div class="table-responsive">
                            	<form action="dashboard.php" method="post">
                            	<div class="row">
									<div class="col-12 col-lg-12 col-xl-6">
                                    	<label for="validationServer01"><strong><a style="color: white;">Destination</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-map"></i></span>
                                            </div>
                                            <select class="form-control" name="destination" required onChange="make_date();" id="destination">
                                                <option value="">--Select Destination--</option>
                                                <?php 
													$data = "";
													$qre = mysqli_query($con,"SELECT *,(SELECT city_name from airport_master where id=d.from_city)city_name1,(SELECT city_name from airport_master where id=d.to_city)city_name2 FROM `destination_master` d where isactive='1' and id in (select destination_id from airline_flight_no_master where id in (select flight_id from ticket_master where isexpire='0' and isactive='1'))");
													if(mysqli_num_rows($qre)>0)
													{
														while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
														{
															if($destination==$res["id"])
															{
																$data .="<option value='".$res["id"]."' selected>".$res["city_name1"]." to ".$res["city_name2"]."</option>";
															}
															else
															{
																$data .="<option value='".$res["id"]."'>".$res["city_name1"]." to ".$res["city_name2"]."</option>";
															}
															
														}
													}
													echo $data;
												?>
                                            </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-12 col-xl-6">
                                    	<label for="validationServer01"><strong><a style="color: white;">Travel Date</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-calendar-alt"></i></span>
                                            </div>
                                            <input type="text" class="form-control" id="datepicker" value="<?php echo $date;?>" required name="date"  placeholder="Travel Date">
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-12 col-lg-12 col-xl-2">
                                    	<label for="validationServer01"><strong><a style="color: white;">Adults(12+Yrs)</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                            </div>
                                            <select class="form-control" name="adult" required>
                                                <option value="0">0</option>
                                                <option value="1" selected>1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                            </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-12 col-xl-2">
                                    	<label for="validationServer01"><strong><a style="color: white;">Child(2-12Yrs)</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                            </div>
                                            <select class="form-control" name="child" required>
                                                <option value="0">0</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                             </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-12 col-xl-2">
                                    	<label for="validationServer01"><strong><a style="color: white;">Infant(0-2Yrs)</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                            </div>
                                            <select class="form-control" name="infant" required>
                                                <option value="0">0</option>
                                                <option value="1">1</option>
                                             </select>
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-12 col-lg-12 col-xl-6">
                                    	<label for="validationServer01"><strong><a style="color: white;">Airlines</a></strong></label>
                                    	<div class="input-group mb-3">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="lni lni-plane"></i></span>
                                            </div>
                                            <select class="form-control" name="airline" required>
                                                 <option value="all">ALL</option>
                                                 
                                                 <?php 
													$data = "";
													$qre = mysqli_query($con,"SELECT * FROM airline_master d where isactive='1'");
													if(mysqli_num_rows($qre)>0)
													{
														while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
														{
															if($airline==$res["id"])
															{
																$data .="<option selected value='".$res["id"]."'>".$res["airline"]."</option>";
															}
															else
															{
																$data .="<option value='".$res["id"]."'>".$res["airline"]."</option>";
															}
															
														}
													}
													echo $data;
												?>
                                            </select>
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-12 col-xl-6">
                                    	<div class="input-group mb-3">
                                           
                                            <input type="submit" class="btn btn-success" value="Search" name="search">
                                            
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                </div>
                                </form>    
                            	
                            
								
							</div>
						</div>
					</div>
                    <?php 
						if($data_table!="")
						{?>
								<div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0">Flight Result</h5>
							</div>
							<hr/>
							<div class="table-responsive">
								<table class="table mb-0">
									<thead class="thead-dark">
										<tr>
											<th>Airlines</th>
											<th>Destination</th>
											<th>Flight No</th>
											<th>Date</th>
											<th>Dep</th>
                                            <th>Arr</th>
                                            <th>Qty.</th>
                                            <th>Available Seat(s)</th>
                                            <th>Deal</th>
                                            <th></th>
										</tr>
									</thead>
									<tbody>
										<?php echo $data_table;?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
						<?php }
					?>
                    
                    
                    
                    
                    
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<!--footer -->
		<div class="footer">
			<p class="mb-0">WION TRIP @2021 | Developed By : <a href="http://happyweb.in/" target="_blank">Happy Web</a>
			</p>
		</div>
		<!-- end footer -->
	</div>
	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<?php include("footerjs.php");?>
    <script src="http://www.jquerycookbook.com/demos/scripts/jquery-1.11.1.min.js"></script>
    <script src="http://www.jquerycookbook.com/demos/scripts/jquery-ui.min.js"></script>
  <script>
	
/*var dates = ["05-02-2021", "06-02-2021", "07-02-2021", "09-02-2021"];
 
function DisableDatess(date) {
	alert(date);
    var string = jQuery.datepicker.formatDate('dd-mm-yy', date);
    return [dates.indexOf(string) == -1];
}
function make(date)
{
	alert(date);
}

$(document).ready(function () {
	alert(date);
});*/
 /* function make_date()
  {
	var dest = $("#destination").val();
	if(dest>0)
	{
		$.ajax({ type: "GET",   
		 url: "pst.php?dest="+dest,   
		 async: false,
		 success : function(text)
		 {
				
					 $("#datepicker").datepicker({
						 beforeShowDay: DisableDatess
					 });
				
		 }
		});
	}

  }*/
  $( function() {
   $( "#datepicker" ).datepicker({ minDate: 0 ,dateFormat:"dd-mm-yy",maxDate: new Date('02-02-2012','03-02-2021')});
  } );
  </script>
</body>


</html>