<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class departmentAdd extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		// $this->load->database();
		// $this->load->model('Category_model');
	}

	public function index()
	{

	   	$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$this->load->view('addDepartment');
		$this->load->view('include/footer');
	}

	public function add_user()
	{
		$data['department']=$this->input->post('department');
		$this->load->model('department_model');
		 $user=$this->department_model->saverecords($data); 

		if($user >0)
			{
	
			        redirect('departmentView');
			}
			else
			{
					echo "Insert error !";
			}
	}


}

?>	
	