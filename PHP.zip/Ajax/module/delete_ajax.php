<?php
include "connection.php";
$id=$_REQUEST['send_id'];

$delete=mysqli_query($conn,"DELETE FROM user WHERE id='".$id."'");
if ($delete) {
	header("location:profile_list.php?del=1");

	// echo "<font color='green'>Data Deleted Successfully</font>";
}
else{
	header("location:profile_list.php?del=0");

	// echo "<font color='red'>Sorry, Data is not Deleted</font>";
}
?>