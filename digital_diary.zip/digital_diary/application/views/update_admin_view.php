
 <div class="content-wrapper">
 
 <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Employee</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add User</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

<section class="content">
      <div class="container-fluid">
        <!-- SELECT2 EXAMPLE -->
        <div class="card card-default">
          <!-- <div class="card-header"> -->
            <!-- <h3 class="card-title">Create User</h3> -->


          <!-- </div> -->
          <!-- /.card-header -->
          <form action="<?php echo base_url('View_all_admin_user/update_user'); ?>" method="post"  enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $this->uri->segment(3); ?>">
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter Full Name" value="<?php echo $user[0]->full_name; ?>">
                  </div>
                    <div class="form-group">
                    <label for="mobile">Status</label>
                    <select class="form-control" id="status" name="status">
                      <option value="1" <?php if($user[0]->status==1){ echo 'selected';} ?>>Active</option>
                      <option value="0" <?php if($user[0]->status==0){ echo 'selected';} ?>>Inactive</option>
                    </select>
                  </div>
              </div>

              <div class="col-md-6">
                 <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" value="<?php echo $user[0]->email; ?>">
                  </div>
                 <div class="form-group">
                    <label for="mobile">Mobile</label>
                    <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Enter Mobile" value="<?php echo $user[0]->mobile; ?>">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-6 col-sm-6">
                <div class="form-group">
                  <label>User Role</label>
                  <select class="form-control" style="width: 100%;" name="user_role">
                    <option value="Super Admin" <?php if($user[0]->user_role=='Super Admin'){ echo 'selected';} ?>>Super Admin</option>
                    <option value="Admin" <?php if($user[0]->user_role=='Admin'){ echo 'selected';} ?>>Admin</option>
                    <option value="Employee" <?php if($user[0]->user_role=='Employee'){ echo 'selected';} ?>>Employee</option> 
                  </select>
                </div>
              </div>
              <div class="col-3 col-sm-3">
                <div class="form-group">
                    <label for="profile_pic">Profile Picture</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <!-- <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic" onchange ="show_pictures(this.value)"> -->
                        <input type="file" class="custom-file-input" id="profile_pic" name="profile_pic"  onchange="readURL(this);" value="">
                        <label class="custom-file-label" for="profile_pic">Choose file</label>
                      </div>
                    </div>
                  </div>
              </div>

              <div class="col-3 col-sm-3">
                <div class="form-group">
                        <?php if($user[0]->profile_pic!='') {?>
                        <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('uploads/'.$user[0]->profile_pic); ?>" id="image_disp" class="img-thumbnail">
                <?php } else {?>
                  <img style="width: 100px;height: 100px; border-radius: 50%;" src="<?php echo base_url('asset/banner/180.png'); ?>" id="image_disp" class="img-thumbnail">
                <?php } ?>
                </div>
              </div>        
            </div>                                                                   

            <div class="card-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
          </div>
          </form>       
        </div>
</div>        
</section>
</div> 

<script type="text/javascript">
       function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#image_disp')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>

