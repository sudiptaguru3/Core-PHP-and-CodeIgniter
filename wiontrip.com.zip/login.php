<?php 
	include("z_db.php");
	
	if(isset($_POST['sbt']))
	{
		$email=mysqli_real_escape_string($con,trim($_POST['email'])); //fetching details through post method
		$password = mysqli_real_escape_string($con,trim($_POST['password']));
		
		if($email!="" && $password!="")
		{
			$qre = mysqli_query($con,"select * from tempusermaster t where email='$email' and password='$password' and isactive='1'");
			if(mysqli_num_rows($qre)!=0)
			{
				$res = mysqli_fetch_array($qre,MYSQLI_ASSOC);
				session_start();
				$_SESSION['MSRNO']=$res["id"];
				$_SESSION['USERNAME']=$res["username"];
				$_SESSION['COMPANY_NAME']=$res["company_name"];
				header("location:dashboard.php");
			}
			else
			{
				echo "<script type='text/javascript'>alert('Invalid Email or password.');window.location='login.php';</script>";
			}
		}
		else
		{
			echo "<script type='text/javascript'>alert('Invalid Email or password.');window.location='login.php';</script>";
		}
	}
?>
<!DOCTYPE html>
<html lang="en">


<head>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<title>Welcome To WION TRIP</title>
	<!--favicon-->
	<link rel="icon" href="favicon-32x32.png" type="image/png" />
	<!-- loader-->
	<link href="assets/css/pace.min.css" rel="stylesheet" />
	<script src="assets/js/pace.min.js"></script>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
	<!-- Icons CSS -->
	<link rel="stylesheet" href="assets/css/icons.css" />
	<!-- App CSS -->
	<link rel="stylesheet" href="assets/css/app.css" />
</head>

<body class="bg-login">
	<!-- wrapper -->
    <form action="login.php" method="post">
	<div class="wrapper">
		<div class="section-authentication-login d-flex align-items-center justify-content-center">
			<div class="row">
				<div class="col-12 col-lg-10 mx-auto">
					<div class="card radius-15">
						<div class="row no-gutters">
							<div class="col-lg-6">
								<div class="card-body p-md-5">
									<div class="text-center">
                                    <!--assets/images/logo-icon.png-->
										<img src="logo_login.png" width="120" alt=" ">
										<h3 class="mt-4 font-weight-bold">Welcome Back</h3>
									</div>
									<!--<div class="input-group shadow-sm rounded mt-5">
										<div class="input-group-prepend">	<span class="input-group-text bg-transparent border-0 cursor-pointer"><img src="assets/images/icons/search.svg" alt="" width="16"></span>
										</div>
										<input type="button" class="form-control  border-0" value="Log in with google">
									</div>-->
									<!--<div class="login-separater text-center"> <span>OR LOGIN WITH EMAIL</span>
										<hr/>
									</div>-->
									<div class="form-group mt-4">
										<label>Email Address</label>
										<input type="email" required name="email" class="form-control" placeholder="Enter your email address" />
									</div>
									<div class="form-group">
										<label>Password</label>
										<input type="password" name="password" required class="form-control" placeholder="Enter your password" />
									</div>
									<div class="form-row">
										<div class="form-group col">
											<div class="custom-control custom-switch">
												<input type="checkbox" class="custom-control-input" id="customSwitch1" checked>
												<label class="custom-control-label" for="customSwitch1">Remember Me</label>
											</div>
										</div>
										<div class="form-group col text-right"> <a href="authentication-forgot-password.html"><i class='bx bxs-key mr-2'></i>Forget Password?</a>
										</div>
									</div>
									<div class="btn-group mt-3 w-100">
										<input type="submit" name="sbt" class="btn btn-primary btn-block" value="Login" />
										<button type="button" class="btn btn-primary"><i class="lni lni-arrow-right"></i>
										</button>
									</div>
									<hr>
									<div class="text-center">
										<p class="mb-0">Don't have an account? <a href="register.php">Sign up</a>
										</p>
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<img src="assets/images/login-images/login-frent-img.jpg" class="card-img login-img h-100" alt="...">
							</div>
						</div>
						<!--end row-->
					</div>
				</div>
			</div>
		</div>
	</div>
    </form>
	<!-- end wrapper -->
</body>


</html>