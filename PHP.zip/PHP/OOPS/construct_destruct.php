<?php
class test{
	function bbc(){
		echo "Ejob ";
	}
	function __construct(){
		echo "Hello ";

	}
	function __destruct(){
		echo "Bye! ";
	}
	function abd(){
		echo "CodIgniter ";
	}
	
}
$obj=new test();

$obj->bbc();
$obj->abd();
?>