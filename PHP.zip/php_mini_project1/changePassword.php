<?php
if(isset($_REQUEST['pass']) && $_REQUEST['pass'] == 0){
    echo "<font color='red'>db password and old password does not match</font>";
}
if(isset($_REQUEST['pass']) && $_REQUEST['pass'] == 1){
    echo "<font color='red'>old password and new password same</font>";
}
if(isset($_REQUEST['pass']) && $_REQUEST['pass'] == 2){
    echo "<font color='red'>new password and confirm password does not same</font>";
}
if(isset($_REQUEST['pass']) && $_REQUEST['pass'] == 3){
    echo "<font color='red'>password not updated</font>";
}
?>
<form action="changepass_action.php" method="post" id="frm">
<h1>Change Password</h1>
	Old Password:<input type="Password"  name="old_pass"></br>
	New Password:<input type="Password"  name="new_pass"></br>
	Confirm Password:<input type="Password" name="confirm_pass"></br>
	<input type="submit" name="sbm" value="change">
</form>