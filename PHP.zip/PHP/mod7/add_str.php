<?php 
  
// Declare a variable and initialize it 
$variable = "GeeksForGeeks is the best platform."; 
  
// Display value of variable 
echo $variable; 
echo "\n"; 
  
// Use substr() and strpos() function to remove 
// portion of string after certain character 
$variable = substr($variable, 0, strpos($variable, "is")); 
  
// Display value of variable 
echo $variable; 
  
?>