CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(60) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `username`, `name`, `gender`, `email`) VALUES
(1, 'sonarika', 'Sonarika Bhadoria', 'female', 'bsonarika@gmail.com'),
(2, 'vishal', 'Vishal sahu', 'male', 'vishal@yahoo.com'),
(3, 'yssyogesh', 'Yogesh singh', 'male', 'yogesh@makitweb.com'),
(4, 'sunil', 'Sunil singh', 'male', 'sunil1993@makitweb.com');
