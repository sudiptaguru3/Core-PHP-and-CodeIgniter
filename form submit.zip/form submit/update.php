<?php
include("connect.php");
$id=$_GET['uid'];
$sqls="SELECT * FROM form WHERE id='$id' ";
$query=mysqli_query($con,$sqls);
$row=mysqli_fetch_array($query);

if(isset($_POST['update'])){
     $name=$_POST['name'];
     $gender=$_POST['gender'];
     $hb=$_POST['hobby'];
     $hobby=implode(",",$hb);
     $education=$_POST['education'];
     $file=$_FILES['file']['name'];
    move_uploaded_file($_FILES['file']['tmp_name'],"fs/$file");

    $gall=array();
    foreach ($_FILES['photos']['name'] as $key => $value) {
        $gal=$_FILES['photos']['name'][$key];
        move_uploaded_file($_FILES['photos']['tmp_name'][$key], "fs/$gal");
        array_push($gall, $gal);
    }
    $g=implode(",", $gall);

    $sql="UPDATE  form SET name='$name',gender='$gender',hobby='$hobby',education='$education',file='$file', gallery='$g' WHERE id='$id'";
    $query=mysqli_query($con,$sql);
    if($query)
    {
        header("location:select.php");
    }
    else
    {
        echo"fail";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>PHP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
    <h2>Submit data by using core php</h2>
    <form method="POST" action="" enctype="multipart/form-data">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group row">
            <div class="col-sm-12">
              <label for="name" class="block">Name *</label>
            </div>
            <div class="col-sm-12">
              <input type="text" name="name" class="form-control" value="<?php echo $row['name'];?>">
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group row">
            <div class="col-sm-12">
              <label for="education" class="block">Education *</label>
            </div>
            <div class="col-sm-12">
              <select id="education" name="education" class="form-control">
                <option value="BE"  <?php if($row['education'] == 'BE') echo 'selected';?>>BE</option>
                <option value="ME"  <?php if($row['education'] == 'ME') echo 'selected';?>>ME</option>
                <option value="Btech"  <?php if($row['education'] == 'Btech') echo 'selected';?>>Btech</option>
                <option value="Mtech"  <?php if($row['education'] == 'Mtech') echo 'selected';?>>Mtech</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
         <div class="col-md-6">
          <div class="form-group row">
            <div class="col-sm-12">
              <label for="gender" class="block">Gender *</label>
            </div>
            <div class="col-sm-12">
              <input type="radio" name="gender" value="male" <?php if($row['gender'] == 'male') echo 'checked';?>>Male
              <input type="radio" name="gender" value="female" <?php if($row['gender'] == 'female') echo 'checked';?>>Female
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group row">
            <div class="col-sm-12">
              <label for="hobby" class="block">Hobby *</label>
            </div>
            <div class="col-sm-12">
                <?php 
                             $chkbox=$row['hobby'];
                             $arr=explode(",",$chkbox);
                      ?>
              <input type="checkbox" name="hobby[]" value="cricket" <?php if(in_array("cricket",$arr)){echo "checked";}?>>cricket
              <input type="checkbox" name="hobby[]" value="wb" <?php if(in_array("wb",$arr)){echo "checked";}?>>wb
              <input type="checkbox" name="hobby[]" value="fb" <?php if(in_array("fb",$arr)){echo "checked";}?>>fb
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group row">
            <div class="col-sm-12">
              <label for="file" class="block">File *</label>
            </div>
            <div class="col-sm-12">
             <img src="fs/<?php echo $row['file'];?>" height="80" width="80">
             <input type="file" name="file" class="form-control">
           </div>
         </div>
       </div>
       <div class="col-md-6">
        <div class="form-group row">
          <div class="col-sm-12">
            <label for="photos" class="block">Gallary *</label>
          </div>
          <div class="col-sm-12">
            <?php $temp=explode(",", $row['gallery']);
                    for($i=0;$i<count($temp);$i++){?>
                    <img src="fs/<?php echo $temp[$i];?>" height="80" width="80"> <?php }?>
            <input type="file" name="photos[]" multiple="" class="form-control">
          </div>
        </div>
      </div>
    </div>
    <input type="submit" name="update" value="update" id="submit" class="btn btn-info">
  </form>
</div>
</body>
</html>