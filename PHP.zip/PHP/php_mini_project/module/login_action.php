<?php
session_start();
include "connect.php";

$email= $_REQUEST['email'];
$password= $_REQUEST['password'];

$sql="SELECT * FROM user WHERE email='".$email."' AND password='".$password."'";
$data= mysqli_query($conn, $sql);

if(mysqli_num_rows($data)==1){
	$fetch= mysqli_fetch_array($data);
	// echo "<pre>";
	// print_r($fetch); exit;

	$_SESSION['id']=$fetch['id'];
	//print_r($_SESSION['id']); exit;

	//echo "<font color='green'> Login Successfull </font>";
	header("location:profile.php?log=1");
}
else{
	header("location:login.php?log=0");
}
?>