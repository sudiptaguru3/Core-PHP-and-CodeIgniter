<?php
class pure{
	function __call($fname,$farg){
		if ($fname=='cal') {
			if (count($farg)==1) {
				echo "1 param passed";
			}
			else{
				echo "2 or more param passed";
			}
		}
		if ($fname=='val') {
			if(count($farg)==5) {
				echo "5 and more param visited";
			}
			else{
				echo "Less than 5 param visited";
			}
	}
	
  }
}
$obj=new pure();
$obj->cal(1);
echo "<br>";
$obj->val(5,3,4,2);
?>
