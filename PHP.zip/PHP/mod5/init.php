<?php

echo "This is PHP"

?>