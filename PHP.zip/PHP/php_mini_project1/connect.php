<?php
$conn=mysqli_connect('localhost','root','','phpconnect');
if(!$conn)  
{  
  die('Could not connect: ' . mysqli_error());  
}  
echo 'Connected successfully <br>';  
  
?>