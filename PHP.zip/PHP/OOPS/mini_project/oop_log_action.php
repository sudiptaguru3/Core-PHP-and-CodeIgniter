<?php
session_start();
include 'query.php';

 $obj=new oop();

 $email=$_REQUEST["email"];
 $password=md5($_REQUEST["password"]);

 $login=$obj->login($email,$password);
 
 if(mysqli_num_rows($login)==1)
 {
 	$fetch=mysqli_fetch_array($login);
 	$_SESSION['id']=$fetch['id'];
 	header("location:oop_profile.php");
 	// echo "<font color='green'>Login Successfull</font>";
 }
 else{
 	header("location:oop_login.php");
 }
 ?>