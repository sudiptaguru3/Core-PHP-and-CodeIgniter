 <?php
echo "<h3> sub string</h3> <br>";
$str= "http://www.example.com/5478631";
$str1= substr($str,23);
echo $str1."<br>";
?>


