<?php

include "connect.php"; // Using database connection file here

$id = $_GET['id']; // get id through query string

$qry = mysqli_query($conn,"select * from user where id='$id'"); // select query

$data = mysqli_fetch_array($qry); // fetch data

if(isset($_POST['update'])) // when click on Update button
{
  // $id = $_POST['id'];
  $name = $_POST['name'];
  $email = $_POST['email'];
  $contact = $_REQUEST['contact'];
  $address = $_REQUEST['address'];
  $edit = mysqli_query($conn,"update user set name='$name', email='$email', contact='$contact', address='$address' where id='$id'");
	
    if($edit)
    {
        mysqli_close($conn); // Close connection
        header("location:admin_profile.php"); // redirects to all records page
        exit;
    }
    else
    {
        echo mysqli_error();
    }    	
}
?>

<h3>Update Data</h3>

<form method="POST">
  <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
  <input type="text" name="name" class="form-control" value="<?php echo $data['name'] ?>" placeholder="Name" >
  </div>  
  </div>
  <div class="col-md-6">
                 <div class="form-group">
  <input type="text" name="email" class="form-control" value="<?php echo $data['email'] ?>" placeholder="Email" >
  </div>
  </div>
  </div>
  <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
  <input type="number" name="contact" class="form-control" value="<?php echo $data['contact'] ?>" placeholder="Contact" >
  </div>
  </div>
   <div class="col-md-6">
    <div class="form-group">
  <input type="text" name="address" class="form-control" value="<?php echo $data['address'] ?>" placeholder="Enter Address" >
   </div>
                </div>
              </div>
              <div class="card-footer">
  <input type="submit" name="update" class="btn btn-primary" value="Update">
</div>
</form>
</div>
</div>        
</section>
    <!-- /.content -->
  </div>
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
$(function () {
  bsCustomFileInput.init();
});
</script>
</body>
</html>