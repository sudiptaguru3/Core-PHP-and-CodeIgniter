<?php
$array= array('10','Sudipta','20','30');

foreach ($array as $value) {
	echo $value;
	echo "<br>";
	// print_r($ar[20]);
}
?>