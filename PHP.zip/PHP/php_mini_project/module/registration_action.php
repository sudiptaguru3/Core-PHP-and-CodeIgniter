<?php

include "connect.php";

$name= $_REQUEST['user'];
$email= $_REQUEST['email'];
$password= $_REQUEST['password'];
$address= $_REQUEST['address'];
$number= $_REQUEST['phone'];
$gender= $_REQUEST['gen'];
$skill= implode(',', $_REQUEST['skill']);
$city= $_REQUEST['city'];

$filename= $_FILES['file']['name'];
$tmpname= $_FILES['file']['tmp_name'];
$destination= 'uploads/'.rand().$filename;
move_uploaded_file($tmpname, $destination);

$query= "SELECT * FROM user WHERE email='".$email."'";
$check_email= mysqli_query($conn, $query);

if(mysqli_num_rows($check_email)==0){

$sql= "INSERT INTO user VALUES('','$name','$email','$password','$address','$number','$gender','$skill','$city','$destination')";


$insert= mysqli_query($conn, $sql);

if($insert){

	echo "<font color='green'> Registration Successfull </font>";
// 	header('location:login_cookie.php?reg=1');
}
else{
	echo "<font color='red'> Sorry, Registration not success </font>";
	// header('location:registration.php?reg=0');
}

}
else{
	echo "<font color='red'> Sorry, Email Id is already Exist</font>";
	// header('location:registration.php?reg=2');
}

?>