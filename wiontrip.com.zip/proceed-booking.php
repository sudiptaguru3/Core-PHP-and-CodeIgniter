<?php 
	include("z_db.php");
	include("Auth.php");
	$qre = mysqli_query($con,"select * from tempusermaster where id='".$_SESSION['MSRNO']."'");
	$res = mysqli_fetch_array($qre,MYSQLI_ASSOC);
	$agent_email = $res["email"];
	$contact_no = $res["contact_no"];
	
	if(isset($_POST['sbt']))
	{
		$email = mysqli_real_escape_string($con,trim($_POST['email']));
		$mobile = mysqli_real_escape_string($con,trim($_POST['mobile']));
		$ticket_id = mysqli_real_escape_string($con,trim($_POST['ticket_id']));
		$price = mysqli_real_escape_string($con,trim($_POST['price']));
		
		$title_inf = mysqli_real_escape_string($con,trim($_POST['title_inf']));
		$fname_inf = mysqli_real_escape_string($con,trim($_POST['fname_inf']));
		$lname_inf = mysqli_real_escape_string($con,trim($_POST['lname_inf']));
		$dob_inf = mysqli_real_escape_string($con,trim($_POST['dob_inf']));
		
		
		
		$status = "OK";
		$msg = "";
		
		$qre = mysqli_query($con,"SELECT * FROM ticket_master t where id='$ticket_id'");
		if(mysqli_num_rows($qre)>0)
		{
			$res = mysqli_fetch_array($qre,MYSQLI_ASSOC);
			$airline_id = $res["airline_id"];
			$flight_id = $res["flight_id"];
			$flight_date = $res["flight_date"];
			$price = $res["price"];
			$ttl = $res["price"]*$_SESSION['qty'];
			if($infant>0)
			{
				$ttl = $ttl+1500;	
			}
			
			$qre1 = mysqli_query($con,"select * from uwalletstatus where Msrno='".$_SESSION['MSRNO']."'");
			$res1 = mysqli_fetch_array($qre1,MYSQLI_ASSOC);
			if($res1["credit"]<$ttl)
			{
				$status = "NOTOK";
				$msg = "Insufficient Balance in your wallet";
			}
			
		}
		$k=1;
		$otp='';
		$otp  = mt_rand(100000, 999999999);
		
		while($k>0)
		{
			$qre = mysqli_query($con,"select * from booking_master where booking_PNR LIKE '%$otp%'");
			if(mysqli_num_rows($qre)==0)
			{
				$k=0;
			}
			else
			{
				$otp  = mt_rand(100000, 999999999);
			}
		}
		
		if($status=="NOTOK")
		{
			echo "<script>alert('$msg');window.location='dashboard.php';</script>";
		}
		else if($status=="OK")
		{
			mysqli_query($con,"insert into booking_master (booking_PNR,Msrno,airline_id,flight_id,ticket,fare,total_fare,email,phone,payment_method,payment_type,isactive,ondate,ticket_id,flight_date,destination_id) VALUES('$otp','".$_SESSION['MSRNO']."','$airline_id','$flight_id','".$_SESSION['qty']."','$price','$ttl','$email','$mobile','Wallet','By Wallet','1','$datedata','$ticket_id','$flight_date','".$_SESSION['des']."')");
			$last_id = mysqli_insert_id($con);
			$qty_minus = $_SESSION['qty'];
			mysqli_query($con,"update ticket_master set available_seat=available_seat-'$qty_minus' where id='$ticket_id'");
			if($_SESSION['ad']>0)
			{
				for($i=1;$i<=$_SESSION['ad'];$i++)
				{
					
					$title1 = 'title_a_'.$i;
					$fname1 = 'fname_a_'.$i;
					$lname1 = 'lname_a_'.$i;
					$title = mysqli_real_escape_string($con,trim($_POST[$title1]));
					$fname = mysqli_real_escape_string($con,trim($_POST[$fname1]));
					$lname = mysqli_real_escape_string($con,trim($_POST[$lname1]));
					mysqli_query($con,"insert into booking_detail (Msrno,booking_id,title,first_name,last_name,isactive,ondate) VALUES('".$_SESSION['MSRNO']."','$last_id','$title','$fname','$lname','1','$datedata')");
				}
			}
			
			if($_SESSION['ch']>0)
			{
				for($i=1;$i<=$_SESSION['ch'];$i++)
				{
					
					$title1 = 'title_c_'.$i;
					$fname1 = 'fname_c_'.$i;
					$lname1 = 'lname_c_'.$i;
					$dob1 = 'dob_c_'.$i;
					$title = mysqli_real_escape_string($con,trim($_POST[$title1]));
					$fname = mysqli_real_escape_string($con,trim($_POST[$fname1]));
					$lname = mysqli_real_escape_string($con,trim($_POST[$lname1]));
					$dob = mysqli_real_escape_string($con,trim($_POST[$dob1]));
					mysqli_query($con,"insert into booking_detail (Msrno,booking_id,title,first_name,last_name,isactive,ondate,child_dob) VALUES('".$_SESSION['MSRNO']."','$last_id','$title','$fname','$lname','1','$datedata','$dob')");
				}
			}
			if($_SESSION['inf']>0)
			{
				mysqli_query($con,"insert into booking_detail (Msrno,booking_id,title,first_name,last_name,isactive,ondate,child_dob) VALUES('".$_SESSION['MSRNO']."','$last_id','$title_inf','$fname_inf','$lname_inf','1','$datedata','$dob_inf')");
			}
			
			mysqli_query($con,"update uwalletstatus set credit=credit-'$ttl',debit=debit+'$ttl' where Msrno='".$_SESSION['MSRNO']."'");
			$qre = mysqli_query($con,"select * from uwalletstatus where Msrno='".$_SESSION['MSRNO']."'");
			$res = mysqli_fetch_array($qre,MYSQLI_ASSOC);
			$credit = $res["credit"];
			mysqli_query($con,"insert into uwalletdetails (Msrno,transwith,remark,transtype,debit,balance,isactive,ondate) VALUES('".$_SESSION['MSRNO']."','".$_SESSION['MSRNO']."','Booking Reference Id : $otp','Debit','$ttl','$credit','1','$datedata')");
			unset($_SESSION['des']);
			unset($_SESSION['dt']);
			unset($_SESSION['ad']);
			unset($_SESSION['ch']);
			unset($_SESSION['inf']);
			unset($_SESSION['ttl']);
			echo "<script>alert('Booking Has Been Successfully Done');window.location='sold-tickets.php';</script>";
		}
		
		
		
	}
?>
<!DOCTYPE html>
<html lang="en">


<?php include("headercss.php");?>
  <link href="http://www.jquerycookbook.com/demos/css/jquery-ui.css" rel="stylesheet" />
  <style type="text/css">
	.tbl tr th
	{
		padding:5px !important;	
	}
	.popup {
    width:100%;
    height:100%;
    display:none;
    position:fixed;
    top:0px;
    left:0px;
    background:rgba(0,0,0,0.75);
}
 
/* Inner */
.popup-inner {
    max-width:500px;
    width:90%;
    padding:40px;
    position:absolute;
    top:50%;
    left:50%;
    -webkit-transform:translate(-50%, -50%);
    transform:translate(-50%, -50%);
    box-shadow:0px 2px 6px rgba(0,0,0,1);
    border-radius:3px;
    background:#fff;
}
 
/* Close Button */
.popup-close {
    width:30px;
    height:30px;
    padding-top:4px;
    display:inline-block;
    position:absolute;
    top:0px;
    right:0px;
    transition:ease 0.25s all;
    -webkit-transform:translate(50%, -50%);
    transform:translate(50%, -50%);
    border-radius:1000px;
    background:rgba(0,0,0,0.8);
    font-family:Arial, Sans-Serif;
    font-size:20px;
    text-align:center;
    line-height:100%;
    color:#fff;
}
 
.popup-close:hover {
    -webkit-transform:translate(50%, -50%) rotate(180deg);
    transform:translate(50%, -50%) rotate(180deg);
    background:rgba(0,0,0,1);
    text-decoration:none;
}
.popup {
    background:rgba(0,0,0,0.75);
}
.popup-inner {
    position:absolute;
    top:50%;
    left:50%;
    -webkit-transform:translate(-50%, -50%);
    transform:translate(-50%, -50%);
}
.popup-close {
    transition:ease 0.25s all;
    -webkit-transform:translate(-50%, -50%);
    transform:translate(50%, -50%);
}
.popup-close:hover {
    -webkit-transform:translate(50%, -50%) rotate(180deg);
    transform:translate(50%, -50%) rotate(180deg);
    background:rgba(0,0,0,1);
}
</style>

<body>
	<!-- wrapper -->
    <form action="proceed-booking.php" method="post">
	<div class="wrapper">
		<!--sidebar-wrapper-->
		<?php include("sidemenu.php");?>
		<!--end sidebar-wrapper-->
		<!--header-->
		<?php include("header.php");?>
		<!--end header-->
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">.
            	
                <input type="hidden" name="ticket_id" value="<?php echo $_GET["sol"]; ?>" />
				<div class="page-content">
                
					
					<!--end row-->
					
					<!--end row-->
					
					<!--end row-->
					
					<!--end row-->
					
					<div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0">Adult(s)</h5>
							</div>
							<hr/>
							<div class="table-responsive">
                            	<?php 
									if($_SESSION['ad']>0)
									{
										for($i=1;$i<=$_SESSION['ad'];$i++)
										{?>
											<div class="row">
										<div class="col-12 col-lg-12 col-xl-3">
											<label for="validationServer01"><strong>Title</strong></label>
											<div class="input-group mb-4">
												<div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
												</div>
												<select class="form-control" name="title_a_<?php echo $i;?>" id="title_a_<?php echo $i;?>" required>
													<option value="Mr.">Mr.</option>
													<option value="Mrs." >Mrs.</option>
													<option value="Ms.">Ms.</option>
												</select>
												
											</div>
										</div>
										<div class="col-12 col-lg-12 col-xl-4">
											<label for="validationServer01"><strong>First Name</strong></label>
											<div class="input-group mb-4">
												<div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
												</div>
												<input type="text" class="form-control" value="<?php echo $fname;?>" required name="fname_a_<?php echo $i;?>" id="fname_a_<?php echo $i;?>"  placeholder="First Name">
												
											</div>
										</div>
										<div class="col-12 col-lg-12 col-xl-4">
											<label for="validationServer01"><strong>Last Name</strong></label>
											<div class="input-group mb-4">
												<div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
												</div>
												<input type="text" class="form-control" value="<?php echo $lname;?>" required name="lname_a_<?php echo $i;?>" id="lname_a_<?php echo $i;?>"  placeholder="Last Name">
												
											</div>
										</div>
										
									</div>		
										<?php }
									}
								?>
                                                            	
                            
								
							</div>
						</div>
					</div>
                    
                    <div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0">Child</h5>
							</div>
							<hr/>
							<div class="table-responsive">
                            	<?php 
									if($_SESSION['ch']>0)
									{
										for($i=1;$i<=$_SESSION['ch'];$i++)
										{?>
											<div class="row">
									
                                                <div class="col-12 col-lg-12 col-xl-3">
                                                    <label for="validationServer01"><strong>Title</strong></label>
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                                        </div>
                                                        <select class="form-control" name="title_c_<?php echo $i;?>"  id="title_c_<?php echo $i;?>" required>
                                                            <option value="MASTER">MASTER</option>
                                                            <option value="MISS" >MISS</option>
                                                        </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-12 col-xl-3">
                                                    <label for="validationServer01"><strong>First Name</strong></label>
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control" value="<?php echo $fname;?>" required name="fname_c_<?php echo $i;?>" id="fname_c_<?php echo $i;?>"  placeholder="First Name">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-12 col-xl-3">
                                                    <label for="validationServer01"><strong>Last Name</strong></label>
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control" value="<?php echo $lname;?>" required name="lname_c_<?php echo $i;?>" id="lname_c_<?php echo $i;?>"  placeholder="Last Name">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-12 col-xl-3">
                                                    <label for="validationServer01"><strong>DOB (2-11 years)</strong></label>
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control datepicker" value="<?php echo $lname;?>" required name="dob_c_<?php echo $i;?>" id="dob_c_<?php echo $i;?>"  placeholder="DOB (2-11 years)">
                                                        
                                                    </div>
                                                </div>
                                                
                                            </div>
										<?php }
									}	?>
                            	
                            	
                            
								
							</div>
						</div>
					</div>


					<div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0">Infant</h5>
							</div>
							<hr/>
							<div class="table-responsive">
                            	<?php 
									if($_SESSION['inf']>0)
									{
										?>
                                        	<div class="row">
									
                                    
                                    
                                                <div class="col-12 col-lg-12 col-xl-3">
                                                    <label for="validationServer01"><strong>Title</strong></label>
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                                        </div>
                                                        <select class="form-control" name="title_inf" id="title_inf" required>
                                                            <option value="Male">Male</option>
                                                            <option value="Female" >Female</option>
                                                        </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-12 col-xl-3">
                                                    <label for="validationServer01"><strong>First Name</strong></label>
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control" value="<?php echo $fname;?>" required name="fname_inf" id="fname_inf"  placeholder="First Name">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-12 col-xl-3">
                                                    <label for="validationServer01"><strong>Last Name</strong></label>
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control" value="<?php echo $lname;?>" required name="lname_inf" id="lname_inf"  placeholder="Last Name">
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-12 col-lg-12 col-xl-3">
                                                    <label for="validationServer01"><strong>DOB</strong></label>
                                                    <div class="input-group mb-4">
                                                        <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
                                                        </div>
                                                        <input type="text" class="form-control datepicker1" value="<?php echo $dob_inf;?>" required name="dob_inf" id="dob_inf"  placeholder="DOB">
                                                        
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        <?php 
											
									}	
										?>
                            	
                                
                            	
                            
								
							</div>
						</div>
					</div>
                    
                    <div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0">Flight Details</h5>
							</div>
							<hr/>
							<div class="table-responsive">
                            	
                            	<div class="row">
                                	<table class="table mb-0">
									<thead class="thead-dark">
										<tr>
											<th>Airlines</th>
											<th>Destination</th>
											<th>Flight No</th>
											<th>Date</th>
											<th>Dep</th>
                                            <th>Arr</th>
                                            <th>Qty.</th>
                                            <th>Deal</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											if(isset($_GET['sol']))
											{
												$sol = $_GET['sol'];
												
												$qre = mysqli_query($con,"select *,(SELECT dep_hour from airline_flight_no_master where id=f.flight_id)dep_hour,(SELECT dep_mint from airline_flight_no_master where id=f.flight_id)dep_mint,(SELECT arrival_hour from airline_flight_no_master where id=f.flight_id)arrival_hour,(SELECT arrival_mint from airline_flight_no_master where id=f.flight_id)arrival_mint,(SELECT city_name from airport_master where id=f.from_city)from_city_name,(SELECT city_name from airport_master where id=f.to_city)to_city_name from (select *,(SELECT from_city from destination_master where id=j.destination_id)from_city,(SELECT to_city from destination_master where id=j.destination_id)to_city from (SELECT *,(SELECT logo from airline_master where id=t.airline_id)airline_logo,(SELECT airline from airline_master where id=t.airline_id)airline_name,(select flight_number from airline_flight_no_master where id=t.flight_id)flight_number,(select destination_id from airline_flight_no_master where id=t.flight_id)destination_id,(case when isactive='1' then 'Active' else 'Deactive' end)status,(case when isactive='1' then 'Deactive' else 'Active' end)st FROM ticket_master t where id='$sol' ) j ) f");
												if(mysqli_num_rows($qre)>0)
												{
													$res = mysqli_fetch_array($qre,MYSQLI_ASSOC);
													$ttl = $res["price"]*$_SESSION['qty'];
													if($_SESSION['inf']>0)
													{
														$ttl = $ttl+1500;	
													}
													echo "<input type='hidden' id='from_city_name' value='".$res["from_city_name"]." To ".$res["to_city_name"]."'/>";
													echo "<input type='hidden' id='flight_number' value='".$res["flight_number"]."'/>";
													echo "<input type='hidden' id='dep_hour' value='".$res["dep_hour"]." : ".$res["dep_mint"]."'/>";
													echo "<input type='hidden' id='arrival_hour' value='".$res["arrival_hour"]." : ".$res["arrival_mint"]."'/>";
													echo "<input type='hidden' id='ttl' value='".$ttl."'/>";
													echo "<input type='hidden' id='single_price' value='".$res["price"]."'/>";
													
													echo "<input type='hidden' id='airline_name' value='".$res["airline_name"]."'/>";
													
													$data_table .="<tr>";
													$data_table .="<td><img src='2021/productimg/".$res["airline_logo"]."' width='70' height='70' alt=' ' /></td>";
													$data_table .="<td><strong>".$res["from_city_name"]." to ".$res["to_city_name"]."</strong></td>";
													$data_table .="<td><strong>".$res["flight_number"]."</strong></td>";
													$data_table .="<td><strong>".$_SESSION['dt']."</strong></td>";
													$data_table .="<td><strong>".$res["dep_hour"]." : ".$res["dep_mint"]."</strong></td>";
													$data_table .="<td><strong>".$res["arrival_hour"]." : ".$res["arrival_mint"]."</strong></td>";
													$data_table .="<td><strong>".$_SESSION['qty']."</strong></td>";
													$data_table .="<td><strong>".$ttl."</strong></td>";
													$data_table .="</tr>";
												}
												else
												{
													echo "<script>window.location='dashboard.php';</script>";
												}
											}
											echo $data_table;
										?>
									</tbody>
								</table>
									                                    
                                    
                                </div>
                                
							</div>
						</div>
					</div>
                    
                    
                    
                    <div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h5 class="mb-0">Booking Details</h5>
							</div>
							<hr/>
							<div class="table-responsive">
                            	
                            	<div class="row">
									
                                    
                                    
                                    <div class="col-12 col-lg-12 col-xl-3">
                                    	<label for="validationServer01"><strong>Email Id</strong></label>
                                    	<div class="input-group mb-4">
                                            <div class="input-group-prepend">	<span class="input-group-text"><i class="bx bx-user"></i></span>
                                            </div>
                                            <input type="email" class="form-control" value="<?php echo $agent_email;?>" id="email" required name="email"  placeholder="Email ID">
                                            
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-12 col-xl-3">
                                    	<label for="validationServer01"><strong>Phone no</strong></label>
                                    	<div class="input-group mb-4">
                                            <div class="input-group-prepend"><span class="input-group-text"><i class="bx bx-user"></i></span>
                                            </div>
                                            <input type="text" class="form-control" value="<?php echo $contact_no;?>" id="mobile" required name="mobile"  placeholder="Phone no">
                                            
                                        </div>
                                    </div>
                                    
                                    <div class="col-12 col-lg-12 col-xl-3">
                                    	<label for="validationServer01"><strong>&nbsp;</strong></label>
                                    	<div class="input-group mb-4">
                                            
                                            <a href="javascript:void(0);" class="btn btn-success" onClick="view_table();"  >Submit & Continue</a>
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                                
                            	
                            
								
							</div>
						</div>
					</div>                    
                    
                    
                    
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<!--footer -->
		<div class="footer">
			<p class="mb-0">WION TRIP @2021 | Developed By : <a href="http://happyweb.in/" target="_blank">Happy Web</a>
			</p>
		</div>
		<!-- end footer -->
	</div>
	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<?php include("footerjs.php");?>
    <script src="http://www.jquerycookbook.com/demos/scripts/jquery-1.11.1.min.js"></script>
    <script src="http://www.jquerycookbook.com/demos/scripts/jquery-ui.min.js"></script>
  <script>
	
/*var dates = ["05-02-2021", "06-02-2021", "07-02-2021", "09-02-2021"];
 
function DisableDatess(date) {
	alert(date);
    var string = jQuery.datepicker.formatDate('dd-mm-yy', date);
    return [dates.indexOf(string) == -1];
}
function make(date)
{
	alert(date);
}

$(document).ready(function () {
	alert(date);
});*/
 /* function make_date()
  {
	var dest = $("#destination").val();
	if(dest>0)
	{
		$.ajax({ type: "GET",   
		 url: "pst.php?dest="+dest,   
		 async: false,
		 success : function(text)
		 {
				
					 $("#datepicker").datepicker({
						 beforeShowDay: DisableDatess
					 });
				
		 }
		});
	}

  }*/
  $( function() {
   $( ".datepicker" ).datepicker({ minDate: "-11Y" ,changeMonth: true,changeYear: true,dateFormat:"dd-mm-yy"});
  } );
  $( function() {
   $( ".datepicker1" ).datepicker({ minDate: "-3Y" ,changeMonth: true,changeYear: true,dateFormat:"dd-mm-yy"});
  } );
  function view_table()
  {
  		$("#email1").empty();
		$("#email1").html($("#email").val());
		
		$("#mobile1").empty();
		$("#mobile1").html($("#mobile").val());
		
		$("#price1").empty();
		$("#price1").html($("#single_price").val());
		
		$("#ttl1").empty();
		$("#ttl1").html($("#ttl").val());
		
		$("#destination1").empty();
		$("#destination1").html($("#from_city_name").val());
		var dt = '<?php echo $_SESSION['dt'];?>';
		$("#time1").empty();
		$("#time1").html(dt+" "+$("#dep_hour").val());
		
		$("#time2").empty();
		$("#time2").html(dt+" "+$("#arrival_hour").val());
		
		$("#airline1").empty();
		$("#airline1").html($("#airline_name").val());
		
		
		$("#suges").fadeIn(350);
		
		var ad = '<?php echo $_SESSION['ad'];?>';
		var ch = '<?php echo $_SESSION['ch'];?>';
		var inf = '<?php echo $_SESSION['inf'];?>';
		var data = "<table><tr><th>Title</th><th>First Name</th><th>Last Name</th></tr>";
		if(ad>0)
		{
			
			for(i=1;i<=ad;i++){
				
				data +="<tr><th>"+$("#title_a_"+i).val()+"</th><th>"+$("#fname_a_"+i).val()+"</th><th>"+$("#lname_a_"+i).val()+"</th></tr>";
			}
			
			
			
			
		}
		if(ch>0)
		{
			
			for(i=1;i<=ch;i++){
				
				data +="<tr><th>"+$("#title_c_"+i).val()+"</th><th>"+$("#fname_c_"+i).val()+"</th><th>"+$("#lname_c_"+i).val()+" (DOB : "+$("#dob_c_"+i).val()+")</th></tr>";
			}
			
			
			
		}
		
		if(inf>0)
		{
			
			data +="<tr><th>"+$("#title_inf").val()+"</th><th>"+$("#fname_inf").val()+"</th><th>"+$("#lname_inf").val()+" (DOB : "+$("#dob_inf").val()+")</th></tr>";
			
			
			
		}
		data += "</table>";
		$("#tbl1").empty();
		$("#tbl1").html(data);
  }
  
  	$(document).ready(function ()
	{
		
	});

function closess1()
{
	$("#suges").fadeOut(350);
}
  </script>
  <div class="popup" id="suges" data-popup="popup-1">
    <div class="popup-inner">
        <table class="tbl">
        	<tr style="background:#0367A0;">
            	<th colspan="2" align="center" style="color:#FFFFFF;">Contact Details</th>
            </tr>
            <tr>
            	<th >Email ID</th>
                <th id="email1"></th>
            </tr>
            <tr>
            	<th>Phone No</th>
                <th id="mobile1"></th>
            </tr>
            <tr style="background:#0367A0;">
            	<th colspan="2" align="center" style="color:#FFFFFF;"> Passenger Details </th>
            </tr>
            <tr>
            	<th colspan="2" id="tbl1">
                	
                </th>
            </tr>
            <tr style="background:#0367A0;">
            	<th colspan="2" align="center" style="color:#FFFFFF;">  Flight Details  </th>
            </tr>
            <tr>
            	<th colspan="2">
                	<table class="">
                    	 <tr>
                         	<th colspan="4"><h5 id="destination1">Ranchi to Mumbai</h5></th>
                        </tr>
                        <tr>
                        	<th>Airline</th>
                            <th id="airline1">GoAir</th>
                            <th>Departure</th>
                            <th id="time1"></th>
                        </tr>
                        <tr>
                        	<th>Arrival</th>
                            <th id="time2"></th>
                            <th>Total Seat</th>
                            <th><?php echo $_SESSION['qty'];?></th>
                        </tr>
                        <tr>
                        	<th>Adult(s) Price</th>
                            <th id="price1"></th>
                            <th>Total Pay</th>
                            <th id="ttl1">4,100</th>
                        </tr>
                   </table>
               </th>
            </tr>   
            <tr>
            	<th><a data-popup-close="popup-1" href="javascript:void(0);" onClick="closess1();" id="close" class="btn btn-success">Close</a></th>
                <th><input type="submit" class="btn btn-success" value="Confirm" name="sbt" /></th>
            </tr>          
        </table>
        
       
    </div>
</div>
</form>
</body>


</html>