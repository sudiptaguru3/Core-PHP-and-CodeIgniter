<?php
echo date("Y-M-D");
echo "<br>";
echo date("Y/m/d");
echo "<br>";
echo date("y-m-d");
echo "<br>";
echo "Today is: ".date("l");
echo "<br>";
echo date("h:i:s a");
echo "<br>";
echo date("H:i:s A");
echo "<br>";
date_default_timezone_set(
	"Asia/Kolkata");
echo "Today Time is: ".date("h:i:s a");
echo "<br>";
// $date=date("2020-12-09");
// $date1=date("2020-10-05");
$d= strtotime("1990-02-04");
echo date('Y-m-d',$d).'<br>';
$e= strtotime("tomorrow");
echo date("Y-m-d H:i:s a",$e).'<br>';
$f= strtotime("+2 Days");
echo date("d-m-Y",$f);
?>