<?php
$date1= date_create("1999-10-20");
// echo date_format($date1, "Y-m-d");
// echo $date1;
$date2= date_create(date("Y-m-d"));
$diff= date_diff($date2, $date1);
// echo $diff;
// echo date_format($diff, "Y-m-d");
echo $diff->format("%y year %m month %d days");


?>