-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2021 at 03:26 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oli_asset_inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `id` int(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=Active,0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `full_name`, `email`, `password`, `mobile`, `user_role`, `profile_pic`, `status`) VALUES
(1, 'Sudipta', 'sudipta@gmail.com', '11111', '1234567890', 'admin', 'sdf.jpg', 0),
(2, 'Sudipta Guru', 'sudipta1@gmail.com', '11111', '1234567890', 'admin', 'as.jpg', 1),
(3, 'Sudipta Guru', 'sudipta@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'Super Admin', 'photo-1556830805-7cec0906aee6.jpg', 1),
(4, 'Sudipta Guru', 'sudipta@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '1234567890', 'Employee', 'photo-1556830805-7cec0906aee6.jpg', 0),
(5, 'Sudipta Guru', 'sudipta@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'Employee', 'photo-1556830805-7cec0906aee6.jpg', 0),
(6, 'Sudipta Guru', 'sudipta@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'Employee', 'photo-1556830805-7cec0906aee6.jpg', 0),
(7, 'Sudipta Guru', 'sudipta@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'Employee', 'photo-1556830805-7cec0906aee6.jpg', 0),
(8, 'Sudipta Guru', 'sudipta@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'Employee', 'photo-1556830805-7cec0906aee6.jpg', 0),
(9, 'Sudipta Guru', 'sudipta@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'Employee', 'photo-1556830805-7cec0906aee6.jpg', 0),
(10, 'Sudipta Guru', 'sudipta@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'Employee', 'photo-1556830805-7cec0906aee6.jpg', 0),
(11, 'Sudipta Guru', 'sudipta@gmail.com', 'b0baee9d279d34fa1dfd71aadb908c3f', '1234567890', 'Employee', 'photo-1556830805-7cec0906aee6.jpg', 0),
(12, 'Sudipta Guru', 'sudipta@gmail.com', '0d54b84e69cc502601360b10b6b3f40c', '', 'Select', '', 1),
(13, '', '', '', '', '', 'photo-1550028061-1de667deea35.jpg', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_user`
--
ALTER TABLE `admin_user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
