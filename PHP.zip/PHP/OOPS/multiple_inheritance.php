<?php
Interface A{
	function bbd();
	function abc();
}
Interface B{
	function pqr();
}
Class C implements A,B{
	function bbd(){
		echo "PHP";
	}
	function abc(){
		echo "Hello";
	}
	function pqr(){
		echo "learning";
	}
}
$obj=new C();
$obj->bbd();
$obj->pqr();
$obj->abc();
?>