<?php
$con = mysqli_connect("localhost","root","","example_db");
?>