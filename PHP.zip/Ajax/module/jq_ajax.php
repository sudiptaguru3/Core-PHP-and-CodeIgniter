<!DOCTYPE html>
<html>
<head>
	<title> JQuery Ajax</title>
<script
        src="http://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
        crossorigin="anonymous">
  </script>
<script>
	$(document).ready(function(){
		$("#btn").click(function(){
		  var text= $("#txt").val();
			$.ajax({
			  url:'jq_send.php',
              type:'POST',
              data:{'send_text':text},
              success:function(d){
                $("#p1").html(d);
			}

		})
	
	})
})
</script>

</head>

<body>
<input type="text" id="txt" name="nme">
<input type='submit' id="btn" value='click'>
<p id="p1"></p>
</body>

</html>



