<?php
 $ar="a/b-c/d-e/f";
 echo "<pre>";
 $ar1=explode('/', $ar);
 echo "<pre>";
 $ar2=implode('-', $ar1);
 echo "<pre>";
 $ar3=explode('-', $ar2);
 print_r($ar3);
?>