<head>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<title>WION TRIP : Dashboard</title>
	<!--favicon-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="icon" href="assets/images/favicon-32x32.png" type="image/png" />
	<!-- Vector CSS -->
	<link href="assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
	<!--plugins-->
	<link href="assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
	<link href="assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
	<link href="assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
	<!-- loader-->
	<link href="assets/css/pace.min.css" rel="stylesheet" />
	<script src="assets/js/pace.min.js"></script>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
	<!-- Icons CSS -->
	<link rel="stylesheet" href="assets/css/icons.css" />
	<!-- App CSS -->
	<link rel="stylesheet" href="assets/css/app.css" />
	<link rel="stylesheet" href="assets/css/dark-sidebar.css" />
	<link rel="stylesheet" href="assets/css/dark-theme.css" />
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  $( function() {
    $( "#datepicker1" ).datepicker();
  } );
  </script>
  </script>
	<style>
.button {
  background-color: #4CAF50; /* Green */
  border-radius: 25px;
  color: white;
  padding: 5px 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
/*.buttonn {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}*/

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
  border-radius: 25px;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
  border-radius: 25px;
}

.button2 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
  border-radius: 25px;
}

.button2:hover {
  background-color: #008CBA;
  color: white;
  border-radius: 25px;
}

.button3 {
  background-color: white; 
  color: black; 
  border: 2px solid #f44336;
  border-radius: 25px;
}

.button3:hover {
  background-color: #f44336;
  color: white;
  border-radius: 25px;
}

.button4 {
  background-color: white; 
  color: black; 
  border: 2px solid #008CBA;
  border-radius: 25px;
}

.button4:hover {
  background-color: #008CBA;
  color: white;
  border-radius: 25px;
}

.button5 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  border-radius: 25px;
}

.button5:hover {
  background-color: #555555;
  color: white;
  border-radius: 25px;
}
.button6 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  border-radius: 25px;
}

.button6:hover {
  background-color: #555555;
  color: white;
  border-radius: 25px;
}
.button7 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  border-radius: 25px;
}

.button7:hover {
  background-color: #555555;
  color: white;
  border-radius: 25px;
}
.button8 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  border-radius: 25px;
}

.button8:hover {
  background-color: #555555;
  color: white;
  border-radius: 25px;
}
.button9 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  border-radius: 25px;
}

.button9:hover {
  background-color: #555555;
  color: white;
  border-radius: 25px;
}
.button10 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  border-radius: 25px;
}

.button10:hover {
  background-color: #555555;
  color: white;
  border-radius: 25px;
}
.button11 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  border-radius: 25px;
}

.button11:hover {
  background-color: #555555;
  color: white;
  border-radius: 25px;
}
.button12 {
  background-color: white;
  color: black;
  border: 2px solid #555555;
  border-radius: 25px;
}

.button12:hover {
  background-color: #555555;
  color: white;
  border-radius: 25px;
}
</style>
</head>