
<?php 
$subjectVal = "admin@gmail.com";  
$resStr = str_replace('@', '.', $subjectVal); 
$exploded= explode(".", $resStr);
echo "<pre>";
$ar= print_r($exploded);

?>
<!-- print str_replace($q,$hj,$newString); -->