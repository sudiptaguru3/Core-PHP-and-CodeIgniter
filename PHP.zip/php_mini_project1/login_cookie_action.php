<?php
session_start();
include "connect.php";

$email= $_REQUEST['email'];
$password= md5($_REQUEST['password']);
$cookie_password= md5($_REQUEST['password']);

$sql="SELECT * FROM user WHERE email='".$email."' AND password='".$password."'";
$data= mysqli_query($conn, $sql);

if(mysqli_num_rows($data)==1){
	$fetch=mysqli_fetch_array($data);
	if($fetch['status']==0){

		if(isset($_REQUEST['remember'])){
			setcookie('email',$email,time()+60*60*24);
			setcookie('password',$cookie_password,time()+60*60*24);
		}
		else{
			setcookie('email',$email,time()-60*60*24);
			setcookie('password',$cookie_password,time()-60*60*24);
		}
		$_SESSION['id']=$fetch['id'];
		echo "Login Sucessful";
	}
	else{
		echo "Admin has blocked You";
	}
}
else{
	echo "Login Failed";
}
?>