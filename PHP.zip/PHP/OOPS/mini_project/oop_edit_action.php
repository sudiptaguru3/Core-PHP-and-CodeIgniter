<?php
session_start();
include "query.php";
$id=$_SESSION['id'];
$obj=new oop();
$name=$_REQUEST['user'];
$email=$_REQUEST['mail'];
$phone=$_REQUEST['phone'];

if(!empty($_FILES['file'])){
$filename= $_FILES['file']['name'];
$tmpname= $_FILES['file']['tmp_name'];
$destination= 'upload/'.rand().$filename;
move_uploaded_file($tmpname, $destination);
}

$update=$obj->update($name,$email,$phone,$destination,$id);

if($update){
	header("location:oop_profile.php");
}
else{
	header("location:oop_edit.php");
}
?>