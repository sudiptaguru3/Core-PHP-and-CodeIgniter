<?php
class in{
	function abc()
	{
		echo "Hello";
	}
}
class out extends in{
	function pqr()
	{
		echo "Hii";
	}
}
class over extends out{
	function xyz()
	{
		echo "Bye!!";
	}
}
$obj=new over();
$obj->abc();
$obj->pqr();
$obj->xyz();
?>