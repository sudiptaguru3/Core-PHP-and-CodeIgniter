<?php
$ar= array('1'=>'Blue','2'=>'Yellow','3'=>'Black');
$ar1= ['name'=>'Sudipta','Address'=>'Bamanpukur','State'=>'WB'];
echo "<pre>";
print_r($ar);
echo "<br>";
print_r($ar1);

?> 