<?php
echo $_REQUEST['send_text'];
?>