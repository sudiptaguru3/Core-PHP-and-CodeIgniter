<?php
 $st="admin@gmail.com";
 echo "<pre>";
 $ar=explode("@", $st);
 echo "<pre>";
 $ar1=implode(".", $ar);
 echo "<pre>";
 $ar2=explode(".", $ar1);
 $ar3=array("name","domain","extension");
 $ar4=array_combine($ar3, $ar2);
 print_r($ar4);
 
?>