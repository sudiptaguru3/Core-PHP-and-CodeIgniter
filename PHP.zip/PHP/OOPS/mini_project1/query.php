<?php  
class oop{
	public $con;
	function __construct(){
		$this->con=mysqli_connect("localhost","root","","oops");
	}

	function insert($name,$email,$password,$number,$path)
	{
		$ins=mysqli_query($this->con,"INSERT INTO oops VALUES('','$name','$email','$password','$number','$path')");
		return $ins;
    }

	function check_mail($email){
		$check= mysqli_query($this->con,"SELECT * FROM oops WHERE email='".$email."'");
	$row= mysqli_num_rows($check);
		return $row;
	}

	function login($email,$password){
		echo "SELECT * FROM oops WHERE email='$email'AND password='$password'"; exit;
		$login=mysqli_query($this->con,"SELECT * FROM oops WHERE email='$email'AND password='$password'");
		return $login;
	}

	function profile($id)
	{
		$pro=mysqli_query($this->con,"SELECT * FROM oops WHERE id ='".$id."'");
		return $pro;
	}
	
	function update($name,$email,$phone,$destination,$id)
	{
		$update=mysqli_query($this->con,"UPDATE oops SET name='$name',email='$email',phone='$phone',file='$destination' WHERE id ='$id'");
		return $update;
	}
}
?>