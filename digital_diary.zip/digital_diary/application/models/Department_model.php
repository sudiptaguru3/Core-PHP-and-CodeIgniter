<?php
  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Department_model extends CI_Model 
{
	
	function saverecords($data)
	{
          $this->db->insert('department',$data);
          return $this->db->insert_id();
	}

	public function get_data($id=0)
	{
		if($id==0)
		{
			$query = $this->db->get('department')->result();
			return $query;
		}
		else
		{
			$this->db->where('id',$id);
			$query = $this->db->get('department')->result();
			return $query;
		}
		
	}


	public function upddata($data,$id)       
	{
	    extract($data); 
	    $this->db->where('id', $id);
	    // $this->db->update($table_name, array('full_name' => $full_name, 'email' =>$email, 'mobile' =>$mobile, 'status' =>$status, 'user_role' =>$user_role, 'profile_pic'=>$profile_pic));
	    $this->db->update('department', $data);
	    return true;
	}

	public function delete_data($id)
	{
	    $this -> db -> where('id', $id);
	    $this -> db -> delete('department');
	}

	public function update_status($status,$id)
	{
    	$this->db->query("UPDATE department SET status = '$status' WHERE id = '$id' ");
    	return true;
	}

}
?>
