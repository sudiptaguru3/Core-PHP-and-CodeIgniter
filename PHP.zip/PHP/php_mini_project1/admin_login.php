<?php
if(isset($_REQUEST['admin']) && $_REQUEST['admin'] == 0){
    echo "<font color='red'>Admin Login Unsuccessfull</font>";
}
?>
<h2>Admin Login</h2>
<form action="admin_login_action.php" method="post">
	Email:<input type="email" name="ad_email"><br><br>
	Password:<input type="password" name="ad_pass"><br><br>
	<input type="submit" name="sbm" value="Login">

</form>