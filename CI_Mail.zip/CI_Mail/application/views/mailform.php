<?php
if (isset($message_display)) {
echo $message_display;
}
?>
<form method="post" action="<?php echo base_url().'index.php/MailSend/Sent';?>">
    
	Your Email Id:
	<input type="email" name="user_email"
    placeholder="Enter your email id"><br><br>

	Your Password:
	<input type="password" name="user_password" placeholder="Enter your email password"><br><br>

	To: 
	<input type="email" name="to_email" placeholder="Enter receivers email id"><br><br>

    Username:
    <input type="text" name="name" placeholder="Enter an username"><br>
    <br>

    Subject:
    <input type="text" name="subject" placeholder="Enter the subject"><br><br>

    Body:
    <input type="text" name="message" placeholder="Enter the mail body"><br><br>

   <input type="submit" name="submit" value="SUBMIT">
   <input type="reset" name="set" value="REFRESH">
</form>