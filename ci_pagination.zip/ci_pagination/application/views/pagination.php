
               
<!DOCTYPE html>
<html lang="en">
    <head>
        <style type="text/css">
       .green1
    {
        color: #4CAF50;
        
    }
    .red1
    {
         color: red; 
    }
    </style>
        <meta charset="utf-8">
        <title>CRUD Operation</title>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/material-fullpalette.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">


    </head>
    <body>
        <div class="container">
            <div class="row jumbotron">
               <a href="<?php echo base_url('admin_user'); ?>">Add New</a>
                </div>
            
           
            <div class="row jumbotron">
    <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>
    <form>
                <div class="col-md-12">
                
                            <fieldset>
                <table id="myTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Course</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php

                    $i=1;
                    foreach ($student as $res)
                     {
                       $id=$res->id;

                       
                  ?>
                  
                  <tr>
                    <!-- <td><?php echo $i;?></td> -->
                    <td><?php echo $res->id;?></td>
                    <td><?php echo $res->name;?></td>
                    <td><?php echo $res->email;?> </td>
                    <td><?php echo $res->course;?></td>
                    <td><a href="<?php echo base_url('Student/edit/'.$id);?>" ><i class="fas fa-edit"></i></a> &nbsp; <a  href="<?php echo base_url('Student/delete_row/'.$id);?>" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="fas fa-trash-alt" style="color: red;"></i></a></td>
                  </tr>
                  <?php 
                    $i++;
                    }
                  ?>
                
                  </tbody>
                 
                </table>
                <p><?php echo $links; ?></p>
            </fieldset>
                       
                    </div>
                           
                           </form>
    </div>
            
            <div class="row">
                <div class="alert alert-dismissable alert-success" style="display: none">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Data inserted successfully</strong>.
                </div>
                
                <div class="alert alert-dismissable alert-danger"  style="display: none">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Sorry something went wrong</strong>
                </div>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/material.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
    </body>
</html>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">