<?php
include 'query.php';
$obj=new oop();

$name = $_REQUEST['user'];
$email = $_REQUEST['email'];
$password = md5($_REQUEST['password']);
$number = $_REQUEST['phone'];
$filename = $_FILES['file']['name'];
$tmpName = $_FILES['file']['tmp_name'];
$path = 'upload/'.rand().$filename;
move_uploaded_file($tmpName, $path);

$check= $obj->check_mail($email);

if($check>0){
	echo "<font color='red'> Email Id Already Exists</font>";

}
else{
$ins=$obj->insert($name,$email,$password,$number,$path);

if($ins){
	header("location:oop_login.php");
	 //echo "<font color='green'>Registration Success</font>";

}
else{
    header("location:oop_reg.php");
     //echo "<font color='red'>Registration UnSuccess</font>";
}
}
?>