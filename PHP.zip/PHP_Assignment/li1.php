<?php
$people = array('green','red','white');
for($i=0; $i<count($people); $i++) {  //end when $i is larger than amount of people
    echo "  <li>{$people[$i]}</li>\n";
}
?>