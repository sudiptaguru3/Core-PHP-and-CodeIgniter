<?php 
	include("z_db.php");
	include("Auth.php");
	
	if(isset($_GET['dest']))
	{
		$ar = array();
		$dest = mysqli_real_escape_string($con,trim($_GET['dest']));
		$qre = mysqli_query($con,"select flight_date from ticket_master where flight_id in (select id from airline_flight_no_master where destination_id='$dest') and isexpire='0'");
		if(mysqli_num_rows($qre)>0)
		{
			while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
			{
				
				
				array_push($ar,array($res["flight_date"]));
			}
		}
		//var_dump($ar);
		echo $ar;
	}
?>