<?php
session_start();
include "connect.php";

$id=$_SESSION['id'];

$name= $_REQUEST['user'];
$address= $_REQUEST['address'];
$number= $_REQUEST['phone'];
$gender= $_REQUEST['gen'];
$skill= implode(',', $_REQUEST['skill']);
$city= $_REQUEST['city'];

if(!empty($_FILES['file'])){
$filename= $_FILES['file']['name'];
$tmpname= $_FILES['file']['tmp_name'];
$destination= 'uploads/'.rand().$filename;
move_uploaded_file($tmpname, $destination);
}

if(empty($_FILES['file']['name'])){
$sql="UPDATE user SET name='$name', address='$address', contact='$number', gender='$gender', skill='$skill', city='$city' WHERE id='".$id."'";
}
else{
$sql="UPDATE user SET name='$name', address='$address', contact='$number', gender='$gender', skill='$skill', city='$city', file='$destination' WHERE id=".$id;
}
$update= mysqli_query($conn, $sql);

if($update){
	header('location:profile.php?update=1');
}
else{
	header('location:editprofile.php?update=0');
}
?>