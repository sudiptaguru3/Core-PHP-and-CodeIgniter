<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_user extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		// $this->load->database();
		// $this->load->model('Category_model');
	}

	public function index()
	{

	   	$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$this->load->view('admin_user_add');
		$this->load->view('include/footer');
	}

	public function add_user()
	{
		// echo "<pre>";
		// print_r($_FILES);

		$data['full_name']=$this->input->post('full_name');
		$data['email']=$this->input->post('email');
		$data['password']=md5($this->input->post('password'));
		$data['mobile']=$this->input->post('mobile');
		$data['user_role']=$this->input->post('user_role');
		$data['profile_pic']=$_FILES['profile_pic']['name'];
		

//-------------------------file upload code---------------------------

//Check whether user upload picture
            if(!empty($_FILES['profile_pic']['name'])){
                $config['upload_path'] = 'uploads/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['file_name'] = $_FILES['profile_pic']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('profile_pic')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }

		
		$this->load->model('Admin_user_model');
		 $user=$this->Admin_user_model->saverecords($data); 

		if($user >0)
			{
	
			        redirect('View_all_admin_user');
			}
			else
			{
					echo "Insert error !";
			}

	}


}

?>	
	