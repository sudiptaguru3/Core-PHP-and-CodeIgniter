<?php
$dt = strtotime("2012-12-21");
echo date("Y-m-d", strtotime("+1 month", $dt))."\n";
?>