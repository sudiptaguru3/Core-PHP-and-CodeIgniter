<?php
include "connection.php";
$id=$_REQUEST['send_edit_id'];
$sql=mysqli_query($conn,"SELECT * FROM user WHERE id='".$id."'");
$data = mysqli_fetch_array($sql);

?>
<script
        src="http://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
        crossorigin="anonymous">
 </script>
<script type="text/javascript">
 
     function edit_user(id){

    var name = $("#user").val();
		//var email = $("#mail").val();
    var add = $("#add").val();
    var num = $("#nmbr").val();
        

        $.ajax({
			type:'POST',
			url:'edit_user.php',
			data: {
				edit_id:id,
			    edit_name:name,
				edit_add:add,
				edit_num:num
            },
	success:function(result){
		 $("#result-div").html(result);
         setTimeout(function(){ window.location.reload(); 
         }, 1000);
		
	   }	
    });      
}
 
</script>

<form action="" method="POST" enctype="multipart/form-data" >
    
    Name:<input type="text" id="user" name='user' value="<?php echo $data['name'];?>" ><br><br>

    Email:<input type="text" id="mail" name='email' value="<?php echo $data['email'];?>" readonly><br><br>

    Address:<textarea name='address' rows='5' cols='10' id="add"><?php echo $data['address'];?></textarea><br><br>

    Number:<input type="number" id="nmbr" name='phone' value="<?php echo $data['contact'];?>"><br><br>

  <!--  File:<input type="file" id="fle" name='file'><img src="<?php echo $data['file'];?>" height="300px" width="400px"><br><br> -->

    <input type="reset" value='Reset'>
    <input type="button"  id="sbmit" value="Update" onclick="edit_user(<?php echo $data['id'];?>)">
</form>
<div id="result-div"></div>


