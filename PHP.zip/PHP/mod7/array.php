<?php
$str= 'one/two/three/four';
echo "<pre>";
print_r(explode('/',$str,2));
print_r(explode('/',$str,-1));

?>