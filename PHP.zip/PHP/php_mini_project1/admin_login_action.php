<?php
include "connect.php";
$email=$_REQUEST['ad_email'];
$password=$_REQUEST['ad_pass'];

$sql=mysqli_query($conn,"SELECT * FROM admin WHERE email='$email' AND password='$password'");

if(mysqli_num_rows($sql)==1)
{
	$fetch=mysqli_fetch_array($sql);
	 $_SESSION['id'] = $fetch['id'];
	 header("location:admin_profile.php?admin=1");
}
else
{
	 header("location:admin_login.php?admin=0");
}
?>