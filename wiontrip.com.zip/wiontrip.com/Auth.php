<?php 
session_start();

// Check, if username session is NOT set then this page will jump to login page
if (!isset($_SESSION['MSRNO'])) {
        print "
				<script language='javascript'>
					window.location = 'logout.php';
				</script>
			";
}
?>