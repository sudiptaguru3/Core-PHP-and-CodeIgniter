<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$dbname = 'phpconnect2';

$conn= mysqli_connect($hostname, $username,$password,$dbname);
if(!$conn){
	die('Could not connect:'.mysqli_connect_error());

}
echo '<h3> Connected Successfully </h3> <br>';

$sql= 'CREATE TABLE user(id INT(11) AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL,  password VARCHAR(255) NOT NULL,  address VARCHAR(255) NOT NULL,  contact VARCHAR(255) NOT NULL,  gender VARCHAR(255) NOT NULL,  skill VARCHAR(255) NOT NULL,  city VARCHAR(255) NOT NULL,  file VARCHAR(255) NOT NULL)';

if(mysqli_query($conn,$sql)){
	echo "<h3> Table User Created Successfully </h3>";
}
else{
	echo "<h3> Sorry, Could not Create the table </h3>".mysqli_error($conn);
}


?>