<?php
session_start();
include "connect.php";
$id=$_SESSION['id'];

$name=$_REQUEST['user'];
$address=$_REQUEST['address'];
$number=$_REQUEST['phone'];
$gender=$_REQUEST['gen'];
$skill=implode(',', $_REQUEST['skill']);
$city=$_REQUEST['city'];

if(!empty($_FILES['file'])){
$filename = $_FILES['file']['name'];
$tmpName = $_FILES['file']['tmp_name'];
$destination = 'uploads/'.rand().$filename;
move_uploaded_file($tmpName, $destination);
}

if(empty($_FILES['file']['name'])){
$update=mysqli_query($conn,"UPDATE user SET name='$name',address='$address', contact='$number', skill='$skill',gender='$gender',city='$city' WHERE id=".$id);
}else{
$update=mysqli_query($conn,"UPDATE user SET name='$name',address='$address', contact='$number', skill='$skill',gender='$gender',city='$city', file='$destination' WHERE id=".$id);
}

if($update)
{
	header("location:profile.php?update=1");
}
else
{
	header("location:editProfile.php?update=0");
}

?>