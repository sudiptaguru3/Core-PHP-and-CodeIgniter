<?php
$target_dir = "uploads/";
$target_file = $target_dir.basename(
	           $_FILES['fileup']['name']); 


if(move_uploaded_file($_FILES['fileup']['tmp_name'], $target_file)){
	echo "<h3> File Uploaded Successfully </h3>";
}
else{
	echo "<h3> Sorry, File not Uploaded </h3>";
}
?>