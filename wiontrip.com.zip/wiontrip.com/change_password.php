<?php 
	include("z_db.php");
	include("Auth.php");
	
	if(isset($_POST['sbm']))
	{
		$id=$_SESSION['MSRNO'];
		$sql= "SELECT * FROM tempusermaster WHERE Id='".$id."'";
		$query= mysqli_query($con, $sql);
		$data= mysqli_fetch_array($query);
		
			$db_pass=$data['password'];
			$old_pass=$_REQUEST['old_pass'];
			$new_pass=$_REQUEST['new_pass'];
			$confirm_pass=$_REQUEST['confirm_pass'];
			
			if($db_pass==$old_pass){
				 if($old_pass!=$new_pass){
					 if($new_pass==$confirm_pass){
						
						$update=mysqli_query($con,"UPDATE tempusermaster SET password='".$new_pass."'WHERE Id='".$id."'");
						if($update){
							// echo "Password Update Successfull";
							echo "<script>alert('Password has been changed');window.location='change_password.php';</script>";
						}
						else{
							//echo "Password not update";
							echo "<script>alert('Something is went wrong. Please try again later');window.location='change_password.php';</script>";
						}
					 }
					 else{
					 echo "<script>alert('New password and Confirm password does not match');window.location='change_password.php';</script>";
						  
					 }
				 }
				 else{
					   echo "<script>alert('Old password and New Password is matched ');window.location='change_password.php';</script>";
				 }
			}
			else{
				   echo "<script>alert('Database password and Old password does not match');window.location='change_password.php';</script>";
			}
	}
	
	
?>
<!DOCTYPE html>
<html lang="en">


<?php include("headercss.php");?>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<!--sidebar-wrapper-->
		<?php include("sidemenu.php");?>
		<!--end sidebar-wrapper-->
		<!--header-->
		<?php include("header.php");?>
		<!--end header-->
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					<div class="page-breadcrumb d-none d-md-flex align-items-center mb-3">
						<div class="breadcrumb-title pr-3">Contact us</div>
						
						<div class="ml-auto">
							<div class="btn-group">
								
								
								<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-left">	<a class="dropdown-item" href="javascript:;">Action</a>
									<a class="dropdown-item" href="javascript:;">Another action</a>
									<a class="dropdown-item" href="javascript:;">Something else here</a>
									<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
								</div>
							</div>
						</div>
					</div>
					<!--end breadcrumb-->
					<div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Change Password</h4>
							</div>
							<hr/>
							<div class="table-responsive">
                            <form action="change_password.php" method="post">
								<table class="table table-bordered table-striped mb-0">
									
									<tbody>
    <input type="password"  name="old_pass" class="form-control" placeholder="Old Password"><br><br>
    <input type="password"  name="new_pass" class="form-control" placeholder="New Password"><br><br>
    <input type="password"  name="confirm_pass" class="form-control" placeholder="Confirm Password"><br><br>
    
    <input type="submit" name="sbm" value="Submit" class="btn btn-success">
									</tbody>
								</table>
                                </form>
							</div>
						</div>
						<div class="card-body">
							<hr/>
							
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<!--footer -->
		<div class="footer">
			<p class="mb-0">WION TRIP @2021 | Developed By : <a href="http://happyweb.in/" target="_blank">Happy Web</a>
			</p>
		</div>
		<!-- end footer -->
	</div>
	<!-- end wrapper -->
	<!--start switcher-->
	<div class="switcher-wrapper">
		
		<div class="switcher-body">
			<h5 class="mb-0 text-uppercase">Theme Customizer</h5>
			<hr/>
			<h6 class="mb-0">Theme Styles</h6>
			<hr/>
			<div class="d-flex align-items-center justify-content-between">
				<div class="custom-control custom-radio">
					<input type="radio" id="darkmode" name="customRadio" class="custom-control-input">
					<label class="custom-control-label" for="darkmode">Dark Mode</label>
				</div>
				<div class="custom-control custom-radio">
					<input type="radio" id="lightmode" name="customRadio" checked class="custom-control-input">
					<label class="custom-control-label" for="lightmode">Light Mode</label>
				</div>
			</div>
			<hr/>
			<div class="custom-control custom-switch">
				<input type="checkbox" class="custom-control-input" id="DarkSidebar">
				<label class="custom-control-label" for="DarkSidebar">Dark Sidebar</label>
			</div>
			<hr/>
			<div class="custom-control custom-switch">
				<input type="checkbox" class="custom-control-input" id="ColorLessIcons">
				<label class="custom-control-label" for="ColorLessIcons">Color Less Icons</label>
			</div>
		</div>
	</div>
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<?php include("footerjs.php");?>
</body>


</html>