

<?php
$old = array(
       'a' => 'blah',
       'b' => 'key',
       'c' => 'amazing',
       'd' => array(
                0 => 'want to replace',
                1 => 'yes I want to'
              )
       );
$keyReplaceInfoz = array('a' => 'newA', 'b' => 'newB', 'c' => 'newC', 'd' => 'newD');

$new = array(); 

foreach ($old as $key => $value)
{
    $newvalue =  $keyReplaceInfoz[$key];
   $new[$key] = $newvalue;
}
print_r($new);

?>

