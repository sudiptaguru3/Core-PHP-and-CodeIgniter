<?php 
	if($_SESSION['TYPE']=="ADMIN")
	{
		include("admin_menu.php");
	}
	else if($_SESSION['TYPE']=="SUB")
	{
		include("sub_admin_menu.php");
	}
?>