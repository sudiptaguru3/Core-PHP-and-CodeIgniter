<?php
// if(isset($_REQUEST['reg']) && $_REQUEST['reg']==0){
//    echo "<font color='red'> Sorry, Registration not success </font>";
// }
// if(isset($_REQUEST['reg']) && $_REQUEST['reg']==2){
//    echo "<font color='red'> Sorry, Email Id is already Exist</font>";
// }

?>


<form action="registration_action.php" method="POST" enctype="multipart/form-data">

    Name:<input type="text" id="user" name='user'><br><br><br>

    Email:<input type="text" id="email" name='email'><br><br><br>

    Password:<input type="password" id="password" name='password'><br><br><br>

    Address:<textarea name='address' rows='5' cols='10'></textarea><br><br><br>

    Number:<input type="number" id="nmbr" name='phone'><br><br><br>

    Gender:<input type="radio" name='gen' value="male">Male
           <input type="radio" name='gen' value="female">Female <br><br><br>

    Skill:<input type="checkbox" name="skill[]" value="php">PHP
         <input type="checkbox" name="skill[]" value="android">ANDROID
         <input type="checkbox" name="skill[]" value="iphone">IPHONE 
         <input type="checkbox" name="skill[]" value="java">JAVA <br><br><br>

    City:<select name="city">
    <option value="">Select</option>
    <option value="kolkata">Kolkata</option>
    <option value="mumbai">Mumbai</option>
    <option value="delhi">Delhi</option>
    <option value="chennai">Chennai</option>
    </select><br><br><br>

    File:<input type="file" id="fle" name='file'><br><br><br>
    
    <input type="reset" value='Reset'>
    <input type="submit" value='Submit'>
</form>