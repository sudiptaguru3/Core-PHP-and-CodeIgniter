
<?php 
  
// Input string 
$subjectVal = "a/b-c/d-e/f"; 
  
// using str_replace() function 
$resStr = str_replace('/', '-', $subjectVal); 
$exploded= explode("-",$resStr);
echo "<pre>";
print_r($exploded); 

  
?> 
