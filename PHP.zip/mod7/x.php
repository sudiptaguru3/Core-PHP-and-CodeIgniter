
<?php 
$sentence = 'I am happy today.'; 
$string = 'very'; 
$position = '5'; 
  
// echo substr_replace( $sentence, $string, $position, 0 );
echo substr_replace('I am  happy today.','very',5, 0);

?> 
