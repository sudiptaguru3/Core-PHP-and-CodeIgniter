<?php
//$ar= array('10','deep','20','30');
$ar= ['10','20','30'];
echo "<pre>";
print_r($ar[2]);

?>