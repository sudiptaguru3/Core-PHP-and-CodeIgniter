<input type='submit'  value='click' onclick="test()">
<p id="p1"></p>
<script>
    function test(){
        var x= new XMLHttpRequest();
        x.onreadystatechange=function(){
            if(x.readyState==4 && x.status==200){
                document.getElementById('p1').innerHTML=x.responseText;
            }
        };
        x.open('GET','ajax_send.php',true);
        x.send();
    }
    
</script>
