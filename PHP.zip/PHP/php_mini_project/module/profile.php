<?php
session_start();
include "connect.php";

if(isset($_REQUEST['log']) && $_REQUEST['log']==1){
   echo "<font color='green'> Login Successfull </font>";
}

// if(isset($_REQUEST['update']) && $_REQUEST['update']==1){
//    echo "<font color='green'> Profile Update Successfull </font>";
// }

// if(isset($_REQUEST['change']) && $_REQUEST['change']==1){
//    echo "<font color='green'> Password Update Successfull </font>";
// }

$id= $_SESSION['id'];

$sql="SELECT * FROM user WHERE id=".$id;
$query= mysqli_query($conn, $sql);

$data= mysqli_fetch_array($query);
?>

<h2> User Profile </h2> <br> <br>
<p> Name: <?php echo $data['name'];?> </p> <br> <br>
<p> Email: <?php echo $data['email'];?> </p> <br> 
<br>
<p> Address: <?php echo $data['address'];?> </p> <br> <br>
<p> Contact No: <?php echo $data['contact'];?> </p> <br> <br>
<p> Gender: <?php echo $data['gender'];?> </p> <br> <br>
<p> Skills: <?php echo $data['skill'];?> </p> <br> <br>
<p> City: <?php echo $data['city'];?> </p> <br> <br>
<p> File: <img src="<?php echo $data['file'];?>" 
	        height="300px" width="400px"> </p> <br> <br>

<a href="editprofile.php"> Edit Profile </a> &nbsp; &nbsp; &nbsp;
<a href="change_password.php"> Change Your Password </a> &nbsp; &nbsp; &nbsp;
<a href="logout.php"> Logout </a> 