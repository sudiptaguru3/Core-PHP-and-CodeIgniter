-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 198.23.52.177:3306
-- Generation Time: Feb 17, 2021 at 11:24 AM
-- Server version: 5.6.26
-- PHP Version: 7.0.33-0+deb9u10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vktalwar55_wion`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment_request`
--

CREATE TABLE `payment_request` (
  `id` int(11) NOT NULL,
  `Msrno` int(11) NOT NULL,
  `amount` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ref` int(11) NOT NULL,
  `branch_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `payment_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `payment_date` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `attachment` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `isactive` enum('0','1') COLLATE utf8_unicode_ci NOT NULL,
  `isaprove` enum('0','1') COLLATE utf8_unicode_ci NOT NULL,
  `ondate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payment_request`
--

INSERT INTO `payment_request` (`id`, `Msrno`, `amount`, `ref`, `branch_name`, `payment_type`, `payment_date`, `message`, `attachment`, `isactive`, `isaprove`, `ondate`) VALUES
(1, 0, '111', 11, '11', 'NEFT', '2021-02-15', 'dcsdsd', 'package.jpg', '0', '0', '0000-00-00 00:00:00'),
(2, 1, '100', 0, 'Bam', 'NEFT', '2021-02-16', 'Hello', 'package.jpg', '1', '0', '2021-02-15 17:06:00'),
(3, 1, '100', 100, 'All', 'NEFT', '2021-02-03', 'Hello', 'package.jpg', '1', '0', '2021-02-15 17:09:00'),
(4, 1, '', 0, '', 'NEFT', '', '', 'package.jpg', '1', '0', '2021-02-15 17:45:00'),
(5, 1, '', 0, '', 'NEFT', '', '', 'uploads802288624package.jpg', '1', '0', '2021-02-15 17:47:00'),
(6, 2, '100', 22, 'ASA', 'NEFT', '2021-02-12', 'SA', 'uploads214391066', '1', '0', '2021-02-15 22:54:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment_request`
--
ALTER TABLE `payment_request`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payment_request`
--
ALTER TABLE `payment_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
