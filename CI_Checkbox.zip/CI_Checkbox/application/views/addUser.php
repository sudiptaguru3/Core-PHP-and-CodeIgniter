<!DOCTYPE html>
<head>
    <title>Add User</title>
</head>
<body>
    <a href="<?php echo base_url(); ?>">Add User </a> 
    &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="<?php echo base_url('HomeController/viewUser'); ?>">View User</a>
    <hr>
    <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>
    <form action="<?php echo base_url('registration'); ?>" method="POST">
    <td>Name :</td> 
        <td><input type="text" name="user" required=""></td>
        <br><br>
    <td>Email-ID :</td> 
        <td><input type="text" name="email" required=""></td>
        <br><br>
    <td>Password :</td> 
        <td><input type="password" name="password" required="" ></td>
        <br><br>
    <td>Address :</td> 
        <td><input type="text" name="address" required="" ></td>
        <br><br>
    <td>Phone :</td> 
        <td><input type="number" name="phone" required="" ></td>
        <br><br>
        Skill:<input type="checkbox" name="skill[]" value="php">PHP
         <input type="checkbox" name="skill[]" value="android">ANDROID
         <input type="checkbox" name="skill[]" value="iphone">IPHONE 
         <input type="checkbox" name="skill[]" value="java">JAVA <br><br>
    <!-- City:<select name="city">
    <option value="">Select</option>
    <option value="kolkata">Kolkata</option>
    <option value="mumbai">Mumbai</option>
    <option value="delhi">Delhi</option>
    <option value="chennai">Chennai</option>
    </select><br><br>
    File:<input type="file" id="fle" name='file'><br><br> -->
        <input type="submit" name="submitbtn" value="INSERT">
        <input type="reset" name="resetbtn" value="REFRESH">
        <br>
    </form>
    
</body>
</html>