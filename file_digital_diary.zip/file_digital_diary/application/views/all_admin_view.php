
<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html; charset=utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
  <title>DataTables example - Alternative pagination</title>
  <link rel="shortcut icon" type="image/png" href="/media/images/favicon.png">
  <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
  <link rel="stylesheet" type="text/css" href="/media/css/site-examples.css?_=9464ca0bf85c68c4b59f9bb203742676">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">
  <style type="text/css" class="init">
  
  </style>
  <script type="text/javascript" src="/media/js/site.js?_=f8b58e9283bed2c11047af0c304e0c6b"></script>
  <script type="text/javascript" src="/media/js/dynamic.php?comments-page=examples%2Fbasic_init%2Falt_pagination.html" async></script>
  <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" language="javascript" src="../resources/demo.js"></script>
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
  <script type="text/javascript" class="init">
  
$(document).ready(function() {
  $('#example').DataTable( {
    "pagingType": "full_numbers"
  } );
} );

  </script>
<script type="text/javascript">
function ChangeStatus(id,val)
   {
   var re_confirm = confirm("Are you sure ?");
   if(re_confirm){
       $("#cstm-opcty").css('opacity','0.5');
   $.ajax({
   url: "<?php echo base_url('View_all_admin_user/edit_status');?>",
   method:'POST',
   data:{id:id,status:val},
   success: function(data)
   {
    // alert(data);
       $("#cstm-opcty").css('opacity','1');
      if(data==1)
      {
       location.reload();
      }

   }
   });
   }
   }



 </script>
</head>
<body class="wide comments example">
  <a href="<?php echo base_url('admin_user'); ?>">
                  <p>Add New</p>
                </a>
    <div class="fw-body">
      <div class="content">
        <h1 class="page_title">Alternative pagination</h1>
        <div class="demo-html">
            <table id="example" class="display" border="1">
                  <thead>
                  <tr>
                    <th>SL No.</th>
                    <th>Profile Pic</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php

                    $i=1;
                    foreach ($test as $row)
                     {
                      $id=$row->id;

                  ?>
                  
                  <tr>
                    <td><?php echo $i;?></td>
                     <td>
                      <img style="width: 70px;height: 70px; border-radius: 50%;" src="<?php echo base_url('uploads/'.$row->profile_pic); ?>" id="image_disp" class="img-thumbnail">
                    </td>
                   
                    <td><a href="<?php echo base_url('View_all_admin_user/edit/'.$id);?>" ><i class="fas fa-edit"></i></a> &nbsp; <a  href="<?php echo base_url('View_all_admin_user/delete_row/'.$id);?>" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="fas fa-trash-alt" style="color: red;"></i></a></td>
                  </tr>
                  <?php 
                    $i++;
                    }
                  ?>
                <!-- <p><?php echo $links; ?></p> -->
                  </tbody>
                 
                </table>
        </div>
        <div class="tabs">
          <div class="js">
         <!--  <code class="multiline language-js">$(document).ready(function() {
  $('#example').DataTable( {
    &quot;pagingType&quot;: &quot;full_numbers&quot;
  } );
} );</code> -->
          </div>
          <div class="comments">
            <div class="comments-insert"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript">
          var _gaq = _gaq || [];
          _gaq.push(['_setAccount', 'UA-365466-5']);
          _gaq.push(['_trackPageview']);

          (function() {
          var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
          ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
          var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
          })();
  </script>
</body>
</html>
 