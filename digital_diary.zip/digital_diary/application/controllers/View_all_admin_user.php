<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   
   class View_all_admin_user extends CI_Controller 
   {
   	function __construct()
   	{
   		parent::__construct();
   		// $this->load->database();
   		$this->load->model('Category_model');
   	}
   
   	public function index()
   	{	
   		$this->load->model('Admin_user_model');
   		$data['test']=$this->Admin_user_model->get_data();
   
   		$this->load->view('include/header');
   		$this->load->view('include/sidebar');
   		$this->load->view('all_admin_view', $data);
   		// $this->load->view('include/footer');
   		
   	}
   
   	public function edit()
   	{
   		 $id=$this->uri->segment(3); 
   		 $this->load->model('Admin_user_model');
   		 $data['user']= $this->Admin_user_model->get_data($id);
   		 
   		 // echo "<pre>";
   		 // print_r($data);die();

//---------------------- adding update form to fetch data in form------------------------
   

   		$this->load->view('include/header');
   		$this->load->view('include/sidebar');
   		$this->load->view('update_admin_view',$data);
   		// $this->load->view('admin_user_add', $data);
   		$this->load->view('include/footer');
   
   	}
   
   	public function update_user() 
   	{   
   
   	 $id=$this->input->post('id');
   
   
   //----------------------file upload code------------------
   
   
   	   if(!empty($_FILES['profile_pic']['name']))
   	   {
              $config['upload_path'] = 'uploads/';
              $config['allowed_types'] = 'jpg|jpeg|png|gif';
              $config['file_name'] = $_FILES['profile_pic']['name'];
                   
                   //Load upload library and initialize configuration
              $this->load->library('upload',$config);
              $this->upload->initialize($config);
                   
              if($this->upload->do_upload('profile_pic'))
              	{
	   	           $uploadData = $this->upload->data();
	   	           $picture = $uploadData['file_name'];
                }
              else
               {
                  $picture = '';
               }
        }
        // else
        // {
        //     $picture = '';
        // }
   
   //-------------------file upload code end here----------------------------------------
   
   
   	 if($_FILES['profile_pic']['name']!='')
   	 {
   	 	$data = array(
           // 'table_name' => 'admin_user', // pass the real table name
           'full_name' => $this->input->post('full_name'),
           'mobile' => $this->input->post('mobile'),
           'email' => $this->input->post('email'),
           'status' => $this->input->post('status'),
           'user_role' => $this->input->post('user_role'),
           'profile_pic'=>$_FILES['profile_pic']['name']
      		 );
   	 }
   	 else
   	 {
   	 	$data = array(
           // 'table_name' => 'admin_user', // pass the real table name
           'full_name' => $this->input->post('full_name'),
           'mobile' => $this->input->post('mobile'),
           'email' => $this->input->post('email'),
           'status' => $this->input->post('status'),
           'user_role' => $this->input->post('user_role')
       );
   	 }
   
       
   
       // echo "<pre>";
       // print_r($data);die();
   
       $this->load->model('Admin_user_model');
   
       if($this->Admin_user_model->upddata($data,$id)) 
       {	
           // echo("update successful");
           redirect('View_all_admin_user');
   
       }
       else
       {
           echo("update not successful");
       }
   
   }
   
   	public function delete_row($id='')
   	{  
   		$this->load->model('Admin_user_model');
   		$id=$this->uri->segment(3);
   	    $this->Admin_user_model->delete_data($id);
   	    redirect('View_all_admin_user');
   	}


  public function edit_status()
  {
    // print_r($_POST);die();

    $id= $this->input->post('id'); 
    $status = $this->input->post('status');
    
     $this->load->model('Admin_user_model');
   
       if($this->Admin_user_model->update_status($status,$id)) 
       {  
           echo '1';
       }
       else
       {
           echo '0';
       }
    
  }

   
   }
   
   ?>