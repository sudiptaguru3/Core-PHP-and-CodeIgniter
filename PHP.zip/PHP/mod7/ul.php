

<?php

echo "<ul>";

foreach(array("test", "test2", "test3") as $string)) {
    echo "<li>".$string."</li>"
}

echo "</ul>";

?>

