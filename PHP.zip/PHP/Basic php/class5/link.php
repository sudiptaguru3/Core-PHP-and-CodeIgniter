<?php
$first= $_REQUEST['num1'];
$second= $_REQUEST['num2'];
$result= $first + $second;
echo $result;
?>