<?php 
	include("z_db.php");
	
	if(isset($_POST['sbt']))
	{
		$company_name=mysqli_real_escape_string($con,trim($_POST['company_name'])); //fetching details through post method
		$contact_name = mysqli_real_escape_string($con,trim($_POST['contact_name']));
		$contact_no = mysqli_real_escape_string($con,trim($_POST['contact_no']));
		$email = mysqli_real_escape_string($con,trim($_POST['email']));
		$address = mysqli_real_escape_string($con,trim($_POST['address']));
		$city = mysqli_real_escape_string($con,trim($_POST['city']));
		$state = mysqli_real_escape_string($con,trim($_POST['state']));
		$country = mysqli_real_escape_string($con,trim($_POST['country']));
		$contact_no_alt = mysqli_real_escape_string($con,trim($_POST['contact_no_alt']));
		$company_gst = mysqli_real_escape_string($con,trim($_POST['company_gst']));
		$company_pan = mysqli_real_escape_string($con,trim($_POST['company_pan']));
		$password = mysqli_real_escape_string($con,trim($_POST['password']));
		$status = "OK";
		$msg = "";
		if($company_name=="")
		{
			$status = "NOTOK";
			$msg = "Enter Company Name";
		}
		if($contact_name=="")
		{
			$status = "NOTOK";
			$msg = "Enter Contact Person Name";
		}
		if($contact_no=="")
		{
			$status = "NOTOK";
			$msg = "Enter Contact No.";
		}
		if($email=="")
		{
			$status = "NOTOK";
			$msg = "Enter Email-Id";
		}
		if($address=="")
		{
			$status = "NOTOK";
			$msg = "Enter Address";
		}
		if($city=="")
		{
			$status = "NOTOK";
			$msg = "Enter City";
		}
		if($state=="")
		{
			$status = "NOTOK";
			$msg = "Enter State";
		}
		if($country=="")
		{
			$status = "NOTOK";
			$msg = "Enter Country";
		}
		if($company_pan=="")
		{
			$status = "NOTOK";
			$msg = "Enter Company Pancard";
		}
		else
		{
			$qre = mysqli_query($con,"select * from tempusermaster where company_pan='$company_pan'");
			if(mysqli_num_rows($qre)>0)
			{
				$status = "NOTOK";
				$msg = "This Pancard is already exist.";
			}
		}
		if($password=="")
		{
			$status = "NOTOK";
			$msg = "Enter Password";
		}
		if($status == "NOTOK")
		{
			echo "<script>alert('$msg');window.location='register.php';</script>";
		}
		else if($status == "OK")
		{
			mysqli_query($con,"insert into tempusermaster (company_name,contact_name,password,contact_no,contact_no_alt,email,address,city,state,country,pincode,company_gst,company_pan,isactive,ondate) VALUES('$company_name','$contact_name','$password','$contact_no','$contact_no_alt','$email','$address','$city','$state','$country','$pincode','$company_gst','$company_pan','1','$datedata')");
			$last_id = mysqli_insert_id($con);
			$username = 'WIONTAGNT'.$last_id;
			mysqli_query($con,"update tempusermaster set username='$username' where id='$last_id'");
			
			mysqli_query($con,"insert into uwalletstatus (Msrno,isactive,ondate) VALUES('$last_id','1','$datedata')");
			echo "<script>alert('Registration has been done');window.location='register.php';</script>";
		}
	}
?>
<!DOCTYPE html>
<html lang="en">


<head>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<title>Welcome To WION TRIP</title>
	<!--favicon-->
	<link rel="icon" href="favicon-32x32.png" type="image/png" />
	<!-- loader-->
	<link href="assets/css/pace.min.css" rel="stylesheet" />
	<script src="assets/js/pace.min.js"></script>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
	<!-- Icons CSS -->
	<link rel="stylesheet" href="assets/css/icons.css" />
	<!-- App CSS -->
	<link rel="stylesheet" href="assets/css/app.css" />
</head>

<body class="bg-register">
	<!-- wrapper -->
    <form action="register.php" method="post">
	<div class="wrapper">
		<div class="section-authentication-register d-flex align-items-center justify-content-center">
			<div class="row">
				<div class="col-12 col-lg-10 mx-auto">
					<div class="card radius-15">
						<div class="row no-gutters">
							<div class="col-lg-6">
								<div class="card-body p-md-5">
									<div class="text-center">
										<img src="logo_login.png" width="120" alt="">
										<h5 class="mt-4 font-weight-bold">Please enter your Company information.</h5>
									</div>
									<!--<div class="input-group shadow-sm rounded mt-5">
										<div class="input-group-prepend">	<span class="input-group-text bg-transparent border-0 cursor-pointer"><img src="assets/images/icons/search.svg" alt="" width="16"></span>
										</div>
										<input type="button" class="form-control border-0" value="Register with google">
									</div>
									<div class="input-group shadow-sm rounded mt-3">
										<div class="input-group-prepend">	<span class="input-group-text bg-transparent border-0 cursor-pointer"><img src="assets/images/icons/facebook.svg" alt="" width="16"></span>
										</div>
										<input type="button" class="form-control border-0 text-facebook" value="Register with Facebook">
									</div>
									<div class="login-separater text-center"> <span>OR REGISTER WITH EMAIL</span>
										<hr/>
									</div>-->
									
									<div class="form-row">
										<div class="form-group col-md-6">
											<label>Company Name<span style="color:#FF0000;">*</span> : </label>
											<input type="text" class="form-control" required placeholder="Company Name" name="company_name" />
										</div>
										<div class="form-group col-md-6">
											<label>Contact Name<span style="color:#FF0000;">*</span> :</label>
											<input type="text" class="form-control" required placeholder="Contact Name" name="contact_name" />
										</div>
									</div>
                                    <div class="form-row">
										<div class="form-group col-md-6">
											<label>Contact No.<span style="color:#FF0000;">*</span> : </label>
											<input type="text" class="form-control" required placeholder="Contact No." name="contact_no" />
										</div>
										<div class="form-group col-md-6">
											<label>Email Id<span style="color:#FF0000;">*</span> :</label>
											<input type="email" class="form-control" required placeholder="Email Id" name="email" />
										</div>
									</div>
                                    <div class="form-row">
										<div class="form-group col-md-6">
											<label>Address<span style="color:#FF0000;">*</span> : </label>
											<input type="text" class="form-control" required placeholder="Address" name="address" />
										</div>
										<div class="form-group col-md-6">
											<label>City<span style="color:#FF0000;">*</span> :</label>
											<input type="text" class="form-control" required placeholder="City" name="city" />
										</div>
									</div>
                                     <div class="form-row">
										<div class="form-group col-md-6">
											<label>State<span style="color:#FF0000;">*</span> : </label>
											<select name="state" class="form-control" required>
                                            	<option value="">--Select State--</option>
                                                <option  value="ANDAMAN & NICOBAR" class="ng-star-inserted">ANDAMAN &amp; NICOBAR</option>
                                                <option  value="ANDHRA PRADESH" class="ng-star-inserted">ANDHRA PRADESH</option>
                                                <option  value="ARUNACHAL PRADESH" class="ng-star-inserted">ARUNACHAL PRADESH</option>
                                                <option  value="ASSAM" class="ng-star-inserted">ASSAM</option>
                                                <option  value="BIHAR" class="ng-star-inserted">BIHAR</option>
                                                <option  value="CHANDIGARH" class="ng-star-inserted">CHANDIGARH</option>
                                                <option  value="CHATTISGARH" class="ng-star-inserted">CHATTISGARH</option>
                                                <option  value="DADRA & NAGAR" class="ng-star-inserted">DADRA &amp; NAGAR</option>
                                                <option  value="DAMAN & DIU" class="ng-star-inserted">DAMAN &amp; DIU</option>
                                                <option  value="DELHI" class="ng-star-inserted">DELHI</option>
                                                <option  value="GOA" class="ng-star-inserted">GOA</option>
                                                <option  value="GUJRAT" class="ng-star-inserted">GUJRAT</option>
                                                <option  value="HARYANA" class="ng-star-inserted">HARYANA</option>
                                                <option  value="HIMACHAL PRADESH" class="ng-star-inserted">HIMACHAL PRADESH</option>
                                                <option  value="JAMMU &amp; KASHMIR" class="ng-star-inserted">JAMMU &amp; KASHMIR</option>
                                                <option  value="JHARKHAND" class="ng-star-inserted">JHARKHAND</option>
                                                <option  value="KARNATAKA" class="ng-star-inserted">KARNATAKA</option>
                                                <option  value="KERALA" class="ng-star-inserted">KERALA</option>
                                                <option  value="LAKSHDWEEP" class="ng-star-inserted">LAKSHDWEEP</option>
                                                <option  value="MADHYA PRADESH" class="ng-star-inserted">MADHYA PRADESH</option>
                                                <option  value="MAHARASHTRA" class="ng-star-inserted">MAHARASHTRA</option>
                                                <option  value="MANIPUR" class="ng-star-inserted">MANIPUR</option>
                                                <option  value="MEGHALAYA" class="ng-star-inserted">MEGHALAYA</option>
                                                <option  value="MIZORAM" class="ng-star-inserted">MIZORAM</option>
                                                <option  value="NAGALAND" class="ng-star-inserted">NAGALAND</option>
                                                <option  value="ORISSA" class="ng-star-inserted">ORISSA</option>
                                                <option  value="PONDICHERY" class="ng-star-inserted">PONDICHERY</option>
                                                <option  value="PUNJAB" class="ng-star-inserted">PUNJAB</option>
                                                <option  value="RAJASTHAN" class="ng-star-inserted">RAJASTHAN</option>
                                                <option  value="SIKKIM" class="ng-star-inserted">SIKKIM</option>
                                                <option  value="TAMIL NADU" class="ng-star-inserted">TAMIL NADU</option>
                                                <option  value="TELANGANA" class="ng-star-inserted">TELANGANA</option>
                                                <option  value="TRIPURA" class="ng-star-inserted">TRIPURA</option>
                                                <option  value="UTTAR PRADESH" class="ng-star-inserted">UTTAR PRADESH</option>
                                                <option  value="UTTARANCHAL" class="ng-star-inserted">UTTARANCHAL</option>
                                                <option  value="WEST BENGAL" class="ng-star-inserted">WEST BENGAL</option>
                                            </select>
										</div>
										<div class="form-group col-md-6">
											<label>Country<span style="color:#FF0000;">*</span> :</label>
											<input type="text" class="form-control" required placeholder="Country" name="country" />
										</div>
									</div>
                                    <div class="form-row">
										<div class="form-group col-md-6">
											<label>Alternative Mobile No. :  </label>
											<input type="text" class="form-control" placeholder="Alternative Mobile No." name="contact_no_alt" />
										</div>
										<div class="form-group col-md-6">
											<label>Company GST No. :</label>
											<input type="text" class="form-control" placeholder="Company GST No." name="company_gst" />
										</div>
									</div>
                                    <div class="form-row">
										<div class="form-group col-md-6">
											<label>Company Pan No. <span style="color:#FF0000;">*</span>:</label>
											<input type="text" class="form-control" required placeholder="Company Pan No." name="company_pan" />
										</div>
										<div class="form-group col-md-6">
											<label>Password<span style="color:#FF0000;">*</span>:</label>
                                            <div class="input-group" id="show_hide_password">
											<input class="form-control border-right-0" type="password" required placeholder="Password" name="password" />
											<div class="input-group-append"><a href="javascript:;" class="input-group-text bg-transparent border-left-0"><i class='bx bx-hide'></i></a>
											</div>
										</div>
										</div>
									</div>
									<div class="form-group">
										<div class="custom-control custom-checkbox">
											<input type="checkbox" class="custom-control-input" required id="customCheck1">
											<label class="custom-control-label" for="customCheck1">I read and agree to Terms & Conditions</label>
										</div>
									</div>
									<div class="btn-group mt-3 w-100">
                                    	<input type="submit" name="sbt" class="btn btn-primary btn-block" value="Register" />
										<button type="button" class="btn btn-primary"><i class="lni lni-arrow-right"></i>
										</button>
									</div>
									<hr/>
									<div class="text-center mt-4">
										<p class="mb-0">Already have an account? <a href="login.php">Login</a>
										</p>
									</div>
								</div>
							</div>
							<div class="col-lg-6">
								<img src="assets/images/login-images/register-frent-img.jpg" class="card-img login-img h-100" alt="...">
							</div>
						</div>
						<!--end row-->
					</div>
				</div>
			</div>
		</div>
	</div>
    </form>
	<!-- end wrapper -->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/js/jquery.min.js"></script>
	<!--Password show & hide js -->
	<script>
		$(document).ready(function () {
			$("#show_hide_password a").on('click', function (event) {
				event.preventDefault();
				if ($('#show_hide_password input').attr("type") == "text") {
					$('#show_hide_password input').attr('type', 'password');
					$('#show_hide_password i').addClass("bx-hide");
					$('#show_hide_password i').removeClass("bx-show");
				} else if ($('#show_hide_password input').attr("type") == "password") {
					$('#show_hide_password input').attr('type', 'text');
					$('#show_hide_password i').removeClass("bx-hide");
					$('#show_hide_password i').addClass("bx-show");
				}
			});
		});
	</script>
</body>


<!-- Mirrored from codervent.com/syndash/demo/vertical/authentication-register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 26 Jan 2021 08:16:55 GMT -->
</html>