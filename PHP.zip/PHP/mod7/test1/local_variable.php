<?php

function test(){
	$a=10;
	echo "The inside value is: ".$a;
}
test();
echo "The outside value is: ".$a;
?>