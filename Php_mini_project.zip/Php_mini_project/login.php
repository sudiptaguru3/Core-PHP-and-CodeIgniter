<?php
if(isset($_REQUEST['reg']) && $_REQUEST['reg'] == 1){
    echo "<font color='green'>Registration Successful</font>";
}
if(isset($_REQUEST['login']) && $_REQUEST['login'] == 0){
    echo "<font color='red'>Login unsuccessfull</font>";
}
if(isset($_REQUEST['login']) && $_REQUEST['login'] == 2){
    echo "<font color='red'>Admin has blocked you.</font>";
}
?>
<form action="login_action.php" method="POST">
<h1> User Login</h1>
Username:<input type="email" name="email"><br><br><br>
Password:<input type="password" name="password"><br><br><br>
<input type="submit" name="submit" value="Login">
</form>
