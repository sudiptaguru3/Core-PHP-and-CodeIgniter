<?php 
	include("z_db.php");
	include("Auth.php");
?>
<!DOCTYPE html>
<html lang="en">

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    .custom-file-input.selected:lang(en)::after {
      content: "" !important;
    }

    .custom-file {
      overflow: hidden;
    }

    .custom-file-input {
      white-space: nowrap;
    }
  </style>
<?php include("headercss.php");?>

<body>
	<!-- wrapper -->
	<div class="wrapper">
		<!--sidebar-wrapper-->
		<?php include("sidemenu.php");?>
		<!--end sidebar-wrapper-->
		<!--header-->
		<?php include("header.php");?>
		<!--end header-->
		<!--page-wrapper-->
		<div class="page-wrapper">
			<!--page-content-wrapper-->
			<div class="page-content-wrapper">
				<div class="page-content">
					<!--breadcrumb-->
					<div class="page-breadcrumb d-none d-md-flex align-items-center mb-3">
						
						<div class="ml-auto">
							<div class="btn-group">
								
								
								<div class="dropdown-menu dropdown-menu-right dropdown-menu-lg-left">	<a class="dropdown-item" href="javascript:;">Action</a>
									<a class="dropdown-item" href="javascript:;">Another action</a>
									<a class="dropdown-item" href="javascript:;">Something else here</a>
									<div class="dropdown-divider"></div>	<a class="dropdown-item" href="javascript:;">Separated link</a>
								</div>
							</div>
						</div>
					</div>
					<!--end breadcrumb-->
					<div class="card radius-15">
						<div class="card-body">
							<div class="card-title">
								<h4 class="mb-0">Payment Requests</h4>
							</div>
							<hr/>
							<div class="table-responsive">
                            <form action="payment_requests_action.php" method="POST" enctype="multipart/form-data">
    <label>Amount* :</label>
    <input type="text" id="" placeholder="Amount" class="form-control" name="amount"><br>

    <label>Ref No* :</label>
    <input type="text" id="" placeholder="Ref No" class="form-control" name="ref"><br>

    <label>Branch Name* :</label>
    <input type="text" id="" placeholder="Branch Name" class="form-control" name="branch"><br>

    <label>Payment Type :</label>
    <select class="form-control" name="payment_type">
    	<option value="NEFT">NEFT</option>
    	<option value="RTGS">RTGS</option>
    	<option value="IMPS">IMPS</option>
    	<option value="CASH_DEPOSIT">CASH DEPOSIT</option>
    	<option value="BANK_TRANSFER">BANK TRANSFER</option>
    	<option value="CHEQUE">CHEQUE</option>
    	<option value="UPI">UPI</option>
    	<option value="OTHER">OTHER</option>
    	<option value="CREDIT_REQUEST">CREDIT REQUEST</option>
    </select><br>
   
    <label>Payment Date* :</label>
    <input type="date" id="" placeholder="Date of transaction" class="form-control" name="payment_date"><br>

    <label>Message :</label>
    <textarea class="form-control" placeholder="Message" name="message"></textarea><br>
    
    <label>Attachment:</label>
    <div class="input-group">
      <div class="custom-file">
        <input type="file" class="custom-file-input" id="customFileInput" aria-describedby="customFileInput" name="file">
        <label class="custom-file-label" for="customFileInput">Select file</label>
      </div>
    </div>
    <br>
    <input type="submit" class="btn btn-primary" value="Submit" style="float: right;" name="submit">
  </form>

							</div>
						</div>
						<div class="card-body">
							<hr/>
							
						</div>
					</div>
				</div>
			</div>
			<!--end page-content-wrapper-->
		</div>
		<!--end page-wrapper-->
		<!--start overlay-->
		<div class="overlay toggle-btn-mobile"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<!--footer -->
		<div class="footer">
			<?php
			$sql=mysqli_query($con,"SELECT * FROM payment_request");
			?>
			<table border="1">
<tr>
	<th>Amount</th>
	<th>Ref No</th>
	<th>Branch Name</th>
	<th>Payment Type</th>
	<th>Payment Date</th>
	<th>Message</th>
	<!-- <th>Attachment</th> -->
</tr>

	<?php
	while($data=mysqli_fetch_array($sql))
	{
		?>
		<tr>
		<td><?php echo $data['amount'];?></td>
		<td><?php echo $data['ref'];?></td>
		<td><?php echo $data['branch_name'];?></td>
		<td><?php echo $data['payment_type'];?></td>
		<td><?php echo $data['payment_date'];?></td>
		<td><?php echo $data['message'];?></td>
		<!-- <td><a href="active_deactive.php?id=<?php echo $data['id'];?>">
		<?php
			if($data['']==1)
			{
				echo "Block";
			}
			else
			{
				echo "Unblock";
			}
			?>
				
			</a>
		</td> -->
	</tr>
	<?php	
	}
	?>


</table>
			<p class="mb-0">WION TRIP @2021 | Developed By : <a href="http://happyweb.in/" target="_blank">Happy Web</a>
			</p>
		</div>
		<!-- end footer -->
	</div>
	<!-- end wrapper -->
	<!--start switcher-->
	<div class="switcher-wrapper">
		
		<div class="switcher-body">
			<h5 class="mb-0 text-uppercase">Theme Customizer</h5>
			<hr/>
			<h6 class="mb-0">Theme Styles</h6>
			<hr/>
			<div class="d-flex align-items-center justify-content-between">
				<div class="custom-control custom-radio">
					<input type="radio" id="darkmode" name="customRadio" class="custom-control-input">
					<label class="custom-control-label" for="darkmode">Dark Mode</label>
				</div>
				<div class="custom-control custom-radio">
					<input type="radio" id="lightmode" name="customRadio" checked class="custom-control-input">
					<label class="custom-control-label" for="lightmode">Light Mode</label>
				</div>
			</div>
			<hr/>
			<div class="custom-control custom-switch">
				<input type="checkbox" class="custom-control-input" id="DarkSidebar">
				<label class="custom-control-label" for="DarkSidebar">Dark Sidebar</label>
			</div>
			<hr/>
			<div class="custom-control custom-switch">
				<input type="checkbox" class="custom-control-input" id="ColorLessIcons">
				<label class="custom-control-label" for="ColorLessIcons">Color Less Icons</label>
			</div>
		</div>
	</div>

	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<?php include("footerjs.php");?>

</body>


</html>
<script>
    document.querySelector('.custom-file-input').addEventListener('change', function (e) {
      var name = document.getElementById("customFileInput").files[0].name;
      var nextSibling = e.target.nextElementSibling
      nextSibling.innerText = name
    })
  </script>