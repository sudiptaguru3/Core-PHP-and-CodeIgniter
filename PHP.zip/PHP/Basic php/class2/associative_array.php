<?php
$ar= array('1'=>'Blue','2'=>'Yellow','3'=>'Black');
$ar1= ['name'=>'raj','address'=>'kol','state'=>'wb'];
echo "<pre>";
print_r($ar);
echo "<br>";
print_r($ar1);

?>