<?php
$str= '082307';
echo rtrim(chunk_split($str,2,':'),':');
echo "\n";
?>