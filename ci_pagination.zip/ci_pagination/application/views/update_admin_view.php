
 <!DOCTYPE html>
<html lang="en">
    <head>
        <style type="text/css">
       .green1
    {
        color: #4CAF50;
        
    }
    .red1
    {
         color: red; 
    }
    </style>
        <meta charset="utf-8">
        <title>CRUD Operation</title>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/css/material-fullpalette.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.css">


    </head>
    <body>
        <div class="container">
            <div class="row jumbotron">
               <a href="<?php echo base_url('admin_user'); ?>">Add User </a> 
    &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="<?php echo base_url(); ?>">View User</a>
                </div>
            
           
            <div class="row jumbotron">
          <form action="<?php echo base_url('Student/update_user'); ?>" method="post"  enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $this->uri->segment(3); ?>">
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" value="<?php echo $user[0]->name; ?>">
                  </div>
              </div>

              <div class="col-md-6">
                 <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" value="<?php echo $user[0]->email; ?>">
                  </div>
                </div>
              </div>
                  <div class="row">
              <div class="col-md-6">
                 <div class="form-group">
                    <label for="course">Course</label>
                    <input type="checkbox" name="course[]" value="php">PHP
                    <input type="checkbox" name="course[]" value="android">ANDROID
                    <input type="checkbox" name="course[]" value="iphone">IPHONE 
                    <input type="checkbox" name="course[]" value="java">JAVA
                </div>
              </div>
            </div>                                                               

            <div class="card-footer">
             <button type="submit" class="btn btn-primary">Submit</button>
           </div>
          </div>
          </form>       
        </div>
            
            <div class="row">
                <div class="alert alert-dismissable alert-success" style="display: none">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong>Data inserted successfully</strong>.
                </div>
                
                <div class="alert alert-dismissable alert-danger"  style="display: none">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>Sorry something went wrong</strong>
                </div>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/0.3.0/js/material.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
    </body>
</html>
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">

