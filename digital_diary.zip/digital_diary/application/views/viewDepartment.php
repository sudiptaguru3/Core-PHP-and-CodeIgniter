
<style type="text/css">
       .green1
    {
        color: #4CAF50;
        
    }
    .red1
    {
         color: red; 
    }
    </style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Department</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('welcome/admin'); ?>">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


 <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
             
    <div class="card">
              <div class="card-header">
                <h3 class="card-title"></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <!-- <table id="myTable" class="display table" width="100%" > -->
                <table id="myTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>SL No.</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php

                    $i=1;
                    foreach ($test as $row)
                     {
                       $id=$row->id;

                       if($row->status==1)
                           {
                             $status_color='green1';
                             // $status='green1';
                           }
                           else
                           {
                            $status_color='red1'; 
                           }
                  ?>
                  
                  <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $row->department;?> </td>
                    <td>

                      <?php 
                        echo ($row->status==1)?'Active':'Inactive';
                      ?>
                      
               <a href="javascript:void(0)" onclick="ChangeStatus(<?php echo $id; ?>,<?php if($row->status==1){ echo "0"; }else{ echo "1"; } ?>);" style="font-size: 40px;line-height: 0; background-color: "><br><i class="fa fa-toggle-on <?php echo $status_color; ?>" aria-hidden="true"></i> 
                </a> 
              </td>
                    <td><a href="<?php echo base_url('departmentView/edit/'.$id);?>" ><i class="fas fa-edit"></i></a> &nbsp; <a  href="<?php echo base_url('departmentView/delete_row/'.$id);?>" onclick="return confirm('Are you sure you want to delete this item ?');"><i class="fas fa-trash-alt" style="color: red;"></i></a></td>
                  </tr>
                  <?php 
                    $i++;
                    }
                  ?>
                
                  </tbody>
                 
                </table>
              </div>
              <!-- /.card-body -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
 </div>
<?php $this->load->view('include/footer'); ?>
 <link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css">
  <script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">
function ChangeStatus(id,val)
   {
   var re_confirm = confirm("Are you sure ?");
   if(re_confirm){
       $("#cstm-opcty").css('opacity','0.5');
   $.ajax({
   url: "<?php echo base_url('departmentView/edit_status');?>",
   method:'POST',
   data:{id:id,status:val},
   success: function(data)
   {
    // alert(data);
       $("#cstm-opcty").css('opacity','1');
      if(data==1)
      {
       location.reload();
      }

   }
   });
   }
   }



 </script> 
 <script src="<?php echo base_url(); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="<?php echo base_url(); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="<?php echo base_url(); ?>dist/js/demo.js"></script>
<!-- Page specific script -->
<script>
  $(function () {
    $("#myTable").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
    })
  });
</script>