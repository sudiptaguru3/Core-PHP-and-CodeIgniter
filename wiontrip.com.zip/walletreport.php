<?php 
include_once ("z_db.php");
$data ="";
include("Auth.php");

?>
<!DOCTYPE html>
<html lang="en">


<head>
	<?php include("headercss.php");?>
   
</head>

<body>
<div class="main-menu">
	<?php 
		include("header.php");
	?>
	<!-- /.header -->
	<?php 
		include("sidemenu.php");
	?>
	<!-- /.content -->
</div>
<!-- /.main-menu -->


<!-- /.fixed-navbar -->


<!-- /#notification-popup -->


<!-- /#message-popup -->
<?php include("uppernav.php");?>
<!-- #color-switcher -->

<div id="wrapper">
	<div class="main-content">
		<div class="row small-spacing">
			
			<div class="col-xs-12">
				<div class="box-content">
					<h4 class="box-title">E-Wallet Report</h4>
					<!-- /.box-title -->
                     <table id="example" class="table table-striped table-bordered display" style="width:100%">
                          <thead>
                            <tr>
                              <th >S No.</th>
                              <th >Username</th>
                              <th > Full Name</th>
                              <th >Wallet Balance</th>
                              <th >Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php
                                $qre = mysqli_query($con,"select *,(select username from affiliateuser where Id=u.Msrno)username,(select fname from affiliateuser where Id=u.Msrno)name from uwalletstatus u where Msrno in (select Id from affiliateuser) order by Msrno asc");
                                $data ="";
                                $i=1;
                                while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
                                {
                                    
                                 $data .="<tr><td>".$i."</td><td>".$res["username"]."</td><td>".$res["name"]."</td><td>".$res["BalAmount"]."</td><td><a href='wallet_details.php?sol=".$res["Msrno"]."' class='btn btn-success'>View Details</a></td></tr>";
                                 $i++;
                                }
                                echo $data;
                            ?>
                          
                          </tbody>
                        </table>
    
				
				<!-- /.box-content -->
			</div>
		</div>
		<!-- /.row -->		
		<?php include("footer.php"); ?>
	</div>
	<!-- /.main-content -->
</div><!--/#wrapper -->

	<?php include("footerjs.php"); ?>
    <script src="assets/plugin/datatables/media/js/jquery.dataTables.min.js"></script>
	<script src="assets/plugin/datatables/media/js/dataTables.bootstrap.min.js"></script>
    <script src="assets/plugin/datatables/extensions/Responsive/js/dataTables.responsive.min.js"></script>
    <script src="assets/plugin/datatables/extensions/Responsive/js/responsive.bootstrap.min.js"></script>
    <script src="assets/scripts/datatables.demo.min.js"></script>
     
</body>


</html>