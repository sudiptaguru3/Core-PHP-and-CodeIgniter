<?php
session_start()
session_destroy();
echo($_SESSION['name']);
// print_r($_SESSION);
?>