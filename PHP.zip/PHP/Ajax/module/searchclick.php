<?php

//Including Database configuration file.

include "connection.php";

//Getting value of "search" variable from "script.js".

if (isset($_POST['search'])) {

//Search box value assigning to $Name variable.

   $Name = $_POST['search'];

//Search query.

   $query = "SELECT * FROM user WHERE name LIKE '$Name%' ORDER BY name ASC";

//Query execution

   $dbquery = mysqli_query($conn, $query);

//Creating unordered list to display result.

   echo '<ul>';

   //Fetching result from database.

   while ($result = mysqli_fetch_array($dbquery)) {

       ?>

   <li onclick='fill("<?php echo $result['name']; ?>")'>

   <a>

   <!-- Assigning searched result in "Search box" in "search.php" file. -->
  
    <?php echo $result['name']; ?>


   </li></a>
   

   <?php

 }
}
?>

</ul>