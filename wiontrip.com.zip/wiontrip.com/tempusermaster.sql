-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 198.23.52.177:3306
-- Generation Time: Feb 13, 2021 at 12:18 PM
-- Server version: 5.6.26
-- PHP Version: 7.0.33-0+deb9u10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vktalwar55_wion`
--

-- --------------------------------------------------------

--
-- Table structure for table `tempusermaster`
--

CREATE TABLE `tempusermaster` (
  `id` int(11) NOT NULL,
  `username` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `company_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `contact_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `contact_no` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `contact_no_alt` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `pincode` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `company_gst` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `company_pan` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `upload_pancard` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `upload_gst` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `isactive` enum('0','1') COLLATE utf8_unicode_ci NOT NULL,
  `ondate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tempusermaster`
--

INSERT INTO `tempusermaster` (`id`, `username`, `company_name`, `contact_name`, `password`, `contact_no`, `contact_no_alt`, `email`, `address`, `city`, `state`, `country`, `pincode`, `company_gst`, `company_pan`, `upload_pancard`, `upload_gst`, `isactive`, `ondate`) VALUES
(1, 'WIONTAGNT1', 'Paryass Marketing', 'Vicky Talwar', '12345678', '7986956385', '9803452902', 'vtalwar55@gmail.com', 'Hall Gate', 'Amritsar', 'PUNJAB', 'India', '', '12sdsdsd45545665', 'HjJHK12345', '', '', '1', '2021-01-28 02:34:00'),
(2, 'WIONTAGNT2', 'Test', 'Test', 'test', '9126660605', '', 'test@gmail.com', 'Mumbai', 'Test', 'UTTAR PRADESH', 'India', '', '', 'Test', '', '', '1', '2021-01-28 03:31:00'),
(3, 'WIONTAGNT3', 'TEST1', 'DEMO', 'Qwer@123', '9920757013', '', 'printaet@gmail.com', 'SAKINAKA', 'SAKINAKA', 'MAHARASHTRA', 'INDIA', '', '', 'AFQPH4574M', '', '', '1', '2021-01-28 14:03:00'),
(4, 'WIONTAGNT4', 'RAIYAN DYES', 'KALIMULLAH SIDDIQUI', 'Saki@1234', '9324547549', '7021855744', 'kam827549@gmail.com', '9 A SAMTA HOU SOC A G LINK ROAD', 'TILAK NAGAR', 'MAHARASHTRA', 'INDIA', '', '', 'BYFPS8219D', '', '', '1', '2021-02-09 11:09:00'),
(5, 'WIONTAGNT5', 'Schaefer - Legros', 'Oswaldo Leannon', 'LyQ5yzYzEREdV8d', 'bus', 'Facilitator', 'Mozell22@yahoo.com', '7094 Hudson Trail', 'Hahnmouth', 'ANDAMAN & NICOBAR', 'United States', '', 'Schaefer - Legros', 'Schaefer - Legros', '', '', '1', '2021-02-12 04:54:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tempusermaster`
--
ALTER TABLE `tempusermaster`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tempusermaster`
--
ALTER TABLE `tempusermaster`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
