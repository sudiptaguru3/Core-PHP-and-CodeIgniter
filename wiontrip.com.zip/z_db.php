<?php
$con = new mysqli("localhost", "vktalwar55_wion", "1m!Cjp97", "vktalwar55_wion");
//$con = new mysqli("localhost", "root", "", "demobinary");
date_default_timezone_set('Asia/Kolkata');
$datedata= date('Y-m-j G:i:a');
$bdata= date('Y-m-j');
$Y= date('Y');
$qre = mysqli_query($con,"select * from settings");
$res = mysqli_fetch_array($qre,MYSQLI_ASSOC);
extract($res);
?>