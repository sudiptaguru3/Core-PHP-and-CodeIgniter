<!DOCTYPE html>
<html lang="en">
<head>
    <title>View User</title>
</head>
<body>
    <a href="<?php echo base_url(); ?>">Add User </a> 
    &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="<?php echo base_url(''); ?>">View User</a>
    <hr>
    <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>
    <table border="2">
        <tr>
            
            <th>Name</th>
            <th>Email</th>
             <th>Address</th>
              <th>Phone</th>
              <th>Skill</th>
            <th>Action</th>
        </tr>
        <?php
        foreach($userinfo as $user){
        ?>
            <tr>
                
    <td><?php echo $user['name']; ?></td>
    <td><?php echo $user['email']; ?></td>
  <td><?php echo $user['address']; ?></td>
    <td><?php echo $user['phone']; ?></td>
    <td><?php echo $user['skill']; ?></td>
    <td> <button onclick="myfunc(<?php echo $user['id']; ?>)">Delete
        </button>
      <a href="<?php echo base_url('edit/'.$user['id']); ?>">Edit</a>
    </td>
            </tr>
        <?php
        }
        ?>
    </table>
    
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
    function myfunc(id)
    {
          var reconfirm=confirm("are you sure");
      if(reconfirm)
      {
       $.ajax({
    type:'post',
    url:'deleteUser',
    data:{id:id},
    success: function(data){
      location.reload();
         // if(data=="YES"){
         //     $ele.fadeOut().remove();
         //     location.reload();
         // }
         // else{
         //     alert("Delete the row");
         // }
    }

     })

      }
    }
</script>