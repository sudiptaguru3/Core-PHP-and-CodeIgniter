    <?php
      $testArray = array(1, 2, 3, 4, 5);
      $product = array_product($testArray); // Equivalent to 1 * 2 * 3 * 4 * 5
      var_dump($product);
      /* int(120) */
    ?>