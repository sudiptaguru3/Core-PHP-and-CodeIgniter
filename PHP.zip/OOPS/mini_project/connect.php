<?php
$conn=mysqli_connect('localhost','root','','oopsconnect');
if(!$conn)  
{  
  die('Could not connect: ' . mysqli_error());  
}  
echo 'Connected successfully <br>';  
  
?>