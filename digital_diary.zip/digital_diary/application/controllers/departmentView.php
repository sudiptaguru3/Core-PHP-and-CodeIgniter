<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   
   class departmentView extends CI_Controller 
   {
   	function __construct()
   	{
   		parent::__construct();
   		// $this->load->database();
   		$this->load->model('Department_model');
   	}
   
   	public function index()
   	{	
   		$this->load->model('Department_model');
   		$data['test']=$this->Department_model->get_data();
   
   		$this->load->view('include/header');
   		$this->load->view('include/sidebar');
   		$this->load->view('viewDepartment', $data);
   		// $this->load->view('include/footer');
   		
   	}
   
   	public function edit()
   	{
   		 $id=$this->uri->segment(3); 
   		 $this->load->model('Department_model');
   		 $data['user']= $this->Department_model->get_data($id);
   		 
   		 // echo "<pre>";
   		 // print_r($data);die();

//---------------------- adding update form to fetch data in form------------------------
   

   		$this->load->view('include/header');
   		$this->load->view('include/sidebar');
   		$this->load->view('updateDepartment',$data);
   		// $this->load->view('admin_user_add', $data);
   		$this->load->view('include/footer');
   
   	}
   
   	public function update_user() 
   	{   
   
   	 $id=$this->input->post('id');
   	 {
   	 	$data = array(
           // 'table_name' => 'admin_user', // pass the real table name
           'department' => $this->input->post('department')
       );
   	 }
   
       
   
       // echo "<pre>";
       // print_r($data);die();
   
       $this->load->model('Department_model');
   
       if($this->Department_model->upddata($data,$id)) 
       {	
           // echo("update successful");
           redirect('viewDepartment');
   
       }
       else
       {
           echo("update not successful");
       }
   
   }
   
   	public function delete_row($id='')
   	{  
   		$this->load->model('Department_model');
   		$id=$this->uri->segment(3);
   	    $this->Department_model->delete_data($id);
   	    redirect('departmentView');
   	}


  public function edit_status()
  {
    // print_r($_POST);die();

    $id= $this->input->post('id'); 
    $status = $this->input->post('status');
    
     $this->load->model('Department_model');
   
       if($this->Department_model->update_status($status,$id)) 
       {  
           echo '1';
       }
       else
       {
           echo '0';
       }
    
  }

   
   }
   
   ?>