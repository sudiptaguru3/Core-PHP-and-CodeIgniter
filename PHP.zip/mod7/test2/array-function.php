<?php
echo "<h3> Array Push </h3>";
$ar1= array('1'=>'Blue','2'=>'Yellow','3'=>'Black');
array_push($ar1, 'Red');
print_r($ar1);
echo "<br>";

echo "<h3> Array Pop </h3>";
$ar2= array('10','25','30');
array_pop($ar2);
print_r($ar2);
echo "<br>";

echo "<h3> Array Combine </h3>";
$ar3= array('20','30','50');
$ar4= array('blue','pink','green');
print_r(array_combine($ar3, $ar4));
echo "<br>";

echo "<h3> Array Merge </h3>";
print_r(array_merge($ar3, $ar4));
echo "<br>";

echo "<h3> Array Chunk </h3>";
$ar5= array('1'=>'red','2'=>'php','3'=>'Java','4'=>'C','5'=>'ejob','6'=>'green');
echo "<pre>";
print_r(array_slice($ar5, 3));
echo "<br>";

echo "<h3> Array Slice </h3>";
print_r(array_slice($ar5, 3));
echo "<br>";

echo "<h3> Array Unique </h3>";
$ar6= array('1'=>'php','2'=>'Java','3'=>'php','4'=>'C','5'=>'Java');
print_r(array_unique($ar6));
echo "<br>";

?>