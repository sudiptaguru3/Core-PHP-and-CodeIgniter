<?php
echo "<b> Parse Error </b> <br>";

$a=10;
echo $a."<br>";

echo "<b> Warning Error </b> <br>";

include 'a.php';
//require 'a.php';
echo "heloo php <br>";

echo "<b> Fatal Error </b> <br>";

function abc(){
	echo "php error";
}
//bca();
abc();
echo "<br>";

echo "<b> Notice Error </b> <br>";

$a='this is notice';
echo $b;

?>