<?php

class HomeModel extends CI_Model{
    
    function register($insertArray){
        
        if($this->db->insert('ci_crud',$insertArray)){
            return true;
        }else{
            return false;
        }
    }

    function getAllUsers(){
       
        $response = $this->db->get('ci_crud');
        // --fetch user data--
        $data = $response->result_array();   
        return $data;
    }
    
    function delete_user($userId){
        
        $this->db->where('id',$userId);
       
        if($this->db->delete('ci_crud')){
            return true;
        }else{
            return false;
        }
    }

    function getSingleUser($userId){
        
        $this->db->where('id',$userId);
        $data = $this->db->get('ci_crud');
        return $data->row_array();
    }

    function update_User($setArray, $userId){
        $this->db->set($setArray);
        $this->db->where('id',$userId);
        if($this->db->update('ci_crud')){
            return true;
        }else{
            return false;
        }
    }
}

?>