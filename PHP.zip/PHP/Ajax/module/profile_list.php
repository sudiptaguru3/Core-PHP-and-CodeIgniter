<!DOCTYPE html>
<html>
<head>
  <title>Profile Ajax Page</title>
  <script
        src="http://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
        crossorigin="anonymous">
  </script>
<script>
 function del(id){
      $.ajax({
              url:'delete_ajax.php',
              type:'post',
              data:{'send_id':id},
              success:function(d){
                $("#shw").html(d);
              // setTimeout(function(){window.location.reload(); }, 1000);
              }
            })
 }

 function edit(id){
      $.ajax({
              url:'edit_ajax.php',
              type:'post',
              data:{'send_edit_id':id},
              success:function(d){
                $("#para").html(d);
              }
            })
 }
</script>
</head>
</html>

<?php
include "connection.php";
$sql=mysqli_query($conn,"SELECT * FROM user");

if(isset($_REQUEST['del']) && $_REQUEST['del']==1){
	echo "<font color='green'>Data Deleted Successfully</font>";
}

if(isset($_REQUEST['del']) && $_REQUEST['del']==0){
	echo "<font color='red'>Sorry, Data is not Deleted</font>";
}

?>

<table border="2" id="shw" align="center" cellpadding="10">
<tr>
<th>NAME</th>
<th>EMAIL</th>
<th>ADDRESS</th>
<th>PHONE NO</th>

<th colspan="2" >ACTION</th>
</tr>
<?php
while($fetch=mysqli_fetch_array($sql))
{
?>
 <tr>
        <td><?php echo $fetch['name']; ?></td>
        <td><?php echo $fetch['email']; ?></td>
        <td><?php echo $fetch['address']; ?></td>
        <td><?php echo $fetch['contact']; ?></td>
		<!-- <td><img src="<?php echo $fetch['file'] ?>" height="100px"      width="100px">
		</td> -->

        <td><button onclick="edit(<?php echo $fetch['id'];?>)">Edit
        </button>
        </td>

        <td><button onclick="del(<?php echo $fetch['id'];?>)">Delete</button>
        </td>

        
 </tr>
<?php
}
?>
</table>
<br>
<p id="para"></p>