<?php
if(isset($_REQUEST['change']) && $_REQUEST['change']==0){
   echo "<font color='red'> Password doesnot Update</font>";
}

?>

<form action="changepass_action.php" method="post" id="frm">
<h1>Change Your Password</h1>
	Old Password:<input type="password"  name="old_pass"></br>
	New Password:<input type="password"  name="new_pass"></br>
	Confirm Password:<input type="password" name="confirm_pass"></br>
	<input type="submit" name="sbm" value="change">
</form>