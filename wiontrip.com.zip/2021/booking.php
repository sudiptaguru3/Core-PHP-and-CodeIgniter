<?php 
include_once ("z_db.php");
$data ="";
include("Auth.php");



?>
<!DOCTYPE html>
<html lang="en">


<head>
	<?php include("headercss.php");?>
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  
</head>

<body>
<div class="main-menu">
	<?php 
		include("header.php");
	?>
	<!-- /.header -->
	<?php 
		include("sidemenu.php");
	?>
	<!-- /.content -->
</div>
<!-- /.main-menu -->


<!-- /.fixed-navbar -->


<!-- /#notification-popup -->


<!-- /#message-popup -->
<?php include("uppernav.php");?>
<!-- #color-switcher -->

<div id="wrapper">
	<div class="main-content">
		<div class="row small-spacing">
			
			<div class="col-xs-12">
				<div class="box-content">
					<table class="table mb-0">
								<tr>
									<th><select class="form-control">
										
									</select></th>
									<th><input type="text" name="to" id="datepicker" value="<?php echo $to;?>" placeholder="Date" class="form-control"></th>
									<th>
										<select class="form-control">
										
									</select>
									</th>
									<th><input type="submit" value="Search" name="payout"  class="btn btn-success"/></th>
								</tr>
							</table>
					<h4 class="box-title"> Pending Booking List</h4>
					<!-- /.box-title -->
                     
						
                        	
                            <table id="example" class="table table-striped table-bordered display" style="width:100%">
                            	<thead>
                                    <tr>
                                        <th>#Ref No.</th>
                                        <th>Agent</th>
                                        <th>Airline</th>
                                        <th>Travel Date</th>
                                        <th>PNR</th>
                                        <th>Sector</th>
                                        <th>Seat</th>
                                        <th>Amount</th>
                                        <th>Requested Date</th>
                                       
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
										$qre = mysqli_query($con,"select *,(select company_name from tempusermaster where id=m.Msrno)company_name,(SELECT city_name from airport_master where id=m.from_city)city_name1,(SELECT city_name from airport_master where id=m.to_city)city_name2 from (select *,(select airline from airline_master where id=b.airline_id)airline,(select from_city from destination_master where id=b.destination_id)from_city,(select to_city from destination_master where id=b.destination_id)to_city from booking_master b where PNR='') m ");
										if(mysqli_num_rows($qre)>0)
										{
											while($res = mysqli_fetch_array($qre,MYSQLI_ASSOC))
											{?>
												<tr>
													<td><a href="booking_details.php?ref=<?php echo $res["booking_PNR"];?>&lnk=booking.php"><?php echo $res["booking_PNR"];?></a></td>
                                                    <td><?php echo $res["company_name"];?></td>
													<td><?php echo $res["airline"];?></td>
													<td><?php echo $res["flight_date"];?></td>
													<td><?php 
														if($res["PNR"]=="")
														{
															echo "Pending";
														}
														else
														{
															echo $res["PNR"];		
														}
													?></td>
													<td><?php echo $res["city_name1"];?> To : <?php echo $res["city_name2"];?></td>
													<td><?php echo $res["ticket"];?></td>
													<td><?php echo $res["total_fare"];?></td>
													<td><?php echo $res["ondate"];?></td>
													 <td>Print Invoice</td>
												</tr>
											<?php }
										}
									?>
                                </tbody>
                            </table>                  
                    
    
				
				<!-- /.box-content -->
			</div>
		</div>
		<!-- /.row -->		
		<?php include("footer.php"); ?>
	</div>
	<!-- /.main-content -->
</div><!--/#wrapper -->

	<?php include("footerjs.php"); ?>
    <script src="assets/plugin/datatables/media/js/jquery.dataTables.min.js"></script>
		<script src="assets/plugin/datatables/media/js/dataTables.bootstrap.min.js"></script>
		<script src="assets/plugin/datatables/extensions/Responsive/js/dataTables.responsive.min.js"></script>
		<script src="assets/plugin/datatables/extensions/Responsive/js/responsive.bootstrap.min.js"></script>
		<script src="assets/scripts/datatables.demo.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
     <script>
				jQuery(".onlynum").keydown(function (event) {
				if (event.shiftKey) {
					event.preventDefault();
				}
	
				if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9) {
				}
				else {
					if (event.keyCode < 95) {
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault();
						}
					}
					else {
						if (event.keyCode < 96 || event.keyCode > 105) {
							event.preventDefault();
						}
					}
				}
	
			});
			
			function drp()
			{
				var airline_id = $("#airline_id").val();
				
				if(airline_id>0)
				{
					$.ajax({ //make ajax request to cart_process.php
					url: "pst.php",
					type: "POST",
					dataType:"json", //expect json value from server
					data: { 'airline_id': airline_id}
					}).done(function(data){ //on Ajax success
						$("#destination_id").empty();
						$("#destination_id").html(data.items);
					});						
				}
			}
        </script>
          <script>
  $( function() {
    $( "#datepicker" ).datepicker({ minDate: 0 ,dateFormat:"dd-mm-yy",maxDate: new Date('02-02-2012','03-02-2021')});
  } );
  </script>
</body>


</html>