
<?php
session_start();
// Delete certain session
unset($_SESSION['USERNAME']);
unset($_SESSION['MSRNO']);
unset($_SESSION['COMPANY_NAME']);
// Delete all session variables
session_destroy();

// Jump to login page
echo "<script>window.location='login.php';</script>";
//header('Location: index.php'); //you can change this to the home page of website

?>
