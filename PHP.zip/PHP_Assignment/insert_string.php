<?php 
$str = 'The brown box'; 
echo substr_replace($str,'quick ',4, 0);
?> 