<?php
if(isset($_REQUEST['reg']) && $_REQUEST['reg']==1){
   echo "<font color='green'> Registration Successfull </font>";
}
if(isset($_REQUEST['log']) && $_REQUEST['log']==0){
   echo "<font color='red'> Login Unsuccessfull </font>";
}
?>

<form action="login_action.php" method="POST">
<h1> User Login</h1>
Username:<input type="email" name="email"><br><br><br>
Password:<input type="password" name="password"><br><br><br>
<input type="submit" name="submit" value="Login">
</form>