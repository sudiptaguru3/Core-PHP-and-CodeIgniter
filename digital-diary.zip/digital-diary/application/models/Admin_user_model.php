<?php
  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Admin_user_model extends CI_Model 
{
	
	function saverecords($data)
	{
          $this->db->insert('admin_user',$data);
          return $this->db->insert_id();
	}

	public function get_data($id=0)
	{
		if($id==0)
		{
			$query = $this->db->get('admin_user')->result();
			return $query;
		}
		else
		{
			$this->db->where('id',$id);
			$query = $this->db->get('admin_user')->result();
			return $query;
		}
		
	}


	public function upddata($data,$id)       
	{
	    extract($data); 
	    $this->db->where('id', $id);
	    // $this->db->update($table_name, array('full_name' => $full_name, 'email' =>$email, 'mobile' =>$mobile, 'status' =>$status, 'user_role' =>$user_role, 'profile_pic'=>$profile_pic));
	    $this->db->update('admin_user', $data);
	    return true;
	}

	public function delete_data($id)
	{
	    $this -> db -> where('id', $id);
	    $this -> db -> delete('admin_user');
	}

	public function update_status($status,$id)
	{
    	$this->db->query("UPDATE admin_user SET status = '$status' WHERE id = '$id' ");
    	return true;
	}

}
?>
