<?php
class UploadModel extends CI_Model{

  function fileupload($path){
  	 if($this->db->insert('upload',$path)){
            return true;
        }else{
            return false;
        }
  }
}
?>