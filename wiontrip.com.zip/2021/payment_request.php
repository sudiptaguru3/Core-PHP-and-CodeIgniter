<?php 
include_once ("z_db.php");
$data ="";
include("Auth.php");



?>
<!DOCTYPE html>
<html lang="en">


<head>
	<?php include("headercss.php");?>
     <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  
</head>

<body>
<div class="main-menu">
	<?php 
		include("header.php");
	?>
	<!-- /.header -->
	<?php 
		include("sidemenu.php");
	?>
	<!-- /.content -->
</div>
<!-- /.main-menu -->


<!-- /.fixed-navbar -->


<!-- /#notification-popup -->


<!-- /#message-popup -->
<?php include("uppernav.php");?>
<!-- #color-switcher -->

<div id="wrapper">
	<div class="main-content">
		<div class="row small-spacing">
			
			<div class="col-xs-12">
				<div class="box-content">
					<table class="table mb-0">
								<tr>
									<th><select class="form-control">
										
									</select></th>
									<th><input type="text" name="to" id="datepicker" value="<?php echo $to;?>" placeholder="Date" class="form-control"></th>
									<th>
										<select class="form-control">
										
									</select>
									</th>
									<th><input type="submit" value="Search" name="payout"  class="btn btn-success"/></th>
								</tr>
							</table>
					<h4 class="box-title"> Pending Booking List</h4>
					<!-- /.box-title -->
                     
						
                        	
                            <table border="1" class="table">
<tr>
	<th style="color: white;">SL No</th>
	<th style="color: white;">Amount</th>
	<th style="color: white;">Ref No</th>
	<th style="color: white;">Branch Name</th>
	<th style="color: white;">Payment Type</th>
	<th style="color: white;">Payment Date</th>
	<th style="color: white;">Message</th>
	<th style="color: white;">Attachment</th>
	<th style="color: white;">Status</th>
</tr>

	<?php
	$i=1;
	$sql=mysqli_query($con,"SELECT *,(case when isactive='1' AND isaprove='1' then 'Aproved' else (case WHEN isactive='0' AND isaprove='0' THEN 'Reject' else 'Pending' END) END)status FROM payment_request");
	while($data=mysqli_fetch_array($sql))
	{
		?>
		<tr>
		<td><?php echo $i++;?></td>	
		<td><?php echo $data['amount'];?></td>
		<td><?php echo $data['ref'];?></td>
		<td><?php echo $data['branch_name'];?></td>
		<td><?php echo $data['payment_type'];?></td>
		<td><?php echo $data['payment_date'];?></td>
		<td><?php echo $data['message'];?></td>
		<td><img src="<?php echo $data['attachment']; ?>" width="100px" height="100px"></td>
		<td><?php echo $data['status'];?></td>
		<!-- <td><a href="active_deactive.php?id=<?php echo $data['id'];?>">
		<?php
			if($data['']==1)
			{
				echo "Block";
			}
			else
			{
				echo "Unblock";
			}
			?>
				
			</a>
		</td> -->
	</tr>
	<?php	
	}
	?>


</table>                  
                    
    
				
				<!-- /.box-content -->
			</div>
		</div>
		<!-- /.row -->		
		<?php include("footer.php"); ?>
	</div>
	<!-- /.main-content -->
</div><!--/#wrapper -->

	<?php include("footerjs.php"); ?>
    <script src="assets/plugin/datatables/media/js/jquery.dataTables.min.js"></script>
		<script src="assets/plugin/datatables/media/js/dataTables.bootstrap.min.js"></script>
		<script src="assets/plugin/datatables/extensions/Responsive/js/dataTables.responsive.min.js"></script>
		<script src="assets/plugin/datatables/extensions/Responsive/js/responsive.bootstrap.min.js"></script>
		<script src="assets/scripts/datatables.demo.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
     <script>
				jQuery(".onlynum").keydown(function (event) {
				if (event.shiftKey) {
					event.preventDefault();
				}
	
				if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9) {
				}
				else {
					if (event.keyCode < 95) {
						if (event.keyCode < 48 || event.keyCode > 57) {
							event.preventDefault();
						}
					}
					else {
						if (event.keyCode < 96 || event.keyCode > 105) {
							event.preventDefault();
						}
					}
				}
	
			});
			
			function drp()
			{
				var airline_id = $("#airline_id").val();
				
				if(airline_id>0)
				{
					$.ajax({ //make ajax request to cart_process.php
					url: "pst.php",
					type: "POST",
					dataType:"json", //expect json value from server
					data: { 'airline_id': airline_id}
					}).done(function(data){ //on Ajax success
						$("#destination_id").empty();
						$("#destination_id").html(data.items);
					});						
				}
			}
        </script>
          <script>
  $( function() {
    $( "#datepicker" ).datepicker({ minDate: 0 ,dateFormat:"dd-mm-yy",maxDate: new Date('02-02-2012','03-02-2021')});
  } );
  </script>
</body>


</html>