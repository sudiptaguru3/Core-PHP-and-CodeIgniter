<?php
$a=15;
//global $a;
function test(){
	global $a;

	echo "The inside value is: ".$a;
}
test();
echo "<br>";
echo "The outside value is: ".$a;
?>