<?php
$str= "hello ejob";
$str1= "HELLO WORLD";
$stre= "this is php ejob also android ejob";

echo "<h3> lcfirst </h3> <br>";
$str2= lcfirst($str1);
echo $str2."<br>";

echo "<h3> ucfirst </h3> <br>";
$str3= ucfirst($str);
echo $str3."<br>";

echo "<h3> ucwords </h3> <br>";
$str4= ucwords($str);
echo $str4."<br>";

echo "<h3> strtoupper </h3> <br>";
$str5= strtoupper($str);
echo $str5."<br>";

echo "<h3> str_word_count </h3> <br>";
$str6= str_word_count($str);
echo $str6."<br>";

echo "<h3> strtolower </h3> <br>";
$str7= strtolower($stre);
echo $str7."<br>";

echo "<h3> strtolower </h3> <br>";
$str8= strtolower($str);
echo $str8."<br>";

echo "<h3> string position of last occurence </h3> <br>";
$str9= strrpos($stre,'ejob');
echo $str9."<br>";

echo "<h3> string length </h3> <br>";
$str10= strlen($stre);
echo $str10."<br>";

echo "<h3> sub string </h3> <br>";
$str11= substr($str,3);
echo $str11."<br>";

echo "<h3> sub string replace </h3> <br>";
$str12= substr_replace($str, 'word',6);
echo $str12."<br>";

echo "<h3> string character of first occurence </h3> <br>";
$str13= strchr($stre, 'e');
echo $str13."<br>";

echo "<h3> string character of last occurence </h3> <br>";
$str14= strrchr($stre, 'e');
echo $str14."<br>";

echo "<h3> string replace </h3> <br>";
$str15= str_replace('ejob', 'india', $str);
echo $str15."<br>";

echo "<h3> string repeat </h3> <br>";
$str16= str_repeat($str,3);
echo $str16."<br>";

echo "<h3> string replace </h3> <br>";
$str17= str_replace('ejob', 'india', $str);
echo $str17."<br>";

echo "<h3> strip tags </h3> <br>";
$strt= "<h3>this is <b>strip tags</b> </h3> <br>";
$str18= strip_tags($strt);
echo $str18."<br>";

echo "<h3> trim tags </h3> <br>";
$str19= trim($str, "heob");
echo $str19."<br>";

echo "<h3> encrypted string </h3> <br>";
$str19= md5($str);
echo $str19."<br>";

echo "<h3> explode function </h3> <br>";
$arr= explode(' ', $stre);
print_r($arr);

?>
