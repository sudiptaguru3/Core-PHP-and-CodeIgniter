<html>
<body>

<form action="file_upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileup" id="fileToUpload"> <br>
    <input type="submit" value="Upload" name="submit">
</form>

</body>
