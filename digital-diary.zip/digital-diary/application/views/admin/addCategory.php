<?php 
  include('header.php');

?>
         <!-- /.navbar -->
         <!-- Main Sidebar Container -->
         
         <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
               <div class="container-fluid">
                  <div class="row mb-2">
                     <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                     </div>
                     <!-- /.col -->
                     <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                           <li class="breadcrumb-item"><a href="#">Home</a></li>
                           <li class="breadcrumb-item active">Dashboard v1</li>
                        </ol>
                     </div>
                     <!-- /.col -->
                  </div>
                  <!-- /.row -->
               </div>
               <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
          
            <!-- /.content -->

            <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Create New Category</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Create New Blog </li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

<section class="content">
  <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>

  <form action="<?php echo base_url('registration'); ?>" method="POST">
    <div class="col-sm-12 col-md-6 col-lg-6">
                      <div class="form-group">
                        <label for class>Category Title</label>
                        <input type="text" class="form-control" name="category_id" id="" value="" placeholder="Enter Category Title">
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6">
                      <div class="form-group">
                        <label for="">Category Slug</label>
                        <input type="text" class="form-control" name="category_slug" id="" value="" placeholder="Enter Category Title">
                        <!-- <textarea class="form-control" name="category_slug" id="meta_description"></textarea> -->
                      </div>
                    </div>

                   <!--  <input type="radio" name="">Active&nbsp;
                    <input type="radio" name="">Deactive
                    <br><br> -->
                    <input type="submit" name="submitbtn" value="INSERT">
                    <input type="reset" name="resetbtn" value="RESET">
                    </div><br>
                  </form>
                <input type="radio" name="">

                  </section>
