<?php
$q= array("ad","@",".com");
$hj= array("/Name/ad","/domain/","/Extension/com/");
$xString= "admin@gmail.com";
print str_replace($q,$hj,$xString);
// $newString= "/Name/admin/domain/gmail/Extension/com/";
// $arr= explode("/",trim($newString,"/"));

// $keys= array_filter($arr,function($k){
// 	return($k%2==0);
// },ARRAY_FILTER_USE_KEY);
// $values= array_filter($arr,function($k){
// 	return($k%2==1);
// },ARRAY_FILTER_USE_KEY);
// $result= array_combine($keys,$values);
// print_r(($result));

?>