<?php
session_start();
include "connect.php";
$email=$_REQUEST['email'];
$password=md5($_REQUEST['password']);
$sql="SELECT * FROM user WHERE email='$email' AND password='$password'";

$rs=mysqli_query($conn, $sql);
// print_r($rs);exit;
if(mysqli_num_rows($rs)==1)
{
		$fetch = mysqli_fetch_array($rs);
		if($fetch['login_status']==0)
		{

			$_SESSION['id'] = $fetch['id'];
			 //echo "<font color='green'>Login Successfull</font>";
			header("location:profile.php?login=1");
		}
		else
		{
			header("location:login.php?login=2");
		}

}
else
{
	// echo "<font color='red'>Login Unsuccessfull</font>";
	header("location:login.php?login=0");
}
?>